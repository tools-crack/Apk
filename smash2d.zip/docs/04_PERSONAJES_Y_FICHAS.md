# 04 · Personajes y fichas (.tres)

Cada personaje tiene **un archivo** en `characters/` que describe todo lo que lo
distingue: nombre, color, sprites, velocidad, salto, daño, vidas y su especial.
Se llama **ficha**.

## Cómo editar una ficha

1. En Godot, panel **FileSystem**, abre `characters/gaviotero.tres` (doble clic).
2. Se muestra el **Inspector** con todos los campos. Cambia el valor que quieras.
3. Guarda con **Ctrl+S**. Los cambios se aplican la siguiente vez que se entra a la arena.

No hace falta tocar código. Si cambias un número y no notas diferencia, revisa que
estés editando la ficha correcta (la de `id = "..."` de ese archivo).

## Campos de la ficha

Los campos se agrupan igual que en el Inspector.

### Identidad

| Campo | Qué es | Ejemplo |
|---|---|---|
| `id` | Nombre interno. Debe ser único. Si se deja vacío se usa el nombre del archivo. | `"topo"` |
| `order` | Posición en la selección (1 = primero, a la izquierda). | `2` |
| `display_name` | Nombre que se ve en menús y en el HUD. | `"Topo"` |
| `special_name` | Nombre de la habilidad. | `"Excavación sorpresa"` |
| `description` | Texto de la selección. Acepta varias líneas. | `"Se hunde en la tierra..."` |
| `color` | Color de marcos, nombre y HUD. | azul, café... |
| `portrait` | Imagen grande de la selección (SVG). | `assets/sprites/topo/portrait.svg` |
| `scene` | Escena del luchador. | `scenes/fighters/Topo.tscn` |

### Movimiento

| Campo | Qué hace | Subir más... | Valores típicos |
|---|---|---|---|
| `move_speed` | Velocidad máxima al correr (px/s). | corre más rápido | 250–350 |
| `accel` | Qué tan rápido llega a esa velocidad en el suelo. | arranca más seco | 2000–3000 |
| `air_accel` | Lo mismo, en el aire. | más control en el aire | 1000–2000 |
| `jump_speed` | Fuerza del salto. | salta más alto | 650–800 |
| `gravity` | Qué tan fuerte cae. | cae más rápido (salto más corto) | 1500–2000 |
| `max_fall_speed` | Velocidad máxima de caída. | cae más rápido al final | 800–1200 |
| `max_air_jumps` | Saltos extra en el aire. `1` = doble salto. | `2` = triple salto | 0–2 |

### Golpe básico

El golpe tiene tres tiempos (todos en segundos):

```
 |---- attack_startup ----|--- attack_active ---|------ resto ------|
 pulsas F                  el golpe daña aquí     vuelves a moverte
 |<------------------------ attack_total --------------------------->|
```

| Campo | Qué hace |
|---|---|
| `attack_damage` | % de daño que causa cada golpe. |
| `attack_knockback` | Empuje: `x` se invierte si mira a la izquierda; `y` negativo = hacia arriba. |
| `attack_startup` | Tiempo antes de que el golpe empiece a dañar. Más alto = golpe más lento. |
| `attack_active` | Cuánto dura el golpe dañando. |
| `attack_total` | Duración total del golpe. Debe ser mayor que `attack_startup + attack_active`. |

### Vidas

| Campo | Qué hace |
|---|---|
| `max_stocks` | Vidas al empezar (1 a 9). |

### Habilidad especial

| Campo | Gaviotero | Topo | Likan | Aukin | Ñanco | Winkul | Jorge | Levaro |
|---|---|---|---|---|---|---|---|---|
| Comunes: `special_cooldown`, `special_damage`, `special_knockback`, `special_windup` | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ |
| Propios | `gull_speed` | `dig_speed`, `dig_emerge_delay` | `rock_speed`, `rock_count`, `rock_zone_width`, `rock_gap_time` | `noodle_zone_width`, `noodle_squeezes`, `noodle_hold_time` | `smoke_length`, `smoke_duration`, `smoke_push_accel` | `spike_count`, `spike_spacing`, `spike_gap_time` | `hook_speed`, `hook_range`, `hook_reel_time` | `oar_swings`, `oar_reach`, `oar_height`, `oar_swing_time` |

Qué hace cada campo de la ficha, con rangos y valores por defecto: [16 · Guía de la ficha .tres](16_PARAMETROS_DE_HABILIDADES.md). Cómo funciona cada habilidad: [05 · Habilidades especiales](05_HABILIDADES_ESPECIALES.md).

## Ejemplos de cambios útiles

- **Hacer al Topo más peligroso:** sube `special_damage` de 15 a 20 y baja `special_cooldown` de 5 a 4.
- **Hacer al Topo más fácil de esquivar:** sube `dig_emerge_delay` de 0.22 a 0.4 (más tiempo para saltar).
- **Gaviotero más rápido:** sube `gull_speed` de 470 a 600. Ojo: la gaviota llega antes y es más difícil esquivar.
- **Más rocas para Likan:** sube `rock_count` de 5 a 8 (y `rock_zone_width` si quieres que cubran más).
- **Tallarines más cortos:** baja `noodle_hold_time` del Aukin de 0.9 a 0.5.
- **Luchador "pesado":** sube `gravity` y baja `jump_speed`. Cae rápido y salta poco.
- **Triple salto:** pon `max_air_jumps = 2`.

## Relación con el código

- El luchador copia estos valores **al empezar la partida** (`Fighter.apply_data()`).
  Si cambias una ficha, la siguiente partida ya lo usa; no hace falta reiniciar Godot
  salvo que ya lo tengas abierto con la escena cargada.
- Los scripts de especiales leen los valores desde `stats` (la ficha completa).
  Por eso `Topo.gd` lee `stats.dig_speed`, por ejemplo.
- Si añades un campo COMÚN nuevo a `CharacterData.gd` (los de habilidad no hacen falta), recuerda copiarlo también en
  `Fighter.apply_data()`, o el luchador nunca lo verá.
