# 03 · Arquitectura del código

Esta es la parte más importante para entender cómo funciona el juego. No hace falta
memorizarla: basta con saber **quién hace qué** y **dónde mirar**.

## Las piezas principales

```
            ┌──────────────────────────┐
            │  Config (autoload)       │  números globales
            └──────────────────────────┘
            ┌──────────────────────────┐
            │  Game (autoload)         │  personajes cargados, selección, música
            └────────────┬─────────────┘
                         │ lee characters/*.tres
   ┌─────────────────────┼──────────────────────┐
   ▼                     ▼                      ▼
MainMenu  ──►  CharSelect (+2 PickPanel)  ──►  Arena
                                                 │ crea 2 luchadores
                                                 ▼
                                   Fighter (base, KinematicBody2D)
                                     ├── Gaviotero  (especial: gaviota)
                                     └── Topo       (especial: excavar)
                                                 │ crea
                                                 ▼
                                   Gull, HitSpark (efectos)
```

## Autoloads: lo que vive toda la sesión

Un **autoload** es un script que Godot carga al arrancar y que existe mientras el juego
esté abierto, en cualquier escena. Hay dos (ver `project.godot`):

- **`Config`** (`scripts/core/Config.gd`): solo constantes. Cualquier script escribe
  `Config.KNOCKBACK_GROWTH`, por ejemplo. Ver [09](09_CONFIGURACION_GLOBAL.md).
- **`Game`** (`scripts/core/Game.gd`): datos que cambian durante la sesión.
  - `CHARACTERS`: diccionario `id → CharacterData` con todas las fichas.
  - `ORDER`: los ids en el orden de la selección.
  - `selected`: `[id de P1, id de P2]`.
  - `practice`: `true` si jugamos contra el muñeco.
  - `play_music()`, `goto()`, `goto_menu()`.

## Las fichas: CharacterData

`scripts/core/CharacterData.gd` define los campos comunes de una ficha y `scripts/core/data/Data<Personaje>.gd` (hereda de él) añade los de la habilidad de cada personaje, para que el Inspector de cada `.tres` solo muestre los suyos. Cada archivo
`characters/*.tres` es una instancia de ese recurso. Los `export var` aparecen en el
Inspector de Godot, así que se editan sin código. Ver [04](04_PERSONAJES_Y_FICHAS.md).

## El luchador: Fighter

`scripts/fighters/Fighter.gd` es el **luchador base**. Contiene todo lo común:
movimiento, salto, golpe básico, daño, KO y reaparición. Está organizado en secciones
numeradas (1 a 9) con comentarios. Los puntos clave:

### Estados

La variable `state` dice qué está haciendo el luchador:

| Estado | Significado | Puede moverse |
|---|---|---|
| `NORMAL` | Lo controla el jugador | Sí |
| `ATTACK` | Dando el golpe básico | Muy poco |
| `SPECIAL` | Ejecutando su especial | Depende del especial |
| `HURT` | Aturdido, volando tras un golpe | No |
| `DEAD` | Fuera de la pantalla, esperando | No |

El bucle principal (`_physics_process`) mira el estado y llama a la función correspondiente:
`_state_normal`, `_state_attack`, `_state_special`, `_state_hurt` o `_state_dead`.

### Ganchos del especial

Un especial no toca el código base: solo sobrescribe tres funciones.

```gdscript
func _can_special() -> bool        # ¿se puede usar ahora?
func _start_special() -> void      # al pulsar el botón
func _state_special(delta) -> void # cada frame mientras dura
```

`Gaviotero.gd` y `Topo.gd` hacen exactamente eso. Ver [05](05_HABILIDADES_ESPECIALES.md).

### Recibir daño

`take_hit(damage, knockback, attacker)` es **la única puerta de entrada al daño**.
Todo lo que pueda dañar (el golpe, la gaviota, el Topo) llama a esta función en el rival.
Hace:

1. Si el luchador es invulnerable, no hace nada y devuelve `false`.
2. Suma `damage` al porcentaje.
3. Calcula la velocidad del empuje: `knockback * (1 + porcentaje / KNOCKBACK_GROWTH)`.
4. Calcula el aturdimiento: entre `HITSTUN_BASE` y `HITSTUN_MAX`.
5. Pasa a `HURT`, reproduce sonido, destello y temblor de pantalla.

### KO y reaparición

Cada frame se comprueba si el luchador salió de la zona `BLAST_*` de `Config`. Si sí,
`_die()` le quita una vida, lo oculta y avisa a la arena. Pasado `RESPAWN_DELAY`,
`_respawn()` lo coloca en `RESPAWN_POSITION` con invulnerabilidad temporal.

### Desde la arena

`Arena.gd` crea los dos luchadores y llama a `apply_data()` (copia la ficha al
luchador) y `setup()` (lo coloca y le asigna su jugador). Ver siguiente sección.

## La arena: Arena

`scripts/stage/Arena.gd` controla la partida:

1. Crea a P1 y P2 con `Game.selected`, les aplica su ficha y los coloca en `Config.SPAWN_POINTS`.
2. Hace la cuenta atrás (`_countdown`) y luego `_start_match()` quita el bloqueo de input.
3. Cada frame: mueve la cámara para el temblor (`shake`), y comprueba si alguien se quedó sin vidas (`_finish`).
4. Se mete en el grupo `"arena"`, así cualquier luchador puede hacerla temblar con
   `get_tree().call_group("arena", "shake", fuerza)`.

## Grupos (cómo se encuentran los objetos entre sí)

| Grupo | Quién está | Para qué |
|---|---|---|
| `fighters` | Los dos luchadores | El Topo busca a su rival |
| `arena` | La escena Arena | Los golpes la hacen temblar |

## Flujo de una partida

```
MainMenu ──Jugar──► CharSelect ──ambos listos──► Arena
                                                  │
                             cuenta 3,2,1,¡YA! ◄──┘
                                                  │
                    ┌─────────────────────────────┤
                    │  golpes, especiales, KO     │
                    └─────────────────────────────┤
                                                  ▼
                             "¡GANA P1!" ──Enter──► revancha
                                         ──Esc────► MainMenu
```

## Convenciones del código

- **Nada de números sueltos**: si un número es global va a `Config`; si es de un
  personaje va a su `.tres`. Solo quedan en el código los números **atados a una
  animación** (por ejemplo, cuándo aparece la gaviota), y están comentados.
- **Comentarios de sección**: los archivos largos están divididos con líneas `# ====`.
- **Un script por responsabilidad**: el luchador base no sabe nada de gaviotas; la gaviota no sabe nada del menú.
