# 05 · Habilidades especiales

Cada personaje tiene **una** habilidad especial, activada con su botón de especial
(**G** para P1, **L** para P2). Ambas son **esquivables**: la idea es que el rival
tenga un aviso y pueda reaccionar.

## Gaviotero · "Gaviota veloz"

**Qué hace:** invoca una gaviota que vuela en línea recta hacia donde mira el jugador
y atraviesa el mapa. Si toca a un rival, le hace daño y lo empuja.

### Secuencia

1. Pulsas G. El Gaviotero hace la animación `special` (3 cuadros, 8 fps).
2. Durante **`special_windup`** (0.35 s por defecto) se queda preparando el lanzamiento. Es el
   **aviso**: si lo subes, tarda más en soltar la gaviota; si lo bajas, la suelta antes.
3. Pasado ese tiempo aparece la gaviota delante de él, a **90 px** (`SPAWN_AHEAD`), con un
   breve fundido visual. Desde ese momento **ya daña**.
4. La gaviota vuela recta a `gull_speed` px/s, con un pequeño vaivén de 10 px.
5. Si toca a un rival, le hace `special_damage` y lo empuja con `special_knockback`.
   Cada rival solo puede recibirla **una vez**.
6. Al salir del mapa (x < −240 o x > 1520), la gaviota desaparece. El Gaviotero recupera el
   control `RECOVER_TIME` (0.24 s) después de soltarla.

### Cómo esquivarla

- **Saltar por encima.** La hitbox está a la altura del cuerpo, así que un salto la deja pasar.
- **Alejarse** hacia el lado contrario a donde vuela.
- Tienes el tiempo de preparación (`special_windup`) más el vuelo de la gaviota para reaccionar.

### Números que controlan la gaviota

| Dónde | Campo | Valor | Efecto |
|---|---|---|---|
| `characters/gaviotero.tres` | `special_cooldown` | 3.0 | recarga |
| | `special_damage` | 9.0 | daño |
| | `special_knockback` | (420, −300) | empuje |
| | `gull_speed` | 470 | velocidad |
| | `special_windup` | 0.35 | segundos de preparación antes de soltar la gaviota |
| `scripts/fighters/Gaviotero.gd` | `RECOVER_TIME` | 0.24 | tiempo para recuperar el control tras soltarla |
| `scripts/effects/Gull.gd` | `SPAWN_AHEAD` | 90 | distancia de aparición |
| | `LEFT_LIMIT`, `RIGHT_LIMIT` | −240, 1520 | dónde desaparece |
| | `BOB` | 10 | amplitud del vaivén |

Los dos últimos bloques son de código.

## Topo · "Excavación sorpresa"

**Qué hace:** se hunde en la tierra, viaja bajo el suelo como un montículo hasta donde
está el rival, y emerge justo debajo de él, golpeándolo hacia arriba.

### Reglas

- **Solo desde el suelo principal.** No funciona en plataformas ni en el aire.
  Si lo intentas, suena el sonido de "no se puede".
- **Siempre emerge sobre el suelo principal**, aunque el rival esté en una plataforma.
  Nunca aparece en el aire. Y como su zona de golpe es pequeña (radio 42 px), **un rival
  parado en una plataforma no recibe el golpe**: el Topo sale por debajo, no por arriba.
- **El golpe llega un instante después de emerger**, para que el rival pueda saltar o alejarse.

### Fases

La variable `phase` controla lo que ocurre (ver `scripts/fighters/Topo.gd`):

| Fase | Duración | Qué pasa |
|---|---|---|
| `DIVE` | 0.42 s (fijo, animación) | Se hunde. Invulnerable. Sale polvo. |
| `UNDER` | hasta llegar al rival | Desaparece. El montículo viaja a `dig_speed`. Sin colisión. |
| `EMERGE` | 0.42 s | Aparece sobre el suelo. A los `dig_emerge_delay` golpea. |

En `UNDER` el montículo avanza hacia la **posición actual** del rival. Solo puede
terminar cuando ya pasó el tiempo mínimo (`special_windup`) **y** llegó a su lado.
Hay un tope de seguridad de 2 s (`UNDER_MAX`) por si el rival no se puede alcanzar.

### Cómo esquivarlo

- **Saltar en el momento de la emersión.** Tienes `dig_emerge_delay` (0.22 s por defecto) para saltar.
- **Alejarte mientras viaja bajo tierra.** El montículo lo ves venir (el tiempo y la trayectoria).
- **Subirte a una plataforma** también funciona: el Topo sale en el suelo y no te alcanza.

### Números que controlan al Topo

| Dónde | Campo | Valor | Efecto |
|---|---|---|---|
| `characters/topo.tres` | `special_cooldown` | 5.0 | recarga |
| | `special_damage` | 15.0 | daño |
| | `special_knockback` | (140, −820) | empuje (casi vertical) |
| | `dig_speed` | 520 | velocidad bajo tierra |
| | `special_windup` | 0.9 | tiempo mínimo bajo tierra |
| | `dig_emerge_delay` | 0.22 | segundos entre emerger y golpear |
| `scripts/fighters/Topo.gd` | `DIVE_TIME` | 0.42 | duración del hundimiento (animación) |
| | `EMERGE_END` | 0.42 | duración de la emersión |
| | `UNDER_MAX` | 2.0 | tope de seguridad bajo tierra |
| | `FALLBACK_FLOOR_Y` | 480 | altura del suelo si no encuentra uno |

## Likan · "Lluvia de rocas"

Archivos: `scripts/fighters/Likan.gd`, `scripts/effects/Rock.gd`, `scenes/effects/Rock.tscn`.

1. Likan alza los brazos (animación `special`).
2. A los `SPAWN_DELAY` (0.18 s) invoca `rock_count` rocas (5 por defecto). Una cae justo
   en la x del rival y las demás se reparten a sus lados en una franja de `rock_zone_width` px
   (siempre dentro del suelo del escenario: `ZONE_MIN_X`..`ZONE_MAX_X`).
3. Cada roca muestra una **sombra roja parpadeante** en su punto de impacto durante
   `special_windup` segundos (más `rock_gap_time` por cada roca anterior: así caen en
   orden aleatorio, una tras otra). Mientras tanto no hacen daño.
4. Luego cae a `rock_speed` px/s, **atraviesa las plataformas** y daña una sola vez a
   quien toque por el camino (también a quien esté sobre una plataforma). Se rompe en el
   suelo principal con chispas, sonido y temblor de cámara.

Cómo esquivarla: apartarse de las sombras (hay huecos entre rocas) o salir de la franja.
Likan no se daña a sí mismo.

| Archivo | Constante | Valor | Qué es |
|---|---|---|---|
| `Likan.gd` | `SPAWN_DELAY` / `TOTAL_TIME` | 0.18 / 0.42 | atados a la animación `special` (3 cuadros a 8 fps) |
| | `ZONE_MIN_X` / `ZONE_MAX_X` | 300 / 980 | límites donde pueden caer las rocas |
| | `JITTER` | 8 | variación aleatoria de la x de cada roca |
| `Rock.gd` | `RADIUS` | 20 | radio de la roca |
| | `SKY_Y` | -60 | altura de la que empieza a caer |
| | `SHAKE` | 5 | temblor de cámara al romperse |

## Aukin · "Tallarines enredadores"

Archivos: `scripts/fighters/Aukin.gd`, `scripts/effects/Noodles.gd`, `scenes/effects/Noodles.tscn`.
Los tallarines se **dibujan por código** (`_draw()` en `Noodles.gd`), no con SVG.

1. Aukin vierte tallarines hacia el suelo (animación `special`). Necesita un rival vivo.
2. A los `SPAWN_DELAY` hace brotar una columna de tallarines en el suelo o plataforma que
   hay bajo el rival (rayo hacia abajo desde el rival).
3. **WARN** (`special_windup`): solo asoman unas puntas que se retuercen, con polvo. Sin daño.
4. **RISE** (`noodle_rise_time`, 0.14 s): suben. Quien esté dentro de la zona (ancho
   `noodle_zone_width`, alto `noodle_height`) queda **atrapado**.
5. **HOLD** (`noodle_up_time`, 0.6 s): siguen arriba y **siguen atrapando** a quien entre en
   la zona mientras estén en pie. Cada atrapado queda inmovilizado (`Fighter.entangle()`)
   durante `noodle_hold_time` y recibe `noodle_squeezes` apretones que suman `special_damage`
   en total. Al terminar se le suelta (`release_entangle()`) y se le lanza con `special_knockback`.
   Quien ya fue atrapado y soltado no vuelve a serlo en ese mismo ataque.
6. **RETRACT** (`noodle_retract_time`, 0.3 s): los tallarines bajan solo cuando ya pasó
   `noodle_up_time` **y** ya soltaron a todos los atrapados.

Cómo esquivarla: salir de la zona durante el aviso, o estar más alto que `noodle_height`
(doble salto). Si el rival es invulnerable en ese instante, `take_hit()` devuelve `false` y no
queda atrapado (pero si deja de serlo mientras los tallarines siguen arriba, sí).

| Archivo | Constante | Valor | Qué es |
|---|---|---|---|
| `Aukin.gd` | `SPAWN_DELAY` / `TOTAL_TIME` | 0.18 / 0.42 | atados a la animación `special` (siguen en código) |
| `Noodles.gd` | `STRANDS`, `COLOR_*` | 6, amarillo | número de tiras y colores del dibujo (siguen en código) |

Altura, tiempos de subida, de permanencia y de bajada: en la ficha (`noodle_height`,
`noodle_rise_time`, `noodle_up_time`, `noodle_retract_time`). Ver [16](16_PARAMETROS_DE_HABILIDADES.md).

## Ñanco · "Humo de cigarro"

Archivos: `scripts/fighters/Nanco.gd`, `scripts/effects/SmokeCloud.gd`, `scenes/effects/SmokeCloud.tscn`.
(El id es `nanco`, sin la Ñ, porque los nombres de archivo van sin tildes; el nombre que se
ve, "Ñanco", está en `characters/nanco.tres`.)

1. Ñanco se lleva el cigarro a la boca y **fuma** `special_windup` segundos (animación
   `special`: se ve la brasa). Es el aviso.
2. Luego **sopla** una nube de humo delante de él (`smoke_length` px de largo, 100 px de alto)
   que dura `smoke_duration` segundos.
3. Quien esté dentro recibe `special_damage` **una sola vez** (con `special_knockback`) y además
   un **empujón continuo** hacia donde sopla: se le suma `smoke_push_accel` px/s de velocidad por
   segundo hasta un tope (`MAX_PUSH` 620). Se puede resistir caminando en contra, pero cuesta.
4. Si golpean a Ñanco mientras fuma, **no se corta**: sale volando, pero la nube sopla igual.

Cómo esquivarlo: saltar por encima de la nube, o estar a más de `smoke_length` px.

| Archivo | Constante | Valor | Qué es |
|---|---|---|---|
| `Nanco.gd` | `RECOVER_TIME` | 0.15 | segundos para recuperar el control tras soplar |
| `SmokeCloud.gd` | `START_OFFSET` | 34 | dónde empieza la nube, delante de su cara |
| | `HEIGHT` | 100 | alto de la nube |
| | `MAX_PUSH` | 620 | velocidad máxima que le da el empujón |
| | `FADE_TIME` | 0.35 | lo que tarda en disiparse |

## Winkul · "Pinchos al borde"

Archivos: `scripts/fighters/Winkul.gd`, `scripts/effects/Spike.gd`, `scenes/effects/Spike.tscn`.
Los pinchos se **dibujan por código** (`_draw()`).

1. Winkul alza las manos y las clava en el suelo (animación `special`).
2. A los `SPAWN_DELAY` (0.2 s) aparecen `spike_count` **grietas rojas** en el suelo, una cada
   `spike_spacing` px hacia donde mira (la primera a `START_OFFSET` = 90 px). Solo sale pincho
   donde hay suelo principal.
3. Cada grieta parpadea `special_windup` segundos (más `spike_gap_time` por cada una
   anterior: así los pinchos brotan en fila, uno tras otro). Sin daño.
4. Brotan los pinchos (64 px de alto), se quedan 0.35 s y se hunden. Quien los toca recibe
   `special_damage` **una vez por pincho** y sale lanzado **hacia la orilla**: hacia el borde del
   escenario más cercano (izquierda si está en la mitad izquierda, derecha si está en la derecha;
   el centro es `Config.SCREEN_SIZE.x / 2`).

Cómo esquivarlo: saltar por encima, subirse a una plataforma o quedarse fuera de la fila.

| Archivo | Constante | Valor | Qué es |
|---|---|---|---|
| `Winkul.gd` | `SPAWN_DELAY` / `TOTAL_TIME` | 0.2 / 0.42 | atados a la animación `special` |
| | `START_OFFSET` | 90 | distancia del primer pincho a Winkul |
| `Spike.gd` | `HEIGHT` / `HALF_WIDTH` | 64 / 22 | alto y medio ancho de cada pincho |
| | `UP_TIME` / `HOLD_TIME` / `RETRACT_TIME` | 0.07 / 0.35 / 0.2 | subida, permanencia y retirada |

## Jorge · "Caña de pescar"

Archivos: `scripts/fighters/Jorge.gd`, `scripts/effects/Hook.gd`, `scenes/effects/Hook.tscn`.
El anzuelo y la línea se **dibujan por código** (`_draw()`).

1. Jorge echa la caña hacia atrás (animación `special`). Es el aviso: `special_windup` segundos.
2. Lanza el **anzuelo** hacia donde mira, a `hook_speed` px/s y hasta `hook_range` px,
   a la altura del pecho.
3. Si toca a un rival (que no sea invulnerable) lo **engancha**: hace el 25 % de `special_damage`,
   lo inmoviliza (`Fighter.entangle()`) y lo recoge hasta quedar delante de Jorge en
   `hook_reel_time` segundos.
4. Jorge da un **tirón** (animación `throw`) y a los `THROW_DELAY` suelta al rival y lo lanza
   **por encima de su cabeza hacia el otro lado** (la x del empuje es la contraria a hacia donde
   mira Jorge). Eso hace el 75 % restante del daño.
5. Si el anzuelo no engancha a nadie, vuelve a la caña y Jorge queda un momento indefenso.
6. Si golpean a Jorge mientras el anzuelo está fuera, **el especial no se anula**: Jorge pierde el control un momento, pero el anzuelo sigue y el rival sigue enganchado. Y el anzuelo también engancha al volver.

Cómo esquivarlo: saltar por encima del anzuelo, o estar a más de `hook_range` px.

| Archivo | Constante | Valor | Qué es |
|---|---|---|---|
| `Jorge.gd` | `THROW_DELAY` / `THROW_TOTAL` | 0.12 / 0.32 | cuándo suelta al rival / duración del tirón (animación `throw`, 2 cuadros a 12 fps) |
| `Hook.gd` | `ROD_TIP` | (58, -24) | punta de la caña respecto a Jorge (debe coincidir con el dibujo) |
| | `FRONT_DISTANCE` | 56 | a qué distancia delante de Jorge queda el rival recogido |
| | `RETURN_SPEED` | 1500 | velocidad de vuelta si falla |
| | `GRAB_DAMAGE_SHARE` | 0.25 | parte del daño que hace el enganche |

## Cómo se reparte el daño de un especial

Todos los especiales usan la misma función `take_hit()` del luchador base. El empuje
final es `knockback * (1 + porcentaje / KNOCKBACK_GROWTH)`, así que el mismo especial
manda más lejos a un rival con más daño. Detalle en [09 · Configuración global](09_CONFIGURACION_GLOBAL.md).

## Crear una habilidad nueva

Si quieres un especial distinto, la forma más rápida es copiar la plantilla
`tools/plantillas/luchador.gd.txt` (un golpe con aviso que ya funciona) y cambiar
lo que hace en `_start_special()` y `_state_special()`.
El paso a paso completo está en [06 · Crear un personaje nuevo](06_CREAR_UN_PERSONAJE_NUEVO.md).

---

## Levaro · "Remazos"

Archivo: `scripts/fighters/Levaro.gd`.

1. Levaro alza el remo (animación `special`). Es el aviso: `special_windup` segundos.
2. Da `oar_swings` (3) remazos seguidos (animación `swing`). Antes de cada uno vuelve a alzar el remo
   (`oar_hit_delay`), así que cada golpe se puede esquivar: alejándose de `oar_reach`, saltando por encima de
   `oar_height` o pasando a su espalda. Los remazos hacen poco empuje: el rival queda aturdido a tiro del siguiente.
3. Remata con un **empujón** (animación `push`, tras `oar_push_delay` de aviso) que lanza al rival con `special_knockback`.
4. Si golpean a Levaro durante el especial, **no se anula** (como en los demás). Parámetros: `docs/16_PARAMETROS_DE_HABILIDADES.md` §12.

---

## JP · "Narizazo"

Archivo: `scripts/fighters/Jp.gd` (hereda de Levaro). Le crece una nariz larguísima: avisa (`special_windup`), da 3 estocadas
cuyo alcance crece en cada una (`nose_growth`) y remata con un empujón de alcance máximo. Se esquiva alejándose, saltando
o pasando a su espalda; si lo golpean no se anula. Parámetros: `docs/16_PARAMETROS_DE_HABILIDADES.md` §13.
