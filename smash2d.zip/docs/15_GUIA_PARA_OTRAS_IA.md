# 15 · Guía para otras IA y para personas nuevas

Proyecto: prototipo de lucha 2D en **Godot 3.5.3** (no Godot 4). Documentación completa en `docs/00_LEEME_PRIMERO.md`.

## Antes de cambiar nada

1. Lee `docs/03_ARQUITECTURA_DEL_CODIGO.md` (cómo se conectan las piezas).
2. Busca el cambio en la tabla de `docs/01_ESTRUCTURA_DEL_PROYECTO.md` ("Qué archivo tocar según lo que quieras").
3. Haz el cambio en **un solo lugar**. Si un número aparece en dos archivos, muévelo a `scripts/core/Config.gd` o a la ficha del personaje.

## Dónde vive cada cosa

| Cambio | Archivo |
|---|---|
| Velocidad, salto, daño, vidas, recarga de un personaje | `characters/<id>.tres` |
| Número global (KO, empuje, cámara, reaparición) | `scripts/core/Config.gd` |
| Comportamiento del especial | `scripts/fighters/<Clase>.gd` (funciones `_can_special`, `_start_special`, `_state_special`) |
| Golpe básico, daño, KO, estados | `scripts/fighters/Fighter.gd` |
| Partida, cuenta atrás, fin | `scripts/stage/Arena.gd` |
| Menús y selección | `scripts/ui/*.gd` y `scenes/ui/*.tscn` |
| Suelo y plataformas (dibujo) | `scenes/stages/*.tscn` (TileMap) y `tools/make_tileset.py` |
| Colisiones del suelo | `StaticBody2D` en `scenes/stages/*.tscn` (no el TileMap) |
| Lista de escenarios / elegir escenario | `Game.STAGES` y `scripts/ui/StageSelect.gd` |
| Teclas (cambiarlas, guardarlas) | `scripts/core/Keybinds.gd` y `scripts/ui/Controls.gd` |
| Aspecto y animación de botones | `resources/ui_theme.tres`, `scripts/ui/AnimButton.gd`, `tools/make_ui.py` |
| Especial de Likan / Aukin | `scripts/fighters/Likan.gd`, `Rock.gd` / `Aukin.gd`, `Noodles.gd` |
| Especial de Ñanco / Winkul | `scripts/fighters/Nanco.gd`, `SmokeCloud.gd` / `Winkul.gd`, `Spike.gd` |
| Especial de Jorge | `scripts/fighters/Jorge.gd`, `scripts/effects/Hook.gd` |
| Aspecto del suelo y plataformas | `tools/make_tileset.py` (sección PALETA) y `scripts/stage/StageTiles.gd` |
| Personaje nuevo | `python3 tools/nuevo_personaje.py <id> "<Nombre>"` |

## Reglas que no se deben romper

- **Daño:** siempre a través de `take_hit(daño, empuje, atacante)` del rival. Nunca restar `percent` a mano.
- **Especiales:** `_start_special()` debe poner `state = State.SPECIAL`, y `_state_special()` debe volver a `State.NORMAL`. Si no, el luchador queda bloqueado.
- **Stats en código:** dentro de un especial, lee `stats.<campo>` (la ficha), no constantes.
- **Números atados a animación** (`SPAWN_DELAY`, `DIVE_TIME`...) deben seguir la duración de la animación en `tools/make_sprites.py`. Si cambias cuadros o fps, revisa esas constantes.
- **Archivos generados:** los `.svg` y los `resources/*_frames.tres` salen de `tools/make_sprites.py`. Si cambias el dibujo, cambia el script y regenera, no edites el SVG a mano.
- **Capas de colisión:** usa las constantes de `Config` (`BIT_*`, `MASK_*`), no números sueltos.
- **En archivos `.tscn` escritos a mano:** en Godot 3 se usa `PoolRealArray`, no `PoolFloatArray`.
- **En recursos:** léelos con punto (`ficha.campo`), no con corchetes.

## Cómo verificar un cambio

```bash
godot --path . -s tools/test_headless.gd        # general
godot --path . -s tools/test_dodge_bugs.gd      # esquives y bugs del Topo
godot --path . -s tools/test_personajes.gd      # contrato de cada personaje
godot --path . -s tools/test_especiales_nuevos.gd  # Likan (rocas) y Aukin (tallarines)
godot --path . -s tools/test_nanco_winkul.gd       # Ñanco (humo) y Winkul (pinchos)
godot --path . -s tools/test_jorge.gd              # Jorge (caña de pescar)
```

Cada una debe terminar con `RESULTADO: 0 fallos`. Si cambiaste un personaje o una animación,
ejecuta sobre todo `test_personajes.gd`. Si cambiaste la arena o los menús, ejecuta `test_headless.gd`.
Antes de la primera ejecución, abre el proyecto una vez en Godot para que importe los recursos.

## Qué no hacer

- No borres `.import/` ni `*.import`: los genera Godot; si faltan, Godot los recrea.
- No pongas personajes en `characters/` que no sean fichas válidas: el juego los carga todos.
- No cambies `tools/plantillas/` sin revisar `nuevo_personaje.py`, que las usa con `{{MARCADORES}}`.
- Campos nuevos de una habilidad en `scripts/core/data/Data<Personaje>.gd` (los comunes en `CharacterData.gd`): si solo los lee un especial vía `stats.<campo>` basta con añadirlos ahí (con valor por defecto); si los usa `Fighter.gd` directamente, cópialos también en `Fighter.apply_data()`.
- Atrapar a un rival: usa `take_hit()` y, si devuelve `true`, `entangle(duración)`; suéltalo con `release_entangle()`.
