extends Control
# ============================================================================
#  CharSelect.gd  —  pantalla de selección de personajes (scenes/ui/CharSelect.tscn)
# ----------------------------------------------------------------------------
#  Contiene dos PickPanel (uno por jugador). Cada jugador elige con SUS teclas
#  (ver PickPanel.gd). Cuando los dos están "listos" guarda la elección en
#  Game.selected y pasa a la selección de escenario (StageSelect). En modo práctica el panel de P2 es un
#  muñeco que usa automáticamente el personaje siguiente al de P1.
#  Los personajes que aparecen salen de Game.ORDER (carpeta characters/).
# ============================================================================

onready var pick1 = $Margin/Col/Row/Pick1
onready var pick2 = $Margin/Col/Row/Pick2
onready var footer = $Margin/Col/Footer

var net_mode := false          # partida en red: cada jugador elige en su dispositivo
var local_pick = null          # el PickPanel que maneja ESTE dispositivo (en red)
var remote_pick = null         # el del otro jugador
var starting := false
var start_timer := 0.0


func _ready() -> void:
	Game.play_music(Game.SELECT_MUSIC)
	pick1.setup(1, Game.selected[0])
	pick2.setup(2, Game.selected[1])
	net_mode = Net.is_active() and not Game.practice
	if net_mode:
		_setup_net()
	elif Game.practice:
		pick2.lock_as_dummy()
		footer.text = "Práctica: el muñeco (P2) usa el otro personaje.   Esc: volver"
	else:
		footer.text = "Esc: volver al menú"


# En red: el panel de MI jugador (anfitrión = P1, cliente = P2) se maneja aquí y manda sus cambios al otro;
# el otro panel solo muestra lo que elige el otro dispositivo. Pasa a escenarios solo el anfitrión.
func _setup_net() -> void:
	local_pick = pick1 if Net.is_host() else pick2
	remote_pick = pick2 if Net.is_host() else pick1
	remote_pick.lock_as_remote("JUGADOR %d (en red)" % (2 if Net.is_host() else 1))
	local_pick.connect("changed", self, "_on_local_pick")
	Net.connect("peer_left", self, "_on_net_peer_left")
	if Net.is_host():
		Net.host_open_select()                               # el cliente salta a esta pantalla
		footer.text = "Tú eres P1 y eliges aquí; el otro jugador elige en su dispositivo.   Esc: volver"
	else:
		footer.text = "Elige tu personaje. Luego el anfitrión elige el escenario.   Esc: salir"
	Net.send_pick(local_pick.character_id(), local_pick.is_ready)   # el otro ve mi personaje desde el principio


func _on_local_pick(id: String, ready: bool) -> void:
	Net.send_pick(id, ready)


func _on_net_peer_left() -> void:
	Game.goto_menu()                                         # el otro se fue (Net.notice dice por qué)


func _process(delta: float) -> void:
	if net_mode:
		if Net.remote_char != "":
			remote_pick.apply_remote(Net.remote_char, Net.remote_ready)
		if Net.is_client():
			footer.text = "¡Listos! El anfitrión está eligiendo el escenario..." if (pick1.is_ready and pick2.is_ready) \
				else "Elige tu personaje. Luego el anfitrión elige el escenario.   Esc: salir"
			return                                           # el cliente espera: no avanza solo
	if Game.practice:
		pick2.set_index((pick1.index + 1) % Game.ORDER.size())
	if starting:
		start_timer -= delta
		if start_timer <= 0.0:
			Game.goto("res://scenes/ui/StageSelect.tscn")
		return
	if pick1.is_ready and pick2.is_ready:
		starting = true
		start_timer = 0.7
		Game.selected = [pick1.character_id(), pick2.character_id()]
		$SfxGo.play()
		$Banner.visible = true


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and not starting:
		Game.goto_menu()
