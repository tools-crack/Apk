extends Node
# ============================================================================
#  NetSync.gd  —  sincroniza la partida entre anfitrión y cliente
# ----------------------------------------------------------------------------
#  Lo crea Arena.gd cuando hay una partida en red (Net.is_active()).
#
#  ANFITRIÓN (P1, simula todo)
#    - Cada paso de física (60/s) copia en el luchador P2 los botones que mandó el
#      cliente (net_held / net_just).
#    - Al FINAL del paso (nodo "NetTail", último hijo de la arena) empaqueta el estado de
#      todo y se lo manda al cliente:  luchadores y efectos (anzuelo, rocas, nube...),
#      sus variables, su posición/animación y los sonidos que empezaron a sonar.
#
#  CLIENTE (P2, solo dibuja)
#    - Cada paso de física manda sus botones (los últimos 4 pasos, por si se pierde
#      algún paquete).
#    - Guarda los paquetes que llegan y los dibuja con ~2 pasos (33 ms) de retraso,
#      interpolando la posición entre dos paquetes: así se ve fluido aunque el WiFi
#      entregue los paquetes a destiempo. Los luchadores y efectos del cliente son
#      "fantasmas": no simulan nada (ni daño ni física), solo copian al anfitrión.
#
#  Qué se copia (en vez de escribirlo a mano para cada habilidad):
#    - propiedades de nodos: visible, modulate, position, rotation, scale, z_index,
#      animación/frame de los sprites, emitting de las partículas
#    - TODAS las variables del script de cada luchador/efecto (los nodos se mandan
#      como su id de red y los recursos como su ruta)
#    - sonidos: un evento cuando un AudioStreamPlayer empieza o se reinicia
#  Así una habilidad nueva se replica sola, sin tocar este archivo.
#
#  Los paquetes de estado van sin garantía de entrega (unreliable): si uno se pierde, el
#  siguiente (1/60 s después) lo reemplaza. Los eventos de sonido viajan repetidos en los
#  últimos paquetes y el cliente descarta los que ya reprodujo.
# ============================================================================

const ACTIONS := ["left", "right", "jump", "down", "attack", "special"]   # = Fighter.NET_ACTIONS
const INTERP_MIN := 1.0            # retraso mínimo al dibujar (pasos de 1/60 s) cuando la red va estable
const INTERP_MAX := 4.0            # retraso máximo cuando el WiFi va a tirones
const INTERP_START := 2.0          # retraso inicial, hasta medir la red
const HIST := 4                    # cuántos pasos de botones viajan en cada paquete
const MAX_EVENTS := 12             # eventos de sonido que viajan en cada paquete
const SNAP_KEEP := 30              # paquetes de estado que guarda el cliente
const TELEPORT_DIST := 400.0       # si un nodo salta más que esto entre paquetes (reaparecer) no se interpola
# Variables de los luchadores que NO se copian (son del propio dispositivo)
const EXCLUDE := ["net_remote", "net_held", "net_just", "net_puppet"]

var tail := false                  # true = es el nodo "NetTail" (el que manda el estado al final del paso)
var head = null                    # (en NetTail) el NetSync principal
var arena = null
var fighters_root = null
var fighters := []
var is_host := false
var debug_bytes := 0               # tamaño del último paquete de estado (solo si debug_stats)
var debug_parts := []              # [id, bytes de propiedades, bytes de variables, nº de nodos, escena] por entidad
var debug_stats := false

var _nodes := {}                   # id de red -> nodo (0 = arena, 1/2 = luchadores, >=100 = efectos)
var _arena_audio := []
var _var_cache := {}               # script -> nombres de variables a copiar

# --- anfitrión
var _next_id := 100
var _info := {}                    # instance_id -> info de la entidad
var _aprev := {}                   # (entidad*100+i) -> posición de reproducción del sonido (-1 = no suena)
var _event_seq := 0
var _events := []
var _snap_frame := 0
var _in_frame := -1
var _pending_just := 0
var _remote_held := 0

# --- cliente
var _cinfo := {}                   # id -> info
var _snaps := {}                   # paso -> paquete de estado
var _latest := -1
var _render_f := -1.0
var _last_applied := -9999
var _last_event := 0
var _cframe := 0
var _hist := []
var _interp := INTERP_START        # retraso de dibujo actual (se adapta a la red: menos lag si va estable)
var _off_min := 1e9                # menor (llegada - paso/60) visto: lo más rápido que llega un paquete
var _jitter := 0.0                 # cuánto se atrasan los paquetes sobre ese mínimo (en pasos), con memoria que decae


# La llama Arena.gd justo después de crear a los dos luchadores.
func setup(arena_node, fighters_node, fighter_list: Array) -> void:
	arena = arena_node
	fighters_root = fighters_node
	fighters = fighter_list
	is_host = Net.is_host()
	_nodes[0] = arena
	for i in range(fighters.size()):
		var f = fighters[i]
		f.set_meta("net_id", i + 1)
		_nodes[i + 1] = f
		_cinfo[i + 1] = _make_info(f, i + 1)
	for c in arena.get_children():
		if c is AudioStreamPlayer:
			_arena_audio.append(c)
	if is_host:
		fighters[1].net_remote = true               # P2 lo maneja el cliente
	else:
		for f in fighters:
			f.net_make_puppet()
	if not tail:
		var t = Node.new()
		t.set_script(get_script())
		t.tail = true
		t.head = self
		t.name = "NetTail"
		arena.add_child(t)                          # último hijo: corre DESPUÉS de los luchadores


func _physics_process(_delta: float) -> void:
	if tail:
		if head != null:
			head.tail_step()
		return
	if is_host:
		var p2 = fighters[1]
		p2.net_held = _remote_held                  # los botones del cliente para este paso
		p2.net_just = _pending_just
		_pending_just = 0
	else:
		_client_send()


# ============================================================================
#  BOTONES  (cliente -> anfitrión)
# ============================================================================
func _client_send() -> void:
	var pre = "p%d_" % Net.local_player()
	var held := 0
	var pressed := 0
	for i in range(ACTIONS.size()):
		if Input.is_action_pressed(pre + ACTIONS[i]):
			held |= 1 << i
		if Input.is_action_just_pressed(pre + ACTIONS[i]):
			pressed |= 1 << i
	_hist.push_front(pressed)
	if _hist.size() > HIST:
		_hist.pop_back()
	_cframe += 1
	rpc_unreliable_id(1, "recv_input", _cframe, held, _hist)


remote func recv_input(frame: int, held: int, hist: Array) -> void:
	if not is_host or tail or frame <= _in_frame:
		return
	var n = int(min(hist.size(), frame - _in_frame))           # los pasos que aún no habíamos visto
	for i in range(n):
		_pending_just |= int(hist[i])                           # las pulsaciones no se pierden aunque falle un paquete
	_in_frame = frame
	_remote_held = held


# ============================================================================
#  ESTADO  (anfitrión -> cliente)
# ============================================================================
func tail_step() -> void:
	if not is_host or not Net.client_ready or Net.peer_id == 0:
		return
	_snap_frame += 1
	_scan_players(0, _arena_audio)
	var ents := []
	for n in fighters_root.get_children():
		if n.is_queued_for_deletion():
			continue
		var inf = _host_info(n)
		if inf == null:
			continue
		_scan_players(inf["id"], inf["audio"])
		ents.append(_pack(n, inf))
	var snap := {"e": Net.epoch, "f": _snap_frame, "n": ents, "a": _arena_vals(), "v": _events}
	if debug_stats:
		debug_bytes = var2bytes(snap).size()
		debug_parts = []
		for e in ents:
			debug_parts.append([e[0], var2bytes(e[3]).size(), var2bytes(e[4]).size(), e[2], str(e[1]).get_file()])
	rpc_unreliable_id(Net.peer_id, "recv_snap", snap)
	if _snap_frame % 120 == 0:
		for k in _info.keys():                                  # olvida entidades que ya no existen
			if not is_instance_valid(_info[k]["node"]):
				_info.erase(k)


func _host_info(n):
	var key = n.get_instance_id()
	if _info.has(key):
		return _info[key]
	var id = -1
	if n.has_meta("net_id"):
		id = n.get_meta("net_id")
	elif n.filename != "":
		id = _next_id
		_next_id += 1
		n.set_meta("net_id", id)
		_nodes[id] = n
	if id < 0:
		return null                                             # nodo sin escena: no se replica
	var inf = _make_info(n, id)
	_info[key] = inf
	return inf


func _make_info(n, id: int) -> Dictionary:
	var all := [n]
	var audio := []
	_collect(n, all, audio)
	var plist := []
	var total := 0
	for x in all:
		var names = _props_for(x)
		plist.append(names)
		total += names.size()
	return {"id": id, "node": n, "all": all, "plist": plist, "total": total, "audio": audio,
			"names": _var_names(n), "fn": n.filename}


func _collect(n, all: Array, audio: Array) -> void:
	for c in n.get_children():
		if c is AudioStreamPlayer or c is AudioStreamPlayer2D:
			audio.append(c)
		elif c is CanvasItem and not (c is Control) and not (c is Area2D):
			all.append(c)
		_collect(c, all, audio)


func _props_for(n) -> Array:
	var p := []
	if n is CanvasItem:
		p += ["visible", "modulate"]
	if n is Node2D:
		p += ["position", "rotation", "scale", "z_index"]
	if n is AnimatedSprite:
		p += ["animation", "frame", "flip_h"]
	elif n is Sprite:
		p += ["flip_h", "flip_v", "frame"]
	if n is CPUParticles2D:
		p += ["emitting"]
	return p


func _var_names(n) -> Array:
	var s = n.get_script()
	if s != null and _var_cache.has(s):
		return _var_cache[s]
	var names := []
	for p in n.get_property_list():
		if (int(p["usage"]) & PROPERTY_USAGE_SCRIPT_VARIABLE) != 0 and not (p["name"] in EXCLUDE):
			names.append(p["name"])
	if s != null:
		_var_cache[s] = names
	return names


func _pack(n, inf: Dictionary) -> Array:
	var props := []
	for i in range(inf["all"].size()):
		var x = inf["all"][i]
		if is_instance_valid(x):
			for name in inf["plist"][i]:
				props.append(x.get(name))
		else:
			for name in inf["plist"][i]:
				props.append(null)
	# Variables: completas los primeros pasos de la entidad y cada 30 pasos; entre medias solo las que cambiaron.
	if not inf.has("born"):
		inf["born"] = _snap_frame
		inf["last"] = []
		inf["chg"] = []
	var names: Array = inf["names"]
	var cur := []
	for name in names:
		cur.append(_enc(n.get(name)))
	var last: Array = inf["last"]
	var chg: Array = inf["chg"]
	if last.size() != cur.size():
		last = []
		chg = []
		for i in range(cur.size()):
			last.append(cur[i])
			chg.append(_snap_frame)
	else:
		for i in range(cur.size()):
			if cur[i] != last[i]:
				last[i] = cur[i]
				chg[i] = _snap_frame
	inf["last"] = last
	inf["chg"] = chg
	var full = (_snap_frame - inf["born"] < 6) or (_snap_frame % 30 == 0)
	var vals
	if full:
		vals = cur
	else:
		vals = {}
		for i in range(cur.size()):
			if chg[i] > _snap_frame - 6:
				vals[i] = cur[i]
	return [inf["id"], inf["fn"] if full else "", inf["all"].size(), props, vals]


func _arena_vals() -> Array:
	return [arena.shake_amount, arena.message.text, arena.get_node("HUD/EndHint").visible, arena.over]


# Convierte un valor a algo que viaja por la red: nodos -> {"n": id}, recursos -> {"r": ruta}.
# Lo que no se puede mandar (un Tween, un material...) se convierte en null y el cliente lo ignora.
func _enc(v):
	match typeof(v):
		TYPE_OBJECT:
			if not is_instance_valid(v):
				return null
			if v is Node and v.has_meta("net_id"):
				return {"n": v.get_meta("net_id")}
			if v is Resource and v.resource_path != "":
				return {"r": v.resource_path}
			return null
		TYPE_ARRAY:
			var a := []
			for e in v:
				a.append(_enc(e))
			return a
		TYPE_DICTIONARY:
			var d := {}
			for k in v:
				d[k] = _enc(v[k])
			return d
	return v


func _dec(v):
	match typeof(v):
		TYPE_DICTIONARY:
			if v.size() == 1 and v.has("n"):
				var n = _nodes.get(v["n"])
				return n if (n != null and is_instance_valid(n)) else null
			if v.size() == 1 and v.has("r"):
				return load(v["r"])
			var d := {}
			for k in v:
				d[k] = _dec(v[k])
			return d
		TYPE_ARRAY:
			var a := []
			for e in v:
				a.append(_dec(e))
			return a
	return v


# ---------------------------------------------------------------- sonidos
func _scan_players(ent: int, players: Array) -> void:
	for i in range(players.size()):
		var p = players[i]
		if not is_instance_valid(p):
			continue
		var key = ent * 100 + i
		var pos = p.get_playback_position() if p.playing else -1.0
		var prev = _aprev.get(key, -1.0)
		if p.playing and (prev < 0.0 or pos + 0.003 < prev):     # empezó ahora o se reinició
			_event_seq += 1
			_events.append([_event_seq, _snap_frame, ent, i, p.pitch_scale])
			if _events.size() > MAX_EVENTS:
				_events.pop_front()
		_aprev[key] = pos


# ============================================================================
#  CLIENTE: recibir y dibujar
# ============================================================================
remote func recv_snap(snap: Dictionary) -> void:
	if is_host or tail or snap.get("e", -1) != Net.epoch:
		return                                                   # de otra partida (revancha) o no me toca
	var f: int = snap["f"]
	_snaps[f] = snap
	if f > _latest:
		_latest = f
	_measure(f)


# Mide cuánto se atrasan los paquetes respecto al más rápido y ajusta el retraso de dibujo:
# con red estable baja a ~1 paso (menos lag); si hay tirones sube hasta INTERP_MAX para que no se vea a saltos.
func _measure(f: int) -> void:
	var off = OS.get_ticks_usec() / 1000000.0 - f / 60.0
	if off < _off_min:
		_off_min = off
	else:
		_off_min += 0.00005                                      # el mínimo sube muy despacio (por si los relojes se desfasan)
	var late = (off - _off_min) * 60.0                           # atraso de este paquete, en pasos
	_jitter = max(late, _jitter * 0.992)                         # sube de golpe, baja despacio
	var want = clamp(INTERP_MIN + _jitter * 1.1, INTERP_MIN, INTERP_MAX)
	_interp += (want - _interp) * (0.2 if want > _interp else 0.02)   # sube rápido, baja despacio


func _process(delta: float) -> void:
	if tail or is_host or _latest < 0:
		return
	var target = float(_latest) - _interp
	if _render_f < 0.0:
		_render_f = target
	_render_f += delta * 60.0                                    # el reloj de dibujo avanza solo...
	var err = target - _render_f
	if abs(err) > 6.0:
		_render_f = target                                       # ...y se corrige suavemente hacia el último paquete
	else:
		_render_f += err * 0.05
	var fa = int(floor(_render_f))
	var frac = _render_f - fa
	var sa = _pick(fa)
	if sa == null:
		return
	if sa["f"] != fa:
		frac = 0.0                                               # falta ese paquete: se mantiene el anterior
	var sb = _snaps.get(sa["f"] + 1)
	_sync_entities(sa)
	var fresh = sa["f"] != _last_applied
	_apply(sa, sb, frac, fresh)
	if fresh:
		_last_applied = sa["f"]
		_apply_arena(sa["a"])
	_play_events(fa)
	for k in _snaps.keys():
		if k < fa - SNAP_KEEP:
			_snaps.erase(k)


func _pick(fa: int):
	for k in range(0, 8):
		if _snaps.has(fa - k):
			return _snaps[fa - k]
	var best = null
	for k in _snaps.keys():
		if k > fa and (best == null or k < best):
			best = k
	return _snaps[best] if best != null else null


func _sync_entities(sa: Dictionary) -> void:
	var present := {}
	for e in sa["n"]:
		var id: int = e[0]
		present[id] = true
		if id >= 100 and (not _nodes.has(id) or not is_instance_valid(_nodes[id])) and typeof(e[4]) == TYPE_ARRAY and e[1] != "":
			_spawn(e)
	for id in _nodes.keys():
		if id >= 100 and not present.has(id):
			var n = _nodes[id]
			if is_instance_valid(n):
				n.queue_free()
			_nodes.erase(id)
			_cinfo.erase(id)


func _spawn(e: Array) -> void:
	var scene = load(e[1])
	if scene == null:
		return
	var n = scene.instance()
	var id: int = e[0]
	n.set_meta("net_id", id)
	_nodes[id] = n
	var inf = _make_info(n, id)
	_cinfo[id] = inf
	_apply_vars(n, inf, e[4])                                    # (antes de add_child: así _ready() ya ve stats, shooter...)
	_disable_areas(n)
	fighters_root.add_child(n)
	n.set_physics_process(false)                                 # DESPUÉS de add_child: algunos _ready() lo reactivan
	n.set_process(false)
	for p in inf["audio"]:
		p.stop()                                                 # el sonido lo manda el anfitrión con eventos
	for x in inf["all"]:
		if x is AnimatedSprite:
			x.playing = false                                    # el frame lo manda el anfitrión


func _disable_areas(n) -> void:
	if n is Area2D:
		n.monitoring = false
		n.monitorable = false
	for c in n.get_children():
		_disable_areas(c)


func _apply(sa: Dictionary, sb, frac: float, fresh: bool) -> void:
	var by_id := {}
	if sb != null and frac > 0.0:
		for e in sb["n"]:
			by_id[e[0]] = e
	for e in sa["n"]:
		var id: int = e[0]
		var inf = _cinfo.get(id)
		if inf == null or not is_instance_valid(inf["node"]):
			continue
		if e[2] != inf["all"].size() or e[3].size() != inf["total"]:
			continue                                             # distinta estructura de nodos: no arriesgar
		var eb = by_id.get(id)
		_apply_props(inf, e[3], eb[3] if (eb != null and eb[3].size() == e[3].size()) else null, frac)
		if fresh:
			_apply_vars_upto(id, inf, sa["f"])
			if inf["node"] is CanvasItem:
				inf["node"].update()                             # redibuja lo que se dibuja con _draw (tallarines, anzuelo...)
			if inf["node"].has_method("_tick_fx"):
				inf["node"]._tick_fx(0.0)                        # destello / disolución del luchador


func _apply_props(inf: Dictionary, pa: Array, pb, frac: float) -> void:
	var idx := 0
	for i in range(inf["all"].size()):
		var n = inf["all"][i]
		var names: Array = inf["plist"][i]
		if not is_instance_valid(n):
			idx += names.size()
			continue
		for name in names:
			var v = pa[idx]
			if pb != null and (name == "position" or name == "scale" or name == "rotation"):
				var w = pb[idx]
				if typeof(v) == TYPE_VECTOR2 and typeof(w) == TYPE_VECTOR2:
					if v.distance_to(w) < TELEPORT_DIST:
						v = v.linear_interpolate(w, frac)
				elif typeof(v) == TYPE_REAL and typeof(w) == TYPE_REAL:
					v = lerp_angle(v, w, frac)
			if v != null:
				n.set(name, v)
			idx += 1


# Aplica en orden todos los paquetes desde el último aplicado (así no se pierde ningún cambio de variable).
func _apply_vars_upto(id: int, inf: Dictionary, f: int) -> void:
	var start = _last_applied + 1
	if start < f - 8:
		start = f - 8
	for k in range(start, f + 1):
		var s = _snaps.get(k)
		if s == null:
			continue
		for e in s["n"]:
			if e[0] == id:
				_apply_vars(inf["node"], inf, e[4])
				break


func _apply_vars(n, inf: Dictionary, vals) -> void:
	var names: Array = inf["names"]
	if typeof(vals) == TYPE_ARRAY:
		if vals.size() != names.size():
			return
		for i in range(names.size()):
			_set_var(n, names[i], vals[i])
	else:
		for i in vals.keys():
			if i < names.size():
				_set_var(n, names[i], vals[i])


func _set_var(n, name: String, v) -> void:
	if v == null:
		return
	var d = _dec(v)
	if d == null:
		return
	n.set(name, d)


func _apply_arena(a: Array) -> void:
	arena.shake_amount = max(arena.shake_amount, a[0])
	arena.message.text = a[1]
	arena.get_node("HUD/EndHint").visible = a[2]
	arena.over = a[3]


func _play_events(fa: int) -> void:
	var snap = _snaps.get(_latest)
	if snap == null:
		return
	for ev in snap["v"]:
		if ev[0] <= _last_event:
			continue
		if ev[1] > fa:
			break                                                # todavía no toca (van en orden)
		_last_event = ev[0]
		var players: Array = _arena_audio
		if ev[2] != 0:
			var inf = _cinfo.get(ev[2])
			if inf == null:
				continue
			players = inf["audio"]
		if ev[3] < players.size() and is_instance_valid(players[ev[3]]):
			players[ev[3]].pitch_scale = ev[4]
			players[ev[3]].play()
