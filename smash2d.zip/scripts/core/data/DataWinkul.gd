class_name DataWinkul
extends "res://scripts/core/CharacterData.gd"
# Ficha de Winkul · Pinchos al borde.
# Solo aparecen aquí los campos de ESTA habilidad (más los comunes de CharacterData). Documentación: docs/16_PARAMETROS_DE_HABILIDADES.md

export(int, 1, 20) var spike_count := 6                    # cuántos grupos de pinchos salen
export(float, 0, 400, 5) var spike_spacing := 80.0         # separación (px) entre grupos
export(float, 0, 3, 0.01) var spike_gap_time := 0.09       # segundos entre un grupo y el siguiente
export(float, 0, 400, 5) var spike_start_offset := 90.0    # distancia (px) del primer grupo a Winkul
export(float, 10, 300, 2) var spike_height := 64.0         # alto de los pinchos (px)
export(float, 5, 80, 1) var spike_half_width := 22.0       # semiancho (px) de cada grupo
export(float, 0, 3, 0.01) var spike_spawn_delay := 0.2     # segundos desde el inicio hasta que aparecen las grietas
export(float, 0, 3, 0.01) var spike_total_time := 0.42     # segundos hasta que Winkul recupera el control
export(float, 0, 2, 0.01) var spike_up_time := 0.07        # segundos que tardan en salir
export(float, 0, 3, 0.01) var spike_hold_time := 0.35      # segundos que se quedan arriba
export(float, 0, 2, 0.01) var spike_retract_time := 0.2    # segundos que tardan en hundirse
export(float, 0, 20, 0.5) var spike_shake := 3.0           # temblor de cámara al salir
