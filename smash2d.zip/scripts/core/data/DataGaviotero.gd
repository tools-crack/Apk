class_name DataGaviotero
extends "res://scripts/core/CharacterData.gd"
# Ficha de Gaviotero · Gaviota veloz.
# Solo aparecen aquí los campos de ESTA habilidad (más los comunes de CharacterData). Documentación: docs/16_PARAMETROS_DE_HABILIDADES.md

export(float, 0, 2000, 10) var gull_speed := 470.0         # velocidad de la gaviota (px/s)
export(float, 0, 2, 0.01) var gull_recover_time := 0.24    # segundos que Gaviotero tarda en recuperar el control tras soltar la gaviota
export(float, -2000, 0, 10) var gull_left_limit := -240.0  # la gaviota desaparece al pasar este límite (x)
export(float, 0, 4000, 10) var gull_right_limit := 1520.0  # la gaviota desaparece al pasar este límite (x)
export(float, 0, 400, 5) var gull_spawn_ahead := 90.0      # distancia (px) delante de Gaviotero a la que aparece
export(float, 0, 60, 1) var gull_bob := 10.0               # amplitud del vaivén vertical (px)
export(float, 0, 1, 0.01) var gull_fade_in := 0.12         # segundos del fundido de aparición (solo visual)
