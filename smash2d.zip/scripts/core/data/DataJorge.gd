class_name DataJorge
extends "res://scripts/core/CharacterData.gd"
# Ficha de Jorge · Caña de pescar.
# Solo aparecen aquí los campos de ESTA habilidad (más los comunes de CharacterData). Documentación: docs/16_PARAMETROS_DE_HABILIDADES.md

export(float, 0, 2000, 10) var hook_speed := 760.0         # velocidad del anzuelo al volar (px/s)
export(float, 0, 1200, 10) var hook_range := 420.0         # alcance máximo del anzuelo (px)
export(float, 0, 3, 0.01) var hook_reel_time := 0.25       # segundos que tarda en recoger al rival
export(float, 100, 5000, 50) var hook_return_speed := 1500.0  # velocidad (px/s) con la que vuelve si falla
export(float, 0, 1, 0.01) var hook_throw_delay := 0.12     # segundos del tirón hasta que suelta al rival (animación)
export(float, 0.05, 2, 0.01) var hook_throw_total := 0.32  # duración total del tirón (animación)
export(float, 0, 200, 2) var hook_front_distance := 56.0   # distancia (px) delante de Jorge donde queda el rival recogido
export(float, 0, 1, 0.05) var hook_grab_share := 0.25         # parte del daño que hace al enganchar (el resto, al lanzar)
export(float, 0, 5, 0.1) var hook_hold_buffer := 1.0          # segundos extra de inmovilización por seguridad
