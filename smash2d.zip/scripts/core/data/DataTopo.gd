class_name DataTopo
extends "res://scripts/core/CharacterData.gd"
# Ficha de Topo · Excavación sorpresa.
# Solo aparecen aquí los campos de ESTA habilidad (más los comunes de CharacterData). Documentación: docs/16_PARAMETROS_DE_HABILIDADES.md

export(float, 0, 2000, 10) var dig_speed := 520.0          # velocidad del montículo bajo tierra (px/s)
export(float, 0, 3, 0.01) var dig_emerge_delay := 0.22     # segundos entre que emerge y golpea (tiempo para reaccionar)
export(float, 0.05, 3, 0.01) var dig_dive_time := 0.42     # segundos de la animación de zambullida (bajo tierra, antes de emerger)
export(float, 0.05, 3, 0.01) var dig_emerge_end := 0.42    # segundos hasta que el Topo recupera el control tras emerger
export(float, 0, 2000, 10) var dig_fallback_floor_y := 480.0  # altura (y) del suelo si no se encuentra suelo bajo el Topo
export(float, 0.5, 6, 0.1) var dig_under_max := 2.0        # tope de seguridad (s) si el montículo no llega al rival
