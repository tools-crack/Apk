class_name DataLevaro
extends "res://scripts/core/CharacterData.gd"
# Ficha de Levaro · Remazos.
# Solo aparecen aquí los campos de ESTA habilidad (más los comunes de CharacterData). Documentación: docs/16_PARAMETROS_DE_HABILIDADES.md

export(int, 1, 10) var oar_swings := 3                      # cuántos remazos seguidos antes del empujón
export(float, 0, 300, 5) var oar_reach := 100.0             # alcance (px) del remo, delante de Levaro
export(float, 0, 300, 5) var oar_height := 70.0             # altura (px) de la zona de golpe (arriba y abajo de Levaro)
export(float, 0.1, 2, 0.01) var oar_swing_time := 0.34      # segundos que dura cada remazo (de levantar el remo a levantarlo otra vez)
export(float, 0, 1, 0.01) var oar_hit_delay := 0.16         # segundos desde que levanta el remo hasta que cae el golpe (aviso de cada remazo)
export(float, 0, 1, 0.05) var oar_swing_share := 0.55       # parte de special_damage que reparten los remazos (el resto es el empujón)
export var oar_swing_knockback := Vector2(40, -30)          # empuje de cada remazo (pequeño: el rival queda a tiro del siguiente)
export(float, 0, 2, 0.01) var oar_push_delay := 0.3         # segundos de aviso antes del empujón final
export(float, 0.05, 2, 0.01) var oar_push_total := 0.55     # segundos que dura el empujón (hasta recuperar el control)
