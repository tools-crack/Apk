class_name DataLikan
extends "res://scripts/core/CharacterData.gd"
# Ficha de Likan · Lluvia de rocas.
# Solo aparecen aquí los campos de ESTA habilidad (más los comunes de CharacterData). Documentación: docs/16_PARAMETROS_DE_HABILIDADES.md

export(float, 0, 2000, 10) var rock_speed := 900.0         # velocidad de caída de cada roca (px/s)
export(int, 1, 20) var rock_count := 5                     # cuántas rocas caen
export(float, 0, 1200, 10) var rock_zone_width := 540.0    # ancho (px) de la franja donde caen, centrada en el rival
export(float, 0, 3, 0.01) var rock_gap_time := 0.2         # segundos entre una roca y la siguiente
export(float, 0, 3, 0.01) var rock_spawn_delay := 0.18     # segundos desde el inicio hasta que invoca las rocas (animación)
export(float, 0, 3, 0.01) var rock_total_time := 0.42      # segundos hasta que Likan recupera el control (debe ser >= rock_spawn_delay)
export(float, -2000, 4000, 10) var rock_zone_min_x := 300.0  # límite izquierdo (x) donde pueden caer las rocas
export(float, -2000, 4000, 10) var rock_zone_max_x := 980.0  # límite derecho (x) donde pueden caer las rocas
export(float, -2000, 0, 10) var rock_sky_y := -60.0        # altura (y) desde la que empiezan a caer las rocas
export(float, 0, 3000, 10) var rock_no_floor_y := 760.0    # si no hay suelo bajo una roca, cae hasta esta altura (y)
export(float, 0, 3, 0.05) var rock_linger := 0.8           # segundos que la roca sigue viva tras romperse (deja sonar)
export(float, 0, 30, 0.5) var rock_shake := 5.0            # temblor de cámara al caer
export(float, 0, 60, 1) var rock_jitter := 8.0             # variación aleatoria (px) en la x de cada roca
