class_name DataJp
extends "res://scripts/core/data/DataLevaro.gd"
# Ficha de JP · Narizazo (usa los campos oar_* de Levaro y añade nose_growth).
# Solo aparecen aquí los campos de ESTA habilidad (más los comunes de CharacterData). Documentación: docs/16_PARAMETROS_DE_HABILIDADES.md

export(float, 0, 100, 1) var nose_growth := 18.0            # px que crece el alcance de la nariz en cada estocada (el empujón final llega más lejos)
