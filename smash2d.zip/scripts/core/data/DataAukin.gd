class_name DataAukin
extends "res://scripts/core/CharacterData.gd"
# Ficha de Aukin · Tallarines enredadores.
# Solo aparecen aquí los campos de ESTA habilidad (más los comunes de CharacterData). Documentación: docs/16_PARAMETROS_DE_HABILIDADES.md

export(float, 0, 1200, 10) var noodle_zone_width := 96.0   # ancho (px) de la zona de tallarines
export(int, 1, 20) var noodle_squeezes := 3                # apretones (golpes) mientras lo tienen atrapado; reparten special_damage
export(float, 0, 3, 0.01) var noodle_hold_time := 0.9      # segundos que el rival queda atrapado
export(float, 30, 400, 5) var noodle_height := 130.0       # altura (px) de los tallarines y de la zona de agarre
export(float, 0.02, 1, 0.01) var noodle_rise_time := 0.14  # segundos que tardan en subir
export(float, 0.1, 5, 0.05) var noodle_up_time := 0.6      # segundos que se quedan arriba (siguen atrapando a quien entre)
export(float, 0, 3, 0.01) var noodle_spawn_delay := 0.18   # segundos desde el inicio hasta que brotan (animación)
export(float, 0, 3, 0.01) var noodle_total_time := 0.42    # segundos hasta que Aukin recupera el control
export(float, 0.05, 2, 0.01) var noodle_retract_time := 0.3  # segundos que tardan en bajar
