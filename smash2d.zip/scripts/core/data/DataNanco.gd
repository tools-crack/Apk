class_name DataNanco
extends "res://scripts/core/CharacterData.gd"
# Ficha de Ñanco · Humo de cigarro.
# Solo aparecen aquí los campos de ESTA habilidad (más los comunes de CharacterData). Documentación: docs/16_PARAMETROS_DE_HABILIDADES.md

export(float, 0, 1200, 10) var smoke_length := 280.0       # largo (px) de la nube
export(float, 0, 3, 0.01) var smoke_duration := 0.5        # segundos que dura la nube
export(float, 0, 6000, 50) var smoke_push_accel := 2200.0  # empuje continuo (px/s por segundo) a quien esté dentro
export(float, 0, 400, 5) var smoke_start_offset := 34.0    # dónde empieza la nube, delante de Ñanco (px)
export(float, 0, 300, 5) var smoke_height := 100.0         # alto de la nube (px)
export(float, 0, 2000, 10) var smoke_max_push := 620.0     # velocidad horizontal máxima que da el empujón
export(float, 0, 2, 0.01) var smoke_recover_time := 0.15   # segundos que Ñanco tarda en recuperar el control tras soplar
export(float, 0, 2, 0.05) var smoke_fade_time := 0.35      # segundos que tarda en disiparse
