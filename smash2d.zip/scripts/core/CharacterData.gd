class_name CharacterData
extends Resource
# ============================================================================
#  CharacterData.gd  —  la "ficha" de un personaje
# ----------------------------------------------------------------------------
#  Cada personaje tiene un archivo characters/<id>.tres de este tipo. Ábrelo en
#  el Inspector de Godot (doble clic sobre el .tres): ahí cambias nombre, color,
#  retrato, velocidad, salto, daño, vidas y parámetros del especial SIN tocar
#  código.
#
#  Game.gd detecta solo todos los .tres de la carpeta characters/ (excepto los
#  que empiezan con "_"), así que para añadir un personaje basta con crear su
#  .tres (ver docs/06_CREAR_UN_PERSONAJE_NUEVO.md).
#
#  Los valores de aquí se copian al luchador en Fighter.apply_data().
# ============================================================================

# ------------------------------------------------------------------ Identidad
export var id := ""                        # nombre interno, p. ej. "topo". Si lo dejas vacío se usa el nombre del archivo.
export var order := 100                    # posición en la selección de personajes (menor = más a la izquierda)
export var display_name := "Luchador"      # nombre que se ve en menús y en el HUD
export var special_name := "Especial"      # nombre de la habilidad especial
export(String, MULTILINE) var description := ""   # texto explicativo en la pantalla de selección
export var color := Color.white            # color de marcos, nombre y HUD
export(Texture) var portrait               # imagen grande de la selección
export(PackedScene) var scene              # escena del luchador (scenes/fighters/*.tscn)

# ----------------------------------------------------------------- Movimiento
export(float, 50, 800, 5) var move_speed := 300.0          # velocidad máxima al correr (px/s)
export(float, 200, 6000, 50) var accel := 2600.0           # aceleración en el suelo
export(float, 200, 6000, 50) var air_accel := 1500.0       # aceleración en el aire
export(float, 200, 1400, 10) var jump_speed := 720.0       # fuerza del salto
export(float, 400, 4000, 50) var gravity := 1800.0         # gravedad
export(float, 200, 2000, 50) var max_fall_speed := 1000.0  # velocidad máxima de caída
export(int, 0, 5) var max_air_jumps := 1                   # saltos extra en el aire (1 = doble salto)

# ------------------------------------------------------------ Golpe básico
export(float, 0, 40, 0.5) var attack_damage := 6.0         # % de daño que causa
export var attack_knockback := Vector2(320, -260)          # empuje: x se refleja según hacia dónde mira, y negativo = hacia arriba
export(float, 0, 0.5, 0.01) var attack_startup := 0.08     # segundos desde que pulsas hasta que el golpe empieza a dañar
export(float, 0.02, 0.5, 0.01) var attack_active := 0.10   # segundos que el golpe daña
export(float, 0.05, 1, 0.01) var attack_total := 0.26      # duración total de la animación (hasta poder moverte)
export(int, 1, 9) var max_stocks := 3                      # vidas

# ----------------------------------------------------------- Habilidad especial
# Aquí solo están los campos COMUNES a todas las especiales. Los de cada habilidad (gull_, dig_, rock_,
# noodle_, smoke_, spike_, hook_, oar_, nose_) viven en scripts/core/data/Data<Personaje>.gd, que
# hereda de esta clase: así el Inspector de cada .tres solo muestra SUS campos.
# Qué hace cada número: docs/16_PARAMETROS_DE_HABILIDADES.md
export(float, 0.5, 30, 0.5) var special_cooldown := 3.0    # COMÚN: segundos de recarga
export(float, 0, 60, 0.5) var special_damage := 10.0       # COMÚN: % de daño TOTAL que hace la especial
export var special_knockback := Vector2(400, -300)         # COMÚN: empuje base (se multiplica por el % del rival; x se refleja según el lado)
export(float, 0, 3, 0.05) var special_windup := 0.35        # COMÚN: aviso antes de que la especial haga efecto
