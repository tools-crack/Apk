extends Node
# ============================================================================
#  Net.gd  —  autoload "Net": red LAN (WiFi/Ethernet) entre PC y Android
# ----------------------------------------------------------------------------
#  Modelo: el ANFITRIÓN (host) simula toda la partida; el CLIENTE solo envía sus
#  pulsaciones y dibuja lo que le manda el anfitrión (ver NetSync.gd).
#  El anfitrión es el jugador 1 (P1) y el cliente es el jugador 2 (P2).
#
#  Este archivo se encarga de:
#    - crear el servidor / conectarse (ENet de Godot, UDP, puerto PORT)
#    - descubrir partidas en la red local (el anfitrión "grita" por broadcast UDP
#      y el cliente escucha; así no hay que escribir la IP)
#    - los mensajes de lobby: empezar la partida, revancha, "estoy listo"
#
#  Señales:  peer_joined  (anfitrión: entró el cliente)
#            connected    (cliente: conexión lista)
#            connect_failed
#            peer_left    (el otro jugador se fue o se cayó la conexión)
# ============================================================================

signal peer_joined
signal connected
signal connect_failed
signal peer_left
signal rematch_requested              # (anfitrión) el cliente pidió revancha al terminar la partida

const PORT := 7777                    # puerto del juego (UDP). Abre este puerto en el cortafuegos del PC anfitrión
const DISCOVERY_PORT := 47777         # puerto del "grito" para encontrar partidas (UDP, broadcast)
const MAGIC := "SMASH2D"              # para no confundir con otros programas
const HOST_TIMEOUT := 4000            # ms sin oír a un anfitrión y se borra de la lista

enum Mode { OFFLINE, HOST, CLIENT }

var mode = Mode.OFFLINE
var peer_id := 0                      # id del otro jugador (anfitrión: el del cliente; cliente: 1)
var client_ready := false             # anfitrión: el cliente ya cargó la arena y espera
var client_in_arena := false          # anfitrión: el cliente está en la arena (=> al volver a entrar es revancha)
var epoch := 0                        # número de partida (para ignorar paquetes de una partida anterior)
var frame := 0                        # contador de pasos de física (lo avanza _physics_process)
var found_hosts := {}                 # ip -> {"name", "port", "seen"}  (cliente)
var remote_char := ""                 # personaje que eligió el OTRO jugador en la pantalla de selección
var remote_ready := false             # el otro ya confirmó
var notice := ""                      # mensaje para mostrar en el menú ("Se perdió la conexión"...)
var force_touch := false              # true = mostrar controles táctiles aunque no sea un móvil

var _peer = null
var _bcast: PacketPeerUDP = null
var _listen: PacketPeerUDP = null
var _bcast_t := 0.0
var _host_port := PORT


func _ready() -> void:
	force_touch = "--touch" in OS.get_cmdline_args()
	get_tree().connect("network_peer_connected", self, "_on_peer_connected")
	get_tree().connect("network_peer_disconnected", self, "_on_peer_disconnected")
	get_tree().connect("connected_to_server", self, "_on_connected_ok")
	get_tree().connect("connection_failed", self, "_on_connect_fail")
	get_tree().connect("server_disconnected", self, "_on_server_disconnected")


func is_active() -> bool:
	return mode != Mode.OFFLINE


func is_host() -> bool:
	return mode == Mode.HOST


func is_client() -> bool:
	return mode == Mode.CLIENT


# Qué jugador maneja ESTE dispositivo: el anfitrión es P1, el cliente es P2.
func local_player() -> int:
	return 2 if mode == Mode.CLIENT else 1


func touch_enabled() -> bool:
	return force_touch or OS.has_touchscreen_ui_hint()


# ----------------------------------------------------------------------------
#  Anfitrión
# ----------------------------------------------------------------------------
func start_host(port := PORT) -> int:
	stop()
	var p := NetworkedMultiplayerENet.new()
	p.set_compression_mode(NetworkedMultiplayerENet.COMPRESS_FASTLZ)   # paquetes más chicos (importa en WiFi)
	var err = p.create_server(port, 1)                                 # 1 solo cliente
	if err != OK:
		return err
	get_tree().network_peer = p
	_peer = p
	mode = Mode.HOST
	_host_port = port
	_start_broadcast()
	return OK


# Direcciones IPv4 de este equipo (para mostrarlas y que el otro jugador las escriba).
func local_ips() -> Array:
	var out := []
	for a in IP.get_local_addresses():
		var s: String = str(a)
		if s.count(".") == 3 and not s.begins_with("127.") and not s.begins_with("169.254."):
			out.append(s)
	return out


func _start_broadcast() -> void:
	_bcast = PacketPeerUDP.new()
	_bcast.set_broadcast_enabled(true)
	_bcast.set_dest_address("255.255.255.255", DISCOVERY_PORT)
	_bcast_t = 0.0


# ----------------------------------------------------------------------------
#  Cliente
# ----------------------------------------------------------------------------
func join(ip: String, port := PORT) -> int:
	stop()
	var p := NetworkedMultiplayerENet.new()
	p.set_compression_mode(NetworkedMultiplayerENet.COMPRESS_FASTLZ)
	var err = p.create_client(ip.strip_edges(), port)
	if err != OK:
		return err
	get_tree().network_peer = p
	_peer = p
	mode = Mode.CLIENT
	return OK


# Empieza a escuchar los "gritos" de los anfitriones de la red local.
func start_discovery() -> void:
	stop_discovery()
	_listen = PacketPeerUDP.new()
	if _listen.listen(DISCOVERY_PORT, "*") != OK:
		_listen = null                                   # puerto ocupado: queda la IP a mano
	found_hosts.clear()


func stop_discovery() -> void:
	if _listen != null:
		_listen.close()
		_listen = null


# ----------------------------------------------------------------------------
#  Cerrar todo
# ----------------------------------------------------------------------------
func stop() -> void:
	if _peer != null:
		get_tree().network_peer = null
		_peer = null
	if _bcast != null:
		_bcast.close()
		_bcast = null
	stop_discovery()
	mode = Mode.OFFLINE
	peer_id = 0
	client_ready = false
	client_in_arena = false
	remote_char = ""
	remote_ready = false


func _process(delta: float) -> void:
	if _bcast != null and peer_id == 0:                   # solo "grita" mientras espera a alguien
		_bcast_t -= delta
		if _bcast_t <= 0.0:
			_bcast_t = 1.0
			var name = OS.get_environment("COMPUTERNAME") if OS.has_environment("COMPUTERNAME") else OS.get_name()
			_bcast.put_packet(("%s|%d|%s" % [MAGIC, _host_port, name]).to_utf8())
	if _listen != null:
		while _listen.get_available_packet_count() > 0:
			var text: String = _listen.get_packet().get_string_from_utf8()
			var ip: String = _listen.get_packet_ip()
			var parts = text.split("|")
			if parts.size() >= 3 and parts[0] == MAGIC and ip != "":
				found_hosts[ip] = {"name": parts[2], "port": int(parts[1]), "seen": OS.get_ticks_msec()}
		var now = OS.get_ticks_msec()
		for ip in found_hosts.keys():
			if now - found_hosts[ip]["seen"] > HOST_TIMEOUT:
				found_hosts.erase(ip)


func _physics_process(_delta: float) -> void:
	frame += 1


# ----------------------------------------------------------------------------
#  Eventos de conexión
# ----------------------------------------------------------------------------
func _on_peer_connected(id: int) -> void:
	if mode != Mode.HOST:
		return
	if peer_id != 0:                                      # ya hay un cliente: este sobra
		if _peer != null:
			_peer.disconnect_peer(id)
		return
	peer_id = id
	emit_signal("peer_joined")


func _on_peer_disconnected(id: int) -> void:
	if mode == Mode.HOST and id == peer_id:
		peer_id = 0
		client_ready = false
		client_in_arena = false
		_bcast_t = 0.0                                    # vuelve a "gritar"
		notice = "El otro jugador se desconectó."
		call_deferred("emit_signal", "peer_left")


func _on_connected_ok() -> void:
	peer_id = 1
	emit_signal("connected")


func _on_connect_fail() -> void:
	call_deferred("_after_fail")


func _after_fail() -> void:
	stop()
	emit_signal("connect_failed")


func _on_server_disconnected() -> void:
	call_deferred("_after_server_lost")


func _after_server_lost() -> void:
	stop()
	notice = "Se perdió la conexión con el anfitrión."
	emit_signal("peer_left")


# ----------------------------------------------------------------------------
#  Mensajes de lobby
# ----------------------------------------------------------------------------
# Lo llama Arena.gd del ANFITRIÓN al cargar: avisa al cliente para que cargue la suya.
func host_arena_started() -> void:
	if mode != Mode.HOST or peer_id == 0:
		return
	var rematch := client_in_arena
	client_ready = false
	epoch += 1
	if rematch:
		rpc_id(peer_id, "net_rematch", epoch)
	else:
		rpc_id(peer_id, "net_begin", Game.selected, Game.stage_index, epoch)


# Selección de personajes en red: cada jugador elige el suyo en su dispositivo y se lo manda al otro.
# El anfitrión abre la pantalla (host_open_select) y el cliente salta a ella; luego el anfitrión elige escenario.
func host_open_select() -> void:
	if mode != Mode.HOST:
		return
	remote_char = ""
	remote_ready = false
	client_in_arena = false                               # la próxima arena es partida nueva (net_begin), no revancha
	if peer_id != 0:
		rpc_id(peer_id, "net_open_select")


func send_pick(id: String, ready: bool) -> void:
	if is_active() and peer_id != 0:
		rpc_id(peer_id, "net_pick", id, ready)


func client_request_rematch() -> void:
	if mode == Mode.CLIENT:
		rpc_id(1, "net_rematch_request")


remote func net_open_select() -> void:
	if mode != Mode.CLIENT or get_tree().get_rpc_sender_id() != 1:
		return
	remote_char = ""
	remote_ready = false
	Game.practice = false
	Game.goto("res://scenes/ui/CharSelect.tscn")


remote func net_pick(id: String, ready: bool) -> void:
	if not is_active() or get_tree().get_rpc_sender_id() != peer_id:
		return
	if Game.CHARACTERS.has(id):
		remote_char = id
		remote_ready = ready


remote func net_rematch_request() -> void:
	if mode == Mode.HOST and get_tree().get_rpc_sender_id() == peer_id:
		emit_signal("rematch_requested")


# Lo llama Arena.gd del CLIENTE al cargar: "ya estoy, empieza".
func client_arena_loaded() -> void:
	if mode == Mode.CLIENT:
		rpc_id(1, "net_client_ready", epoch)


remote func net_begin(selected: Array, stage_index: int, new_epoch: int) -> void:
	if mode != Mode.CLIENT or get_tree().get_rpc_sender_id() != 1:
		return
	Game.selected = selected
	Game.stage_index = stage_index
	Game.stage_random = false
	Game.practice = false
	epoch = new_epoch
	Game.goto("res://scenes/Arena.tscn")


remote func net_rematch(new_epoch: int) -> void:
	if mode != Mode.CLIENT or get_tree().get_rpc_sender_id() != 1:
		return
	epoch = new_epoch
	get_tree().reload_current_scene()


remote func net_client_ready(for_epoch: int) -> void:
	if mode != Mode.HOST or for_epoch != epoch:
		return
	client_ready = true
	client_in_arena = true
