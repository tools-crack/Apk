extends "res://scripts/fighters/Levaro.gd"
# ============================================================================
#  Jp.gd  —  especial "Narizazo"
# ----------------------------------------------------------------------------
#  Igual que Levaro (aviso, oar_swings golpes seguidos y empujón final) pero el arma es
#  su NARIZ, que crece: cada estocada llega nose_growth px más lejos que la anterior y el
#  empujón final es el que más alcance tiene. Aviso: special_windup + oar_hit_delay antes de cada golpe.
#  Esquivable: alejándose del alcance actual, saltando por encima de oar_height o pasando a su espalda.
#  Números en characters/jp.tres (oar_* y nose_growth; ver docs/16_PARAMETROS_DE_HABILIDADES.md §13).
# ============================================================================


func _current_reach() -> float:
	return stats.oar_reach + stats.nose_growth * float(swing_no)
