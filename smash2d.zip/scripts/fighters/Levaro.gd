extends "res://scripts/fighters/Fighter.gd"
# ============================================================================
#  Levaro.gd  —  especial "Remazos"
# ----------------------------------------------------------------------------
#  Levaro alza el remo (aviso de special_windup segundos), da oar_swings remazos
#  seguidos y termina con un EMPUJÓN fuerte que manda al rival lejos.
#
#  ESQUIVABLE: antes de cada golpe (y antes del empujón) Levaro levanta el remo;
#  si el rival se aleja más de oar_reach px o salta por encima de oar_height px,
#  ese golpe falla. Los remazos son pequeños (el rival queda aturdido a tiro del
#  siguiente); el empujón final es el que lanza.
#
#  FASES  (variable "phase")
#     WINDUP  remo alzado (aviso) ............... special_windup
#     SWING   un remazo; se repite oar_swings veces . oar_swing_time cada uno
#     PUSH    aviso + empujón final ............. oar_push_delay + oar_push_total
#
#  Números en characters/levaro.tres:
#     special_cooldown / special_damage (TOTAL: oar_swing_share para los remazos, el resto para el empujón)
#     special_knockback (empujón final)   special_windup (aviso inicial)
#     oar_swings  oar_reach  oar_height  oar_swing_time  oar_hit_delay
#     oar_swing_share  oar_swing_knockback  oar_push_delay  oar_push_total
# ============================================================================

enum Phase { WINDUP, SWING, PUSH }

var phase = Phase.WINDUP
var phase_time := 0.0
var swing_no := 0              # remazos ya dados
var cycle_hit := false         # ¿ya cayó el golpe de este remazo / empujón?


func _start_special() -> void:
	state = State.SPECIAL
	state_time = 0.0
	phase = Phase.WINDUP
	phase_time = 0.0
	swing_no = 0
	cycle_hit = false
	special_timer = special_cooldown
	velocity.x *= 0.3
	_play("special", true)                 # remo alzado
	_sfx($SfxSpecial)


func _state_special(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 1500.0 * delta)
	phase_time += delta
	match phase:
		Phase.WINDUP:
			if phase_time >= stats.special_windup:
				_next_phase(Phase.SWING)
		Phase.SWING:
			if not cycle_hit and phase_time >= stats.oar_hit_delay:
				cycle_hit = true
				_play("swing", true)
				_sfx($SfxSwing)
				_oar_hit(stats.special_damage * stats.oar_swing_share / float(max(1, int(stats.oar_swings))),
						stats.oar_swing_knockback)
			if phase_time >= stats.oar_swing_time:
				swing_no += 1
				if swing_no >= int(stats.oar_swings):
					_next_phase(Phase.PUSH)
				else:
					_next_phase(Phase.SWING)          # el siguiente remazo
		Phase.PUSH:
			if not cycle_hit and phase_time >= stats.oar_push_delay:
				cycle_hit = true
				_play("push", true)
				_sfx($SfxSwing)
				_oar_hit(stats.special_damage * (1.0 - stats.oar_swing_share), stats.special_knockback)
			if phase_time >= stats.oar_push_delay + stats.oar_push_total:
				state = State.NORMAL


func _next_phase(p) -> void:
	phase = p
	phase_time = 0.0
	cycle_hit = false
	if p != Phase.WINDUP:
		_play("special", true)                 # vuelve a alzar el remo (aviso del siguiente golpe)


func _current_reach() -> float:                                # JP lo cambia: su nariz crece
	return stats.oar_reach


# Golpea a los rivales dentro de la zona del remo (delante de Levaro). Devuelve si alguien recibió el golpe.
func _oar_hit(damage: float, kb: Vector2) -> bool:
	var hit := false
	for f in get_tree().get_nodes_in_group("fighters"):
		if f == self or f.is_dead() or not f.has_method("take_hit"):
			continue
		var dx = (f.global_position.x - global_position.x) * facing     # >0 = delante
		var dy = abs(f.global_position.y - global_position.y)
		if dx >= -16.0 and dx <= _current_reach() and dy <= stats.oar_height:
			if f.take_hit(damage, Vector2(facing * kb.x, kb.y), self):
				hit = true
	return hit
