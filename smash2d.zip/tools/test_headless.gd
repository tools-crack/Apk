extends SceneTree

var fails := 0

func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)

func wait(sec):
	yield(create_timer(sec), "timeout")

func press(action, hold = 0.06):
	Input.action_press(action)
	yield(create_timer(hold), "timeout")
	Input.action_release(action)

func _tilemap_full(tm, cols, rows):
	for x in range(cols):
		for y in range(rows):
			if tm.get_cell(x, y) == TileMap.INVALID_CELL:
				return false
	return true

func reset(f, pos):
	f.position = pos
	f.velocity = Vector2.ZERO
	f.percent = 0.0
	f.state = f.State.NORMAL
	f.invulnerable = false
	f.invuln_timer = 0.0
	f.special_timer = 0.0
	f.frozen = false
	f.collision_layer = 2
	f.sprite.visible = true

func _initialize():
	_run()

func _run():
	var game = root.get_node("Game")
	print("== Input Map")
	for pl in ["p1_", "p2_"]:
		for a in ["left", "right", "jump", "down", "attack", "special"]:
			var n = pl + a
			check("action " + n, InputMap.has_action(n) and InputMap.get_action_list(n).size() == 1)

	print("== Carga de escenas")
	for path in ["res://scenes/ui/MainMenu.tscn", "res://scenes/ui/CharSelect.tscn", "res://scenes/ui/PickPanel.tscn",
			"res://scenes/ui/PlayerPanel.tscn", "res://scenes/Arena.tscn", "res://scenes/fighters/Fighter.tscn",
			"res://scenes/fighters/Gaviotero.tscn", "res://scenes/fighters/Topo.tscn",
			"res://scenes/effects/Gull.tscn", "res://scenes/effects/HitSpark.tscn"]:
		var ps = load(path)
		check("load " + path, ps != null)
		if ps != null:
			var inst = ps.instance()
			check("instance " + path, inst != null)
			inst.free()
	for path in [game.MENU_MUSIC, game.BATTLE_MUSIC]:
		var s = load(path)
		check("music " + path, s != null and s.get_length() > 5.0, str(s.get_length() if s else 0))

	print("== Menu y seleccion")
	var menu = load("res://scenes/ui/MainMenu.tscn").instance()
	root.add_child(menu)
	yield(wait(0.3), "completed")
	check("menu: boton con foco", menu.btn_play.has_focus())
	check("menu: musica sonando", game.music_player.playing and game.music_player.stream.loop)
	menu.queue_free()
	var cs = load("res://scenes/ui/CharSelect.tscn").instance()
	root.add_child(cs)
	yield(wait(0.2), "completed")
	check("charselect: P1 gaviotero", cs.pick1.character_id() == "gaviotero")
	cs.pick1._move(1)
	check("charselect: P1 cambia a topo", cs.pick1.character_id() == "topo" and cs.pick1.get_node("CharName").text == "Topo")
	cs.pick1._set_ready(true)
	check("charselect: P1 listo", cs.pick1.is_ready and cs.pick1.get_node("ReadyBadge/ReadyLabel").text == "¡LISTO!")
	cs.pick1._set_ready(false)
	check("charselect: P1 cancela", not cs.pick1.is_ready)
	cs.pick2._move(1); cs.pick2._move(1)
	check("charselect: ciclo de personajes (topo -> likan -> aukin)", cs.pick2.character_id() == "aukin")
	cs.queue_free()
	yield(wait(0.1), "completed")

	print("== Arena")
	game.selected = ["gaviotero", "topo"]
	game.practice = false
	var arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(3.6), "completed")
	var f1 = arena.fighters[0]
	var f2 = arena.fighters[1]
	check("arena: partida iniciada", arena.started)
	check("arena: P1 en el suelo", f1.is_on_floor(), str(f1.position))
	check("arena: P2 en el suelo", f2.is_on_floor(), str(f2.position))
	check("arena: P1 es gaviotero con script", f1.display_name == "Gaviotero" and f1.has_method("_state_special"))
	check("arena: sprite frames idle", f1.sprite.frames.has_animation("idle") and f1.sprite.frames.has_animation("special"))
	check("arena: sprite frames topo", f2.sprite.frames.has_animation("dive") and f2.sprite.frames.has_animation("emerge"))
	check("arena: esta en el grupo 'arena'", arena.is_in_group("arena"))
	check("luchador recibe las estadisticas del .tres", f1.stats == game.CHARACTERS["gaviotero"] and f1.attack_total == game.CHARACTERS["gaviotero"].attack_total and f2.attack_damage == game.CHARACTERS["topo"].attack_damage)
	root.get_tree().call_group("arena", "shake", 10.0)   # en Godot 3 call_group se ejecuta al final del frame
	yield(wait(0.03), "completed")
	check("temblor de pantalla por grupo", arena.shake_amount >= 8.0, str(arena.shake_amount))
	check("HUD lee la tecla del especial del Input Map", arena.get_node("HUD/P1Panel/SpecialLabel").text == "ESPECIAL  [G]" \
		and arena.get_node("HUD/P2Panel/SpecialLabel").text == "ESPECIAL  [L]", arena.get_node("HUD/P2Panel/SpecialLabel").text)

	print("== Movimiento")
	var x0 = f1.position.x
	Input.action_press("p1_right")
	yield(wait(0.5), "completed")
	check("P1 corre a la derecha", f1.position.x > x0 + 80, "%s -> %s anim=%s" % [x0, f1.position.x, f1.sprite.animation])
	Input.action_release("p1_right")
	yield(wait(0.4), "completed")
	var y0 = f1.position.y
	yield(press("p1_jump"), "completed")
	yield(wait(0.15), "completed")
	check("P1 salta", f1.position.y < y0 - 25, "%s -> %s anim=%s" % [y0, f1.position.y, f1.sprite.animation])
	yield(wait(1.0), "completed")
	check("P1 aterriza", f1.is_on_floor())

	print("== Golpe basico")
	reset(f1, Vector2(500, 440)); reset(f2, Vector2(545, 440))
	yield(wait(0.2), "completed")
	f1.facing = 1
	yield(press("p1_attack"), "completed")
	yield(wait(0.05), "completed")
	check("golpe: animacion 'attack'", f1.sprite.animation == "attack" and f1.state == f1.State.ATTACK)
	yield(wait(0.4), "completed")
	check("golpe causa el daño de la ficha", f2.percent == f1.attack_damage, "percent=%s state=%s" % [f2.percent, f2.state])

	print("== Especial Gaviotero")
	reset(f1, Vector2(400, 440)); reset(f2, Vector2(780, 440))
	f1.facing = 1
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.1), "completed")
	check("gaviotero entra en SPECIAL con anim 'special'", f1.state == f1.State.SPECIAL and f1.sprite.animation == "special")
	check("sonido de gaviota suena", f1.get_node("SfxSpecial").playing)
	var gull = null
	var gguard = 0
	while gull == null and gguard < 100:               # la gaviota sale tras special_windup (0.35 s)
		yield(wait(0.02), "completed")
		gguard += 1
		for c in arena.get_node("Fighters").get_children():
			if c.get_script() != null and c.get_script().resource_path.ends_with("Gull.gd"):
				gull = c
	check("la gaviota existe", gull != null)
	if gull != null:
		var gx = gull.position.x
		yield(wait(0.2), "completed")
		check("la gaviota avanza hacia la derecha", gull.position.x > gx + 60, "%s -> %s" % [gx, gull.position.x])
		check("la gaviota anima (fly)", gull.get_node("Sprite").animation == "fly" and gull.get_node("Sprite").playing)
	yield(wait(0.6), "completed")
	check("la gaviota golpeo a P2", f2.percent >= 9.0, "percent=%s" % f2.percent)
	check("especial en recarga", f1.special_timer > 0.0, str(f1.special_timer))
	yield(wait(2.0), "completed")
	check("la gaviota desaparece al salir del mapa", not is_instance_valid(gull) or gull.is_queued_for_deletion())
	var still = 0
	for c in arena.get_node("Fighters").get_children():
		if c.get_script() != null and c.get_script().resource_path.ends_with("Gull.gd"):
			still += 1
	check("no quedan gaviotas", still == 0, str(still))

	print("== Especial Topo")
	reset(f1, Vector2(450, 440)); reset(f2, Vector2(800, 440))
	f2.facing = -1
	yield(wait(0.4), "completed")
	f2.special_timer = 0.0
	yield(press("p2_special"), "completed")
	yield(wait(0.15), "completed")
	check("topo en DIVE con anim 'dive'", f2.state == f2.State.SPECIAL and f2.phase == f2.Phase.DIVE and f2.sprite.animation == "dive")
	check("sonido de excavar", f2.get_node("SfxSpecial").playing)
	check("invulnerable mientras se hunde", f2.is_invulnerable())
	yield(wait(0.6), "completed")
	check("topo bajo tierra (UNDER)", f2.phase == f2.Phase.UNDER)
	check("sprite oculto y monticulo visible", (not f2.sprite.visible) and f2.mound.visible)
	check("monticulo se mueve hacia el rival", f2.mound.global_position.x < 780.0, str(f2.mound.global_position))
	check("sin colision bajo tierra", f2.collision_layer == 0)
	var guard = 0
	while f2.phase != f2.Phase.EMERGE and guard < 100:
		yield(wait(0.02), "completed")
		guard += 1
	check("topo reaparecio (EMERGE)", f2.phase == f2.Phase.EMERGE, "esperó %.2fs" % (guard * 0.02))
	check("anim 'emerge'", f2.sprite.animation == "emerge")
	check("aparece donde estaba el rival", f2.position.distance_to(f1.position) < 12.0, "topo=%s p1=%s" % [f2.position, f1.position])
	check("topo visible otra vez", f2.sprite.visible and f2.collision_layer == 2)
	check("sonido de aparecer", f2.get_node("SfxEmerge").playing)
	yield(wait(0.35), "completed")
	check("el rival recibio 15% de dano", abs(f1.percent - 15.0) < 0.01, "percent=%s" % f1.percent)
	check("el rival sale lanzado hacia arriba", f1.velocity.y < -200.0 or f1.position.y < 380.0, "vy=%s y=%s" % [f1.velocity.y, f1.position.y])
	yield(wait(0.6), "completed")
	check("topo vuelve a NORMAL y vulnerable", f2.state == f2.State.NORMAL and not f2.invulnerable and not f2.frozen)

	print("== Topo no puede usar el especial en el aire")
	reset(f2, Vector2(800, 200))
	f2.special_timer = 0.0
	f2.sprite.visible = true
	yield(wait(0.05), "completed")
	yield(press("p2_special"), "completed")
	yield(wait(0.05), "completed")
	check("en el aire: no se activa", f2.state != f2.State.SPECIAL)
	yield(wait(1.0), "completed")

	print("== KO y reaparicion")
	reset(f1, Vector2(640, 300)); reset(f2, Vector2(800, 440))
	yield(wait(0.3), "completed")
	f1.position = Vector2(-400, 300)
	yield(wait(0.2), "completed")
	check("P1 pierde una vida", f1.stocks == 2 and f1.state == f1.State.DEAD, "stocks=%s" % f1.stocks)
	yield(wait(1.9), "completed")
	check("P1 reaparece invulnerable", f1.state == f1.State.NORMAL and f1.invuln_timer > 0.0 and f1.sprite.visible, "state=%s" % f1.state)

	print("== Fin de partida")
	f2.stocks = 1
	f2.position = Vector2(2000, 300)
	yield(wait(0.5), "completed")
	check("fin de partida: gana P1", arena.over and "P1" in arena.message.text, arena.message.text.replace("\n", " "))

	print("== Practica (muneco)")
	arena.queue_free()
	yield(wait(0.2), "completed")
	game.practice = true
	var arena2 = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena2)
	yield(wait(3.6), "completed")
	check("practica: muneco sin input", arena2.fighters[0].input_enabled and not arena2.fighters[1].input_enabled)
	check("practica: vidas infinitas", arena2.fighters[1].stocks == 99)

	print("== Config y autodeteccion de personajes")
	var cfg = root.get_node("Config")
	check("Config: 2 puntos de aparicion y zona de KO", cfg.SPAWN_POINTS.size() == 2 and cfg.BLAST_LEFT < 0.0 and cfg.BLAST_RIGHT > 1280.0)
	check("Config: capas coherentes con el Input/Physics map", cfg.MASK_FIGHTER_NORMAL == cfg.BIT_GROUND + cfg.BIT_PLATFORM)
	check("autodeteccion: personajes en orden", game.ORDER == ["gaviotero", "topo", "likan", "aukin", "nanco", "winkul", "jorge", "levaro", "jp"], str(game.ORDER))
	check("autodeteccion: fichas completas", game.CHARACTERS["topo"].scene != null and game.CHARACTERS["gaviotero"].portrait != null)
	check("ficha .tres: campos de golpe cargados", game.CHARACTERS["topo"].attack_total == 0.26 and game.CHARACTERS["topo"].attack_damage == 7.0)
	check("seleccion por defecto valida", game.CHARACTERS.has(game.selected[0]) and game.CHARACTERS.has(game.selected[1]))

	print("== Tileset del escenario")
	var arena3 = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena3)
	yield(wait(0.1), "completed")
	var stage = arena3.get_node("Stage")
	var gt = stage.get_node("GroundTiles")
	var pl = stage.get_node("PlatformLeftTiles")
	check("ground tiles: tileset cargado", gt.tile_set != null)
	check("ground tiles: rellena 15x5 sin huecos", _tilemap_full(gt, 15, 5))
	check("ground tiles: esquinas superiores redondeadas", gt.get_cell(0, 0) == gt.tile_set.find_tile_by_name("top_left") \
		and gt.get_cell(14, 0) == gt.tile_set.find_tile_by_name("top_right"))
	check("plataforma: 4x2 con base redondeada (flotante)", _tilemap_full(pl, 4, 2) \
		and pl.get_cell(0, 1) == pl.tile_set.find_tile_by_name("bot_left") \
		and pl.get_cell(3, 1) == pl.tile_set.find_tile_by_name("bot_right"))
	check("colision del suelo intacta (origen)", stage.get_node("Ground").position == Vector2(640, 510))
	check("colision de plataforma intacta (origen)", stage.get_node("PlatformLeft").position == Vector2(400, 356))
	arena3.queue_free()
	yield(wait(0.1), "completed")

	print("== Panel de seleccion (estilo)")
	var cs2 = load("res://scenes/ui/CharSelect.tscn").instance()
	root.add_child(cs2)
	yield(wait(0.2), "completed")
	var pp1 = cs2.pick1
	var col = game.CHARACTERS[pp1.character_id()].color
	check("colores de marco y acento coinciden con el personaje", \
		pp1.get_stylebox("panel").border_color == col and pp1.get_node("AccentBar").color == col)
	check("retrato del panel cargado", pp1.get_node("PortraitFrame/Portrait").texture != null)
	check("insignia 'listo' no esta en verde antes de confirmar", \
		pp1.get_node("ReadyBadge").get_stylebox("panel").bg_color != Color(0.3, 0.75, 0.42, 0.95))
	pp1._set_ready(true)
	check("insignia 'listo' ahora en verde", \
		pp1.get_node("ReadyBadge").get_stylebox("panel").bg_color == Color(0.3, 0.75, 0.42, 0.95))
	cs2.queue_free()
	yield(wait(0.1), "completed")

	print("")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
