#!/usr/bin/env python3
"""Crea un personaje nuevo, listo para jugar, con un solo comando.

Uso:
    python3 tools/nuevo_personaje.py <id> "<Nombre>" [--color "#aa3366"]
            [--sombrero marinero|minero|cocinero|piedra|gorra|pinchos|pescador|ninguno] [--especial "Nombre del especial"]
            [--descripcion "Texto para la selección"]

Ejemplo:
    python3 tools/nuevo_personaje.py rayo "Rayo" --color "#e0b000" --especial "Puño relámpago"

Qué hace (todo explicado en docs/06_CREAR_UN_PERSONAJE_NUEVO.md):
    1. characters/<id>.tres              ficha con todas las estadísticas
       scripts/core/data/Data<Clase>.gd  (campos de SU habilidad; el Inspector solo muestra esos)
    2. scenes/fighters/<Clase>.tscn      escena (hereda de Fighter.tscn)
    3. scripts/fighters/<Clase>.gd       script con un especial de ejemplo que ya funciona
    4. tools/personajes_extra.json       registra color y sombrero del stickman
    5. regenera los sprites SVG          (assets/sprites/<id>/ y resources/<id>_frames.tres)
Después abre el proyecto en Godot (importa los sprites nuevos) y el personaje aparece solo
en la selección. Requiere Python 3 (y Pillow solo si regeneras el tileset, no aquí).
"""
import argparse
import importlib.util
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, ".."))
PLANT = os.path.join(HERE, "plantillas")
EXTRA = os.path.join(HERE, "personajes_extra.json")


def leer(ruta):
    with open(ruta, encoding="utf-8") as f:
        return f.read()


def escribir(ruta, texto):
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(texto)


def clase_de(id_):
    return "".join(p.capitalize() for p in id_.split("_"))


def color_godot(hex_):
    h = hex_.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    return "Color( %.3f, %.3f, %.3f, 1 )" % (r, g, b)


def siguiente_orden():
    mayor = 0
    carpeta = os.path.join(PROJ, "characters")
    for n in os.listdir(carpeta):
        if n.endswith(".tres") and not n.startswith("_"):
            m = re.search(r"^order = (\d+)", leer(os.path.join(carpeta, n)), re.M)
            if m:
                mayor = max(mayor, int(m.group(1)))
    return mayor + 1


def main():
    ap = argparse.ArgumentParser(description="Crea un personaje nuevo.")
    ap.add_argument("id", help="id interno: minúsculas, números y _ (ej. rayo)")
    ap.add_argument("nombre", help="nombre visible (ej. \"Rayo\")")
    ap.add_argument("--color", default="#8a4fd6", help="color en hex (por defecto #8a4fd6)")
    ap.add_argument("--sombrero", default="ninguno", choices=["marinero", "minero", "cocinero", "piedra", "gorra", "pinchos", "pescador", "ninguno"])
    ap.add_argument("--especial", default="Golpe especial", help="nombre de la habilidad")
    ap.add_argument("--descripcion", default="Describe aquí qué hace su especial.")
    a = ap.parse_args()

    if not re.fullmatch(r"[a-z][a-z0-9_]*", a.id):
        sys.exit("El id debe empezar con una letra minúscula y usar solo minúsculas, números y _")
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", a.color):
        sys.exit("El color debe ser hex de 6 dígitos, por ejemplo #aa3366")
    clase = clase_de(a.id)
    tres = os.path.join(PROJ, "characters", a.id + ".tres")
    if os.path.exists(tres):
        sys.exit("Ya existe characters/%s.tres" % a.id)

    datos = {"ID": a.id, "CLASE": clase, "NOMBRE": a.nombre, "ESPECIAL": a.especial,
             "ORDEN": str(siguiente_orden()), "COLOR": color_godot(a.color),
             "DESCRIPCION": a.descripcion.replace('"', "'")}

    def render(plantilla):
        t = leer(os.path.join(PLANT, plantilla))
        for k, v in datos.items():
            t = t.replace("{{%s}}" % k, v)
        return t

    # 4) color y sombrero del stickman (los lee tools/make_sprites.py)
    extra = json.loads(leer(EXTRA)) if os.path.exists(EXTRA) else {}
    extra[a.id] = {"color": a.color, "hat": None if a.sombrero == "ninguno" else
                   {"marinero": "sailor", "minero": "miner", "cocinero": "chef", "piedra": "rock", "gorra": "cap", "pinchos": "spiky", "pescador": "fisher"}[a.sombrero]}
    escribir(EXTRA, json.dumps(extra, indent=2, ensure_ascii=False) + "\n")

    # 1-3) ficha, escena y script
    escribir(tres, render("personaje.tres.txt"))
    escribir(os.path.join(PROJ, "scripts", "core", "data", "Data" + clase + ".gd"), render("data.gd.txt"))
    escribir(os.path.join(PROJ, "scenes", "fighters", clase + ".tscn"), render("escena_luchador.tscn.txt"))
    escribir(os.path.join(PROJ, "scripts", "fighters", clase + ".gd"), render("luchador.gd.txt"))

    # 5) sprites (reutiliza make_sprites.py)
    spec = importlib.util.spec_from_file_location("make_sprites", os.path.join(HERE, "make_sprites.py"))
    ms = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ms)
    ms.main()

    print("\n¡Listo! Personaje '%s' creado:" % a.id)
    for r in (tres, os.path.join("scripts", "core", "data", "Data" + clase + ".gd"),
              os.path.join("scenes", "fighters", clase + ".tscn"),
              os.path.join("scripts", "fighters", clase + ".gd")):
        print("   ", os.path.relpath(r, PROJ) if os.path.isabs(r) else r)
    print("Abre el proyecto en Godot (importará los sprites nuevos) y verás a '%s' en la selección." % a.nombre)
    print("Edita su especial en scripts/fighters/%s.gd y sus números en characters/%s.tres" % (clase, a.id))


if __name__ == "__main__":
    main()
