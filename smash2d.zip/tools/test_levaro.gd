extends SceneTree
# test_levaro.gd — Levaro: 3 remazos + empujón; se esquiva alejándose o saltando.
#   godot --path . --no-window -s tools/test_levaro.gd
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func reset(f, pos):
	f.position = pos
	f.velocity = Vector2.ZERO
	f.percent = 0.0
	f.state = f.State.NORMAL
	f.invulnerable = false
	f.invuln_timer = 0.0
	f.special_timer = 0.0
	f.frozen = false
	f.wrapped_time = 0.0
	f.collision_layer = 2
	f.sprite.visible = true


func _initialize():
	_run()


func _run():
	var game = root.get_node("Game")
	print("== Levaro: Remazos")
	check("Levaro existe en la lista", game.CHARACTERS.has("levaro") and game.ORDER.has("levaro"))
	game.selected = ["levaro", "gaviotero"]
	game.practice = false
	var arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(3.6), "completed")
	var lv = arena.fighters[0]
	var rv = arena.fighters[1]
	var st = lv.stats
	check("ficha cargada", st != null and lv.display_name == "Levaro")

	# --- golpea: 3 remazos (daño en escalones) y empujón final
	reset(lv, Vector2(400, 440)); reset(rv, Vector2(470, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	var seen := []
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	var t := 0.0
	var last := 0.0
	var max_vx := 0.0
	while t < 3.0 and lv.state == lv.State.SPECIAL:
		yield(wait(0.02), "completed")
		t += 0.02
		if rv.percent != last:
			seen.append(rv.percent)
			last = rv.percent
		max_vx = max(max_vx, abs(rv.velocity.x))
	check("recibe 3 remazos + empujón (4 golpes)", seen.size() == 4, str(seen))
	var total = st.special_damage
	check("daño total = special_damage", abs(rv.percent - total) < 0.5, "percent=%s" % rv.percent)
	check("el empujón es el golpe fuerte (sale volando)", max_vx > 400.0, "vx=%s" % max_vx)
	check("Levaro vuelve a NORMAL", lv.state == lv.State.NORMAL)
	check("recarga activa", lv.special_timer > 0.0)

	# --- esquivar alejándose (fuera de alcance)
	yield(wait(0.5), "completed")
	reset(lv, Vector2(300, 440)); reset(rv, Vector2(300 + st.oar_reach + 80, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	yield(wait(2.2), "completed")
	check("fuera de alcance: no recibe daño", rv.percent == 0.0, "percent=%s" % rv.percent)

	# --- esquivar: detrás de Levaro no golpea
	reset(lv, Vector2(500, 440)); reset(rv, Vector2(430, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	yield(wait(2.2), "completed")
	check("rival a la espalda: no recibe daño", rv.percent == 0.0, "percent=%s" % rv.percent)

	# --- aviso: antes de special_windup + hit_delay no hay daño
	reset(lv, Vector2(400, 440)); reset(rv, Vector2(470, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	yield(wait(st.special_windup * 0.6), "completed")
	check("durante el aviso inicial no hay daño", rv.percent == 0.0)
	yield(wait(2.0), "completed")

	# --- si golpean a Levaro, el especial no se anula
	reset(lv, Vector2(400, 440)); reset(rv, Vector2(470, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	yield(wait(0.2), "completed")
	lv.take_hit(5.0, Vector2(-100, -50), rv)
	check("golpeado durante el especial: sigue en SPECIAL", lv.state == lv.State.SPECIAL)

	print("")
	print("RESULTADO: %d fallos" % fails)
	quit()
