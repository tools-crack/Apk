extends SceneTree
# test_jp.gd — JP: estocadas con la nariz que crece (cada una llega más lejos) + empujón; se esquiva.
#   godot --path . --no-window -s tools/test_jp.gd
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func reset(f, pos):
	f.position = pos
	f.velocity = Vector2.ZERO
	f.percent = 0.0
	f.state = f.State.NORMAL
	f.invulnerable = false
	f.invuln_timer = 0.0
	f.special_timer = 0.0
	f.frozen = false
	f.wrapped_time = 0.0
	f.collision_layer = 2
	f.sprite.visible = true


func _initialize():
	_run()


func _run():
	var game = root.get_node("Game")
	print("== JP: Remazos")
	check("JP existe en la lista", game.CHARACTERS.has("jp") and game.ORDER.has("jp"))
	game.selected = ["jp", "gaviotero"]
	game.practice = false
	var arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(3.6), "completed")
	var lv = arena.fighters[0]
	var rv = arena.fighters[1]
	var st = lv.stats
	check("ficha cargada", st != null and lv.display_name == "JP")

	# --- a distancia media: la 1ª estocada falla, las demás (más largas) pegan
	var growth = st.nose_growth
	reset(lv, Vector2(400, 440)); reset(rv, Vector2(400 + st.oar_reach + growth * 0.8, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	var seen := []
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	var t := 0.0
	var last := 0.0
	var max_vx := 0.0
	while t < 3.5 and lv.state == lv.State.SPECIAL:
		yield(wait(0.02), "completed")
		t += 0.02
		if rv.percent != last:
			seen.append(rv.percent)
			last = rv.percent
		max_vx = max(max_vx, abs(rv.velocity.x))
	check("la nariz crece: 1ª estocada falla y pegan 2 estocadas + empujón (3 golpes)", seen.size() == 3, str(seen))
	check("el empujón final lanza", max_vx > 400.0, "vx=%s" % max_vx)
	check("JP vuelve a NORMAL y tiene recarga", lv.state == lv.State.NORMAL and lv.special_timer > 0.0)

	# --- muy lejos: solo alcanza el empujón (alcance máximo)
	yield(wait(0.5), "completed")
	reset(lv, Vector2(400, 440)); reset(rv, Vector2(400 + st.oar_reach + growth * 2.5, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	yield(wait(3.0), "completed")
	check("a alcance máximo solo pega el empujón", abs(rv.percent - st.special_damage * (1.0 - st.oar_swing_share)) < 0.5, "percent=%s" % rv.percent)

	# --- esquivar alejándose (fuera de alcance)
	yield(wait(0.5), "completed")
	reset(lv, Vector2(300, 440)); reset(rv, Vector2(300 + st.oar_reach + growth * 3.0 + 60, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	yield(wait(2.2), "completed")
	check("fuera de alcance: no recibe daño", rv.percent == 0.0, "percent=%s" % rv.percent)

	# --- esquivar: detrás de JP no golpea
	reset(lv, Vector2(500, 440)); reset(rv, Vector2(430, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	yield(wait(2.2), "completed")
	check("rival a la espalda: no recibe daño", rv.percent == 0.0, "percent=%s" % rv.percent)

	# --- aviso: antes de special_windup + hit_delay no hay daño
	reset(lv, Vector2(400, 440)); reset(rv, Vector2(470, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	yield(wait(st.special_windup * 0.6), "completed")
	check("durante el aviso inicial no hay daño", rv.percent == 0.0)
	yield(wait(2.0), "completed")

	# --- si golpean a JP, el especial no se anula
	reset(lv, Vector2(400, 440)); reset(rv, Vector2(470, 440))
	lv.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.05), "completed"); Input.action_release("p1_special")
	yield(wait(0.2), "completed")
	lv.take_hit(5.0, Vector2(-100, -50), rv)
	check("golpeado durante el especial: sigue en SPECIAL", lv.state == lv.State.SPECIAL)

	print("")
	print("RESULTADO: %d fallos" % fails)
	quit()
