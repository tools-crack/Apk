extends SceneTree
# test_sel_cliente.gd — CLIENTE de la prueba de selección en red (ver test_sel_host.gd)
const TEST_PORT := 7792
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func _initialize():
	_run()


func _run():
	var net = root.get_node("Net")
	var game = root.get_node("Game")
	print("== SELECCIÓN EN RED (cliente)")
	check("inicia la conexión", net.join("127.0.0.1", TEST_PORT) == OK)
	var g := 0
	while net.peer_id == 0 and g < 200:
		yield(wait(0.05), "completed")
		g += 1
	check("conectado", net.peer_id != 0)
	g = 0
	while (current_scene == null or current_scene.name != "CharSelect") and g < 300:   # el anfitrión abre la selección
		yield(wait(0.05), "completed")
		g += 1
	var cs = current_scene
	check("el cliente salta solo a la selección", cs != null and cs.name == "CharSelect")
	if cs == null:
		quit(1)
		return
	check("el cliente maneja el panel P2", cs.net_mode and cs.local_pick == cs.pick2 and cs.pick1.remote)
	yield(wait(0.5), "completed")
	var idx = cs.pick2.index
	cs.pick2._move(1)                                          # elige el siguiente personaje (lo mismo que ►)
	yield(wait(0.3), "completed")
	check("cambia de personaje", cs.pick2.index == (idx + 1) % game.ORDER.size())
	cs.pick2._set_ready(true)                                  # confirma
	yield(wait(0.3), "completed")
	check("queda listo", cs.pick2.is_ready)
	g = 0
	while (current_scene == null or not current_scene.has_method("_show_end_menu")) and g < 400:   # el anfitrión elige escenario y empieza
		yield(wait(0.05), "completed")
		g += 1
	var arena = current_scene
	check("el cliente entra a la arena", arena != null and arena.has_method("_show_end_menu"))
	check("tiene su personaje elegido como P2", arena.fighters[1].stats == game.CHARACTERS[game.ORDER[(idx + 1) % game.ORDER.size()]])
	g = 0
	while not arena.over and g < 400:                          # el anfitrión termina la partida
		yield(wait(0.05), "completed")
		g += 1
	check("el cliente ve el fin de partida", arena.over)
	yield(wait(0.5), "completed")
	check("cliente: 2 botones de fin (Pedir revancha, Salir)", arena.end_buttons.size() == 2)
	var old_id = arena.get_instance_id()
	arena.end_buttons[0].emit_signal("pressed")                # pide revancha
	g = 0
	while current_scene != null and current_scene.get_instance_id() == old_id and g < 300:
		yield(wait(0.05), "completed")
		g += 1
	check("el cliente recarga la arena por la revancha", current_scene != null and current_scene.get_instance_id() != old_id)
	yield(wait(2.0), "completed")
	print("RESULTADO cliente: %s" % ("TODO OK" if fails == 0 else "%d fallos" % fails))
	net.stop()
	quit(1 if fails > 0 else 0)
