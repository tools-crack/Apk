extends SceneTree
# ============================================================================
#  test_sel_host.gd — ANFITRIÓN de la prueba "selección de personajes en red + menú de fin"
#  (se ejecuta junto a test_sel_cliente.gd:  bash tools/probar_seleccion.sh godot)
#  Comprueba: el cliente salta a la selección, elige SU personaje y el anfitrión lo recibe; la partida empieza
#  con esos personajes; al terminar salen los botones de fin (3 en el anfitrión) y la revancha pedida por
#  el cliente recarga la arena.
# ============================================================================
const TEST_PORT := 7792
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func _initialize():
	_run()


func _arena():
	var s = current_scene
	return s if (s != null and s.has_method("_show_end_menu")) else null


func _run():
	var net = root.get_node("Net")
	var game = root.get_node("Game")
	print("== SELECCIÓN EN RED (anfitrión)")
	check("abre el puerto", net.start_host(TEST_PORT) == OK)
	var g := 0
	while net.peer_id == 0 and g < 600:
		yield(wait(0.05), "completed")
		g += 1
	check("el cliente se conecta", net.peer_id != 0)
	if net.peer_id == 0:
		quit(1)
		return
	game.practice = false
	game.goto("res://scenes/ui/CharSelect.tscn")
	yield(wait(0.6), "completed")
	var cs = current_scene
	check("anfitrión en la selección en modo red", cs != null and cs.net_mode and cs.local_pick == cs.pick1 and cs.remote_pick == cs.pick2)
	g = 0
	while net.remote_char == "" and g < 200:                   # el cliente manda su personaje al entrar
		yield(wait(0.05), "completed")
		g += 1
	check("llega el personaje inicial del cliente", net.remote_char != "", net.remote_char)
	g = 0
	while not net.remote_ready and g < 300:                    # el cliente pulsa ► y luego golpe
		yield(wait(0.05), "completed")
		g += 1
	check("el cliente eligió y confirmó", net.remote_ready)
	yield(wait(0.2), "completed")
	var want = net.remote_char                                 # lo que el cliente confirmó
	check("el panel remoto muestra lo que eligió el cliente", cs.pick2.character_id() == want and cs.pick2.is_ready, "%s / %s" % [cs.pick2.character_id(), want])
	check("el panel remoto no responde a mi teclado", cs.pick2.remote)
	cs.pick1._set_ready(true)                                  # el anfitrión confirma el suyo
	yield(wait(1.3), "completed")
	check("con los dos listos pasa a elegir escenario", current_scene != null and current_scene.name == "StageSelect", str(current_scene.name if current_scene else ""))
	check("Game.selected lleva el personaje del cliente", game.selected[1] == want, str(game.selected))
	game.goto("res://scenes/Arena.tscn")
	yield(wait(0.6), "completed")
	var arena = _arena()
	check("arena creada con los personajes elegidos", arena != null and arena.fighters[1].stats == game.CHARACTERS[want])
	g = 0
	while not net.client_ready and g < 300:
		yield(wait(0.05), "completed")
		g += 1
	check("el cliente carga la arena", net.client_ready)
	yield(wait(4.0), "completed")                              # cuenta atrás
	arena._finish(0)                                           # fin de partida (gana P1)
	yield(wait(0.5), "completed")
	check("anfitrión: 3 botones de fin (Revancha, Personajes, Menú)", arena.end_buttons.size() == 3)
	check("'Revancha' tiene el foco (Enter la activa)", arena.end_buttons[0].has_focus())
	var old_id = arena.get_instance_id()
	var old_epoch = net.epoch
	g = 0
	while _arena() != null and _arena().get_instance_id() == old_id and g < 300:   # el cliente pide revancha
		yield(wait(0.05), "completed")
		g += 1
	var a2 = _arena()
	check("la revancha del cliente recarga la arena", a2 != null and a2.get_instance_id() != old_id)
	g = 0
	while not net.client_ready and g < 200:
		yield(wait(0.05), "completed")
		g += 1
	check("el cliente vuelve a cargar (revancha)", net.client_ready and net.epoch == old_epoch + 1, "epoch=%d" % net.epoch)
	yield(wait(1.0), "completed")
	print("RESULTADO anfitrión: %s" % ("TODO OK" if fails == 0 else "%d fallos" % fails))
	net.stop()
	quit(1 if fails > 0 else 0)
