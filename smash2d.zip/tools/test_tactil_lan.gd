extends SceneTree
# test_tactil_lan.gd — controles táctiles (multitoque, stick flotante, contadores) y menú LAN
#   godot --path . -s tools/test_tactil_lan.gd
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func touch(root, idx, pos, pressed):
	var e = InputEventScreenTouch.new()
	e.index = idx
	e.position = pos
	e.pressed = pressed
	root._input(e)


func drag(root, idx, pos):
	var e = InputEventScreenDrag.new()
	e.index = idx
	e.position = pos
	root._input(e)


func _init():
	print("== TÁCTIL Y LAN")
	var tc = load("res://scripts/ui/TouchControls.gd").new()
	tc.player = 2
	root.add_child(tc)
	yield(create_timer(0.1), "timeout")
	touch(tc, 0, Vector2(200, 500), true)                       # stick flotante: toca y arrastra a la derecha
	drag(tc, 0, Vector2(330, 500))
	check("stick a la derecha = p2_right", Input.is_action_pressed("p2_right") and not Input.is_action_pressed("p2_left"))
	touch(tc, 1, Vector2(1130, 585), true)                      # segundo dedo: GOLPE
	touch(tc, 2, Vector2(1152, 422), true)                      # tercer dedo: SALTO
	check("multitoque: mover + golpear + saltar a la vez", Input.is_action_pressed("p2_right") and Input.is_action_pressed("p2_attack") and Input.is_action_pressed("p2_jump"))
	drag(tc, 0, Vector2(330, 380))                              # stick arriba: también salto
	touch(tc, 2, Vector2(1152, 422), false)
	check("soltar el botón SALTO no suelta el salto del stick", Input.is_action_pressed("p2_jump"))
	touch(tc, 1, Vector2(1130, 585), false)
	check("soltar GOLPE", not Input.is_action_pressed("p2_attack"))
	drag(tc, 0, Vector2(100, 560))                              # el stick sigue al dedo y cambia a izquierda
	check("stick a la izquierda", Input.is_action_pressed("p2_left") and not Input.is_action_pressed("p2_right"))
	touch(tc, 0, Vector2(100, 560), false)
	check("al levantar el dedo se sueltan todas las direcciones", not Input.is_action_pressed("p2_left") and not Input.is_action_pressed("p2_jump") and not Input.is_action_pressed("p2_right"))
	touch(tc, 3, Vector2(962, 640), true)
	tc._release_all()
	check("_release_all suelta los botones", not Input.is_action_pressed("p2_special"))
	tc.queue_free()
	var pk = load("res://scenes/ui/PickPanel.tscn").instance()   # selección de personaje sin teclado
	root.add_child(pk)
	pk.setup(1, root.get_node("Game").ORDER[0])
	var i0 = pk.index
	pk._arrows[1].emit_signal("pressed")
	check("flecha ► táctil cambia de personaje", pk.index == (i0 + 1) % root.get_node("Game").ORDER.size())
	pk._arrows[0].emit_signal("pressed")
	check("flecha ◄ táctil vuelve", pk.index == i0)
	var ev = InputEventMouseButton.new()
	ev.button_index = BUTTON_LEFT
	ev.pressed = true
	pk._on_badge_input(ev)
	check("tocar LISTO confirma", pk.is_ready)
	pk._arrows[1].emit_signal("pressed")
	check("ya listo: las flechas no cambian el personaje", pk.index == i0)
	pk._on_badge_input(ev)
	check("tocar LISTO otra vez cancela", not pk.is_ready)
	pk.queue_free()
	var lan = load("res://scenes/ui/Lan.tscn").instance()
	root.add_child(lan)
	yield(create_timer(0.3), "timeout")
	check("el menú LAN se construye (tiene botones)", lan._col.get_child_count() > 0)
	lan.queue_free()
	yield(create_timer(0.1), "timeout")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
