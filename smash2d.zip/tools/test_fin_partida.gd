extends SceneTree
# test_fin_partida.gd — al ganar: botones (Revancha / Elegir personajes / Menú) y Enter.
#   godot --path . --no-window -s tools/test_fin_partida.gd
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func _initialize():
	_run()


func _run():
	var game = root.get_node("Game")
	game.selected = ["levaro", "topo"]
	game.practice = false
	game.goto("res://scenes/Arena.tscn")
	yield(wait(4.4), "completed")
	var arena = current_scene
	check("arena offline creada", arena != null and arena.name == "Arena")
	check("sin botones antes de terminar", arena.end_menu == null)
	arena._finish(0)
	yield(wait(0.6), "completed")
	check("aparecen 3 botones", arena.end_buttons.size() == 3)
	check("'Revancha' tiene el foco", arena.end_buttons[0].has_focus())
	check("los botones son visibles y tocables (tamaño >= 48 px)", arena.end_buttons[0].rect_size.y >= 48 and arena.end_buttons[0].is_visible_in_tree())
	var old = arena.get_instance_id()
	var ev = InputEventKey.new()
	ev.scancode = KEY_ENTER
	ev.pressed = true
	arena._input(ev)                                             # Enter en PC (el test headless no entrega teclas a la GUI, se llama directo)
	yield(wait(0.8), "completed")
	check("Enter = revancha (arena nueva)", current_scene != null and current_scene.get_instance_id() != old and current_scene.name == "Arena")
	yield(wait(4.4), "completed")
	arena = current_scene
	check("la revancha empieza sin menú de fin", arena.end_menu == null and not arena.over)
	arena._finish(1)
	yield(wait(0.6), "completed")
	arena.end_buttons[1].emit_signal("pressed")                 # "Elegir personajes" (toque)
	yield(wait(0.8), "completed")
	check("'Elegir personajes' abre la selección", current_scene != null and current_scene.name == "CharSelect")
	game.goto("res://scenes/Arena.tscn")
	yield(wait(4.4), "completed")
	arena = current_scene
	arena._finish(0)
	yield(wait(0.6), "completed")
	arena.end_buttons[2].emit_signal("pressed")                 # "Menú" (toque)
	yield(wait(0.8), "completed")
	check("'Menú' vuelve al menú principal", current_scene != null and current_scene.name == "MainMenu")
	print("")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
