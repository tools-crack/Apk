#!/bin/bash
# Prueba de red: selección de personajes del cliente + menú de fin de partida + revancha (dos procesos de Godot).
#   bash tools/probar_seleccion.sh [ruta/a/godot]      ambos deben decir TODO OK
GODOT=${1:-godot}
cd "$(dirname "$0")/.."
$GODOT --path . --no-window -s tools/test_sel_host.gd > ${TMPDIR:-/tmp}/sel_host.log 2>&1 &
H=$!
sleep 1.5
$GODOT --path . --no-window -s tools/test_sel_cliente.gd > ${TMPDIR:-/tmp}/sel_cliente.log 2>&1 &
C=$!
wait $H $C
echo "---- anfitrión"; cat ${TMPDIR:-/tmp}/sel_host.log
echo "---- cliente";   cat ${TMPDIR:-/tmp}/sel_cliente.log
