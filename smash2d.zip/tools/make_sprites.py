#!/usr/bin/env python3
"""Genera todos los sprites SVG del proyecto y los recursos SpriteFrames (.tres).

Uso:  python3 tools/make_sprites.py

Los stickman se dibujan con cinemática inversa: cada pose define dónde están
los pies y las manos y el script calcula rodillas y codos. Para crear un
personaje nuevo basta con añadir una entrada en CHARACTERS.

Nota: Godot 3 importa SVG con nanosvg, que NO soporta clipPath, filtros ni
máscaras. Por eso el "hundirse en la tierra" se recorta aquí, geométricamente.
"""
import math
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, ".."))
SPR = os.path.join(PROJ, "assets", "sprites")
RES = os.path.join(PROJ, "resources")

OUTLINE = "#1b1b2f"
SKIN = "#fff1dc"
GROUND = 104      # y del suelo dentro del lienzo de 128x128
CLIP = 106        # y a partir de la cual la tierra "se traga" al personaje


# ----------------------------------------------------------------- utilidades
def fmt(v):
    return ("%.2f" % v).rstrip("0").rstrip(".")


def pts_attr(pts):
    return " ".join("%s,%s" % (fmt(x), fmt(y)) for x, y in pts)


def darken(color, f):
    r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
    return "#%02x%02x%02x" % (int(r * f), int(g * f), int(b * f))


def lighten(color, f):
    """Mezcla el color con blanco (f=0 igual, f=1 blanco)."""
    r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
    return "#%02x%02x%02x" % (int(r + (255 - r) * f), int(g + (255 - g) * f), int(b + (255 - b) * f))


def vec(angle_deg, length):
    """Vector con ángulo medido desde "arriba", en sentido horario."""
    a = math.radians(angle_deg)
    return (math.sin(a) * length, -math.cos(a) * length)


def rot(p, c, deg):
    a = math.radians(deg)
    x, y = p[0] - c[0], p[1] - c[1]
    return (c[0] + x * math.cos(a) - y * math.sin(a),
            c[1] + x * math.sin(a) + y * math.cos(a))


def ik(root, target, l1, l2, prefer):
    """Cinemática inversa de 2 huesos. Devuelve (articulación, extremo)."""
    rx, ry = root
    dx, dy = target[0] - rx, target[1] - ry
    dist = math.hypot(dx, dy) or 1e-6
    d = max(min(dist, l1 + l2 - 0.01), abs(l1 - l2) + 0.01)
    ux, uy = dx / dist, dy / dist
    end = (rx + ux * d, ry + uy * d)
    c = (l1 * l1 + d * d - l2 * l2) / (2 * l1 * d)
    ang = math.acos(max(-1.0, min(1.0, c)))
    base = math.atan2(dy, dx)
    cands = [(rx + l1 * math.cos(base + s * ang), ry + l1 * math.sin(base + s * ang))
             for s in (1, -1)]
    mid = ((rx + end[0]) / 2, (ry + end[1]) / 2)
    best = max(cands, key=lambda k: (k[0] - mid[0]) * prefer[0] + (k[1] - mid[1]) * prefer[1])
    return best, end


# ------------------------------------------------------------- recorte (clip)
def clip_polyline(pts, y):
    if y is None:
        return [pts]
    runs, cur = [], []
    for a, b in zip(pts, pts[1:]):
        ain, bin_ = a[1] <= y, b[1] <= y
        if not ain and not bin_:
            if cur:
                runs.append(cur)
                cur = []
            continue
        if ain and bin_:
            s, e = a, b
        else:
            t = (y - a[1]) / (b[1] - a[1])
            ip = (a[0] + t * (b[0] - a[0]), y)
            s, e = (a, ip) if ain else (ip, b)
        if cur and cur[-1] == s:
            cur.append(e)
        else:
            if cur:
                runs.append(cur)
            cur = [s, e]
        if e != b:
            runs.append(cur)
            cur = []
    if cur:
        runs.append(cur)
    return runs


def clip_poly(pts, y):
    out = []
    n = len(pts)
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        ain, bin_ = a[1] <= y, b[1] <= y
        if ain:
            out.append(a)
        if ain != bin_:
            t = (y - a[1]) / (b[1] - a[1])
            out.append((a[0] + t * (b[0] - a[0]), y))
    return out


class Canvas:
    def __init__(self, w=128, h=128, clip=None, out_size=None, view=None):
        self.w, self.h, self.clip = w, h, clip
        self.out_size = out_size or (w, h)
        self.view = view or (0, 0, w, h)
        self.parts = []

    def raw(self, s):
        self.parts.append(s)

    def line(self, pts, color, width, outline=True, opacity=1.0):
        for run in clip_polyline(pts, self.clip):
            if len(run) < 2:
                continue
            if outline:
                self.parts.append(
                    '<polyline points="%s" fill="none" stroke="%s" stroke-width="%s" '
                    'stroke-linecap="round" stroke-linejoin="round"/>'
                    % (pts_attr(run), OUTLINE, fmt(width + 3.5)))
            op = '' if opacity >= 1 else ' stroke-opacity="%s"' % fmt(opacity)
            self.parts.append(
                '<polyline points="%s" fill="none" stroke="%s" stroke-width="%s" '
                'stroke-linecap="round" stroke-linejoin="round"%s/>'
                % (pts_attr(run), color, fmt(width), op))

    def disc(self, cx, cy, r, fill, opacity=1.0):
        c = self.clip
        op = '' if opacity >= 1 else ' fill-opacity="%s"' % fmt(opacity)
        if c is None or cy + r <= c:
            self.parts.append('<circle cx="%s" cy="%s" r="%s" fill="%s"%s/>'
                              % (fmt(cx), fmt(cy), fmt(r), fill, op))
            return
        if cy - r >= c:
            return
        h = c - cy
        w = math.sqrt(max(r * r - h * h, 0))
        large = 1 if h > 0 else 0
        d = "M %s %s A %s %s 0 %d 1 %s %s Z" % (
            fmt(cx - w), fmt(c), fmt(r), fmt(r), large, fmt(cx + w), fmt(c))
        self.parts.append('<path d="%s" fill="%s"%s/>' % (d, fill, op))

    def poly(self, pts, fill, stroke=OUTLINE, sw=2.0):
        if self.clip is not None:
            pts = clip_poly(pts, self.clip)
        if len(pts) < 3:
            return
        self.parts.append(
            '<polygon points="%s" fill="%s" stroke="%s" stroke-width="%s" stroke-linejoin="round"/>'
            % (pts_attr(pts), fill, stroke, fmt(sw)))

    def svg(self):
        return ('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" '
                'viewBox="%s %s %s %s">\n%s\n</svg>\n'
                % (self.out_size[0], self.out_size[1], fmt(self.view[0]), fmt(self.view[1]),
                   fmt(self.view[2]), fmt(self.view[3]), "\n".join(self.parts)))


# -------------------------------------------------------------- accesorios
def hat_sailor(cv, c, tilt):
    R = 13.0
    pts = [rot((c[0] + R * math.cos(math.radians(a)), c[1] - 3 + R * math.sin(math.radians(a))), c, tilt)
           for a in range(-180, 1, 15)]
    cv.poly(pts, "#ffffff")
    band = [rot((c[0] - R, c[1] - 3), c, tilt), rot((c[0] + R + 1, c[1] - 3), c, tilt)]
    cv.line(band, "#2f5fb5", 3.4)
    tuft = rot((c[0] - 2, c[1] - 17), c, tilt)
    cv.disc(tuft[0], tuft[1], 2.6, "#d9433b")


def hat_miner(cv, c, tilt):
    R = 13.6
    pts = [rot((c[0] + R * math.cos(math.radians(a)), c[1] - 3.5 + R * math.sin(math.radians(a))), c, tilt)
           for a in range(-180, 1, 15)]
    cv.poly(pts, "#f6c431")
    cv.line([rot((c[0], c[1] - 16.5), c, tilt), rot((c[0], c[1] - 6), c, tilt)], "#d19a12", 2.2, outline=False)
    cv.line([rot((c[0] - 14.5, c[1] - 3.5), c, tilt), rot((c[0] + 19, c[1] - 3.5), c, tilt)], "#f6c431", 3.0)
    lamp = rot((c[0] + 10.5, c[1] - 10), c, tilt)
    cv.disc(lamp[0], lamp[1], 4.8, OUTLINE)
    cv.disc(lamp[0], lamp[1], 3.3, "#fffbe0")


def hat_chef(cv, c, tilt):
    """Gorro de cocinero (Aukin): copa esponjosa blanca sobre una banda."""
    for dx, dy, r in [(-8, -21, 6.8), (0, -25, 7.8), (8, -21, 6.8)]:
        p = rot((c[0] + dx, c[1] + dy), c, tilt)
        cv.disc(p[0], p[1], r + 1.6, OUTLINE)
    for dx, dy, r in [(-8, -21, 6.8), (0, -25, 7.8), (8, -21, 6.8)]:
        p = rot((c[0] + dx, c[1] + dy), c, tilt)
        cv.disc(p[0], p[1], r, "#ffffff")
    band = [rot((c[0] - 11, c[1] - 7), c, tilt), rot((c[0] + 11, c[1] - 7), c, tilt),
            rot((c[0] + 10, c[1] - 16), c, tilt), rot((c[0] - 10, c[1] - 16), c, tilt)]
    cv.poly(band, "#ffffff")
    cv.line([rot((c[0] - 11, c[1] - 9), c, tilt), rot((c[0] + 11, c[1] - 9), c, tilt)], "#d9433b", 2.4,
            outline=False)


def hat_rock(cv, c, tilt):
    """Casco de piedra (Likan): media cúpula gris con dos bultos."""
    R = 13.4
    pts = [rot((c[0] + R * math.cos(math.radians(a)), c[1] - 3 + R * math.sin(math.radians(a))), c, tilt)
           for a in range(-180, 1, 15)]
    cv.poly(pts, "#8c909c")
    for dx, dy, r in [(-5, -13, 2.6), (4, -9, 2.0)]:
        p = rot((c[0] + dx, c[1] + dy), c, tilt)
        cv.disc(p[0], p[1], r, "#b4b8c4")
    cv.line([rot((c[0] - 14, c[1] - 3), c, tilt), rot((c[0] + 14, c[1] - 3), c, tilt)], "#8c909c", 3.0)


def hat_cap(cv, c, tilt):
    """Gorra plana (Ñanco): copa roja oscura y visera hacia delante."""
    R = 12.6
    pts = [rot((c[0] + R * math.cos(math.radians(a)), c[1] - 4 + R * math.sin(math.radians(a))), c, tilt)
           for a in range(-180, 1, 15)]
    cv.poly(pts, "#3b3f58")
    cv.line([rot((c[0] - 1, c[1] - 4), c, tilt), rot((c[0] + 20, c[1] - 2), c, tilt)], "#3b3f58", 3.4)
    cv.disc(*rot((c[0] - 1, c[1] - 15), c, tilt), 1.8, "#d1485a")


def hat_spiky(cv, c, tilt):
    """Pelo de pinchos (Winkul): cinco picos de color alrededor de la cabeza."""
    for ang, ln in [(-150, 11), (-120, 14), (-90, 16), (-60, 14), (-30, 11)]:
        base = (c[0] + 7.5 * math.cos(math.radians(ang)), c[1] + 7.5 * math.sin(math.radians(ang)))
        tip = (c[0] + (7.5 + ln) * math.cos(math.radians(ang)), c[1] + (7.5 + ln) * math.sin(math.radians(ang)))
        side = (math.cos(math.radians(ang + 90)) * 3.6, math.sin(math.radians(ang + 90)) * 3.6)
        cv.poly([rot((base[0] - side[0], base[1] - side[1]), c, tilt), rot(tip, c, tilt),
                 rot((base[0] + side[0], base[1] + side[1]), c, tilt)], "#e8f4f2")


def hat_fisher(cv, c, tilt):
    """Sombrero de pescador (Jorge): copa redonda color paja y ala ancha con una cinta."""
    R = 10.8
    cv.line([rot((c[0] - 16, c[1] - 5), c, tilt), rot((c[0] + 16, c[1] - 5), c, tilt)], "#e6c97a", 3.6)
    pts = [rot((c[0] + R * math.cos(math.radians(a)), c[1] - 5 + R * math.sin(math.radians(a))), c, tilt)
           for a in range(-180, 1, 15)]
    cv.poly(pts, "#e6c97a")
    cv.line([rot((c[0] - R + 0.5, c[1] - 7.5), c, tilt), rot((c[0] + R - 0.5, c[1] - 7.5), c, tilt)], "#7a5a2e", 2.4,
            outline=False)


HATS = {"sailor": hat_sailor, "miner": hat_miner, "chef": hat_chef, "rock": hat_rock,
        "cap": hat_cap, "spiky": hat_spiky, "fisher": hat_fisher}


# ---------------------------------------------------------------- stickman
# Estilo del personaje (se puede cambiar por personaje en CHARACTERS / personajes_extra.json):
#   color    color de acento (menús, HUD). Si no hay "shirt", también es el de la camiseta
#   shirt    camiseta / abrigo        pants   pantalón        shoe    zapatos
#   skin     piel                     hair    color del pelo  hair_style  "spiky" | "tuft" | "none"
#   glasses  "round" (anteojos) | "goggles" (antiparras oscuras) | None
#   claws    True = garras en las manos     build  "normal" | "stocky" (más ancho y bajo)
STYLE_DEFAULTS = dict(skin="#f6d08c", hair="#ffa62b", hair_style="spiky", glasses="round",
                      shoe="#8a5a2b", claws=False, build="normal")


def style_of(ch):
    st = dict(STYLE_DEFAULTS)
    st.update(ch)
    st["shirt"] = ch.get("shirt", ch["color"])
    st["pants"] = ch.get("pants", darken(ch["color"], 0.5))
    return st


def hair_spiky(cv, c, tilt, col, r=13.4):
    """Pelo de picos (como el de la imagen de referencia): cubre la parte de arriba y cae un mechón al frente."""
    pts = []
    spikes = [(-205, 24), (-182, 17), (-158, 25), (-132, 19), (-108, 26), (-82, 20), (-58, 24), (-32, 17), (-8, 21)]
    pts.append((c[0] + math.cos(math.radians(-212)) * (r + 1), c[1] + math.sin(math.radians(-212)) * (r + 1)))
    for ang, tip in spikes:
        valley = ang - 12
        pts.append((c[0] + math.cos(math.radians(valley)) * (r - 0.5), c[1] + math.sin(math.radians(valley)) * (r - 0.5)))
        pts.append((c[0] + math.cos(math.radians(ang)) * tip, c[1] + math.sin(math.radians(ang)) * tip))
    pts.append((c[0] + math.cos(math.radians(8)) * (r - 1), c[1] + math.sin(math.radians(8)) * (r - 1)))   # sien delantera
    pts.append((c[0] + 2.0, c[1] - 6.5))                                                                 # flequillo
    pts.append((c[0] - 6.0, c[1] - 3.0))
    pts.append((c[0] - 11.5, c[1] + 1.0))
    cv.poly([rot(p, c, tilt) for p in pts], col, sw=2.2)


def hair_tuft(cv, c, tilt, col, r=13.4):
    """Pelo ralo: un mechón despeinado arriba y otro atrás (Mole Man)."""
    pts = [(c[0] - 11, c[1] - 3), (c[0] - 14, c[1] - 11), (c[0] - 7, c[1] - 9), (c[0] - 6, c[1] - 18),
           (c[0] - 1, c[1] - 11), (c[0] + 4, c[1] - 17), (c[0] + 5, c[1] - 9), (c[0] + 11, c[1] - 8),
           (c[0] + 8, c[1] - 3), (c[0] - 4, c[1] - 6)]
    cv.poly([rot(p, c, tilt) for p in pts], col, sw=2.0)


def glasses_round(cv, c, tilt, eye, hurt):
    """Anteojos redondos de lente blanca y aro oscuro; patilla hacia atrás."""
    ex, ey = eye
    cv.line([rot((c[0] - 9.5, c[1] - 1.2), c, tilt), (ex - 4.5, ey)], OUTLINE, 1.6, outline=False)
    cv.disc(ex, ey, 6.2, OUTLINE)
    cv.disc(ex, ey, 4.5, "#fffaf0")
    if hurt:
        cv.line([(ex - 2.4, ey - 2.4), (ex + 2.4, ey + 2.4)], OUTLINE, 1.6, outline=False)
        cv.line([(ex - 2.4, ey + 2.4), (ex + 2.4, ey - 2.4)], OUTLINE, 1.6, outline=False)
    else:
        cv.disc(ex + 0.9, ey, 1.9, OUTLINE)


def goggles(cv, c, tilt, eye, hurt):
    """Antiparras oscuras y gruesas (Mole Man): lente negra con brillo y correa."""
    ex, ey = eye
    cv.line([rot((c[0] - 12, c[1] - 1.5), c, tilt), (ex - 4, ey)], "#2a2a33", 3.0, outline=False)
    cv.disc(ex, ey, 8.2, OUTLINE)
    cv.disc(ex, ey, 6.6, "#15151d")
    cv.disc(ex - 2.0, ey - 2.2, 1.7, "#7a7f99")
    if hurt:
        cv.line([(ex - 3, ey - 3), (ex + 3, ey + 3)], "#e8e8f0", 1.6, outline=False)
        cv.line([(ex - 3, ey + 3), (ex + 3, ey - 3)], "#e8e8f0", 1.6, outline=False)


def draw_stickman(cv, pose, ch):
    st = style_of(ch)
    stocky = st["build"] == "stocky"
    dy = pose.get("dy", 0)

    def sh(p):
        return (p[0], p[1] + dy)

    hip = sh(pose["hip"])
    lean = pose.get("lean", 0)
    tilt = pose.get("tilt", 0)
    tdx, tdy = vec(lean, 1)
    neck = (hip[0] + tdx * 24, hip[1] + tdy * 24)
    shoulder = (hip[0] + tdx * 21, hip[1] + tdy * 21)
    hdx, hdy = vec(lean + tilt, 1)
    head_r = 13.0 if not stocky else 14.2
    head = (neck[0] + hdx * 10.5, neck[1] + hdy * 10.5)
    shirt, pants = st["shirt"], st["pants"]
    shirt_back, pants_back = darken(shirt, 0.66), darken(pants, 0.7)
    torso = lighten(shirt, 0.55)
    WA, WL, WT = (8.6, 9.6, 8.0) if not stocky else (10.8, 11.8, 12.5)      # grosor brazos, piernas, torso

    def limb(root, target, l1, l2, prefer):
        mid, end = ik(root, sh(target), l1, l2, prefer)
        return [root, mid, end]

    leg_b = limb(hip, pose["fB"], 17, 17, (1, 0))
    leg_f = limb(hip, pose["fF"], 17, 17, (1, 0))
    arm_b = limb(shoulder, pose["hB"], 13, 13, (-0.4, 1))
    arm_f = limb(shoulder, pose["hF"], 13, 13, (-0.4, 1))

    def shoe(leg, col):
        fx, fy = leg[-1]
        cv.disc(fx + 3.0, fy - 1.2, 5.8 if not stocky else 6.6, OUTLINE)
        cv.disc(fx + 3.0, fy - 1.2, 4.2 if not stocky else 5.0, col)

    def hand(arm, col):
        hx, hy = arm[-1]
        cv.disc(hx, hy, 5.8 if not stocky else 6.6, OUTLINE)
        cv.disc(hx, hy, 4.2 if not stocky else 5.0, col)
        if st["claws"]:
            for k in (-1, 0, 1):
                cv.line([(hx + 3 + k * 0.4, hy + k * 3.2), (hx + 9, hy + k * 4.6)], "#d9d4c4", 2.0)

    # atrás -> delante
    cv.line(arm_b, shirt_back, WA)
    hand(arm_b, darken(st["skin"], 0.82))
    cv.line(leg_b, pants_back, WL)
    shoe(leg_b, darken(st["shoe"], 0.78))
    cv.line([hip, neck], torso, WT)
    cv.line(leg_f, pants, WL)
    shoe(leg_f, st["shoe"])
    cv.line(arm_f, shirt, WA)
    hand(arm_f, st["skin"])
    # cabeza
    cv.disc(head[0], head[1], head_r + 1.8, OUTLINE)
    cv.disc(head[0], head[1], head_r, st["skin"])
    ex, ey = rot((head[0] + 5.2, head[1] + 0.6), head, tilt)
    hurt = pose.get("mood") == "hurt"
    if st["hair_style"] == "spiky":
        hair_spiky(cv, head, tilt, st["hair"], head_r)
    elif st["hair_style"] == "tuft":
        hair_tuft(cv, head, tilt, st["hair"], head_r)
    # boca
    mx, my = rot((head[0] + 5.5, head[1] + 7.2), head, tilt)
    cv.line([(mx - 3.4, my), (mx + 0.6, my + 0.4)], OUTLINE, 1.5, outline=False)
    if st["glasses"] == "goggles":
        goggles(cv, head, tilt, (ex, ey), hurt)
    elif st["glasses"] == "round":
        glasses_round(cv, head, tilt, (ex, ey), hurt)
    else:
        if hurt:
            cv.line([(ex - 2.2, ey - 2.2), (ex + 2.2, ey + 2.2)], OUTLINE, 1.6, outline=False)
            cv.line([(ex - 2.2, ey + 2.2), (ex + 2.2, ey - 2.2)], OUTLINE, 1.6, outline=False)
        else:
            cv.disc(ex, ey, 1.9, OUTLINE)
    hat = HATS.get(ch.get("hat"))
    if hat:
        hat(cv, head, tilt)
    return {"hand_f": arm_f[-1], "head": head}


# ------------------------------------------------------------------- poses
def idle_pose(k):
    if k == 0:
        return dict(hip=(64, 71), lean=5, fF=(72, 104), fB=(56, 104), hF=(82, 54), hB=(75, 60))
    return dict(hip=(64, 73), lean=7, fF=(72, 104), fB=(56, 104), hF=(82, 57), hB=(75, 63))


def run_pose(k, n=6):
    p = k / n

    def foot(ph):
        ph %= 1.0
        if ph < 0.5:
            return (64 + 15 - 30 * (ph / 0.5), GROUND)
        s = (ph - 0.5) / 0.5
        return (64 - 15 + 30 * s, GROUND - 17 * math.sin(math.pi * s))

    f_f, f_b = foot(p), foot(p + 0.5)
    hip_y = 73 - 2.5 * abs(math.sin(2 * math.pi * p))
    return dict(hip=(66, hip_y), lean=14, tilt=-4, fF=f_f, fB=f_b,
                hF=(73 + 0.9 * (f_b[0] - 64), 62), hB=(73 + 0.9 * (f_f[0] - 64), 62))


JUMP = dict(hip=(64, 70), lean=4, fF=(76, 94), fB=(54, 100), hF=(88, 36), hB=(44, 40))
FALL = dict(hip=(64, 72), lean=-2, fF=(72, 100), fB=(56, 102), hF=(90, 58), hB=(38, 58))
HURT = dict(hip=(60, 74), lean=-16, tilt=-10, fF=(74, 100), fB=(50, 104), hF=(86, 46), hB=(36, 60),
            mood="hurt")

ATTACK = [
    dict(hip=(62, 76), lean=-8, fF=(80, 104), fB=(46, 104), hF=(48, 60), hB=(74, 54)),
    dict(hip=(68, 75), lean=16, fF=(84, 104), fB=(50, 104), hF=(104, 52), hB=(66, 60)),
    dict(hip=(66, 74), lean=6, fF=(76, 104), fB=(54, 104), hF=(92, 58), hB=(72, 60)),
]

SUMMON = [
    dict(hip=(60, 76), lean=-8, fF=(74, 104), fB=(48, 104), hF=(50, 80), hB=(44, 74)),
    dict(hip=(66, 73), lean=12, fF=(78, 104), fB=(52, 104), hF=(100, 44), hB=(88, 38)),
    dict(hip=(66, 72), lean=14, fF=(78, 104), fB=(52, 104), hF=(104, 38), hB=(92, 34)),
]

# Aukin: vierte los tallarines hacia el suelo (manos abajo y delante)
POUR = [
    dict(hip=(60, 76), lean=-6, fF=(74, 104), fB=(48, 104), hF=(62, 86), hB=(54, 82)),
    dict(hip=(68, 78), lean=18, fF=(80, 104), fB=(52, 104), hF=(98, 98), hB=(90, 94)),
    dict(hip=(68, 78), lean=20, fF=(80, 104), fB=(52, 104), hF=(102, 102), hB=(94, 98)),
]

# Ñanco: lleva el cigarro a la boca, aspira (se echa hacia atrás) y exhala
SMOKE = [
    dict(hip=(62, 74), lean=-2, fF=(76, 104), fB=(50, 104), hF=(76, 40), hB=(60, 78)),
    dict(hip=(60, 75), lean=-12, fF=(76, 104), fB=(48, 104), hF=(72, 36), hB=(56, 78)),
    dict(hip=(66, 73), lean=12, fF=(80, 104), fB=(50, 104), hF=(94, 62), hB=(66, 70)),
]

# Jorge: lanza la caña (hacia atrás, hacia delante y quieto) y luego la voltea por encima de la cabeza
JORGE_CAST = [
    dict(hip=(60, 76), lean=-12, fF=(74, 104), fB=(48, 104), hF=(48, 44), hB=(56, 52)),
    dict(hip=(66, 74), lean=14, fF=(82, 104), fB=(52, 104), hF=(92, 48), hB=(80, 52)),
    dict(hip=(66, 74), lean=10, fF=(80, 104), fB=(52, 104), hF=(92, 50), hB=(80, 54)),
]
JORGE_THROW = [
    dict(hip=(64, 74), lean=0, fF=(78, 104), fB=(50, 104), hF=(72, 30), hB=(66, 36)),
    dict(hip=(60, 76), lean=-14, fF=(76, 104), fB=(48, 104), hF=(44, 40), hB=(54, 50)),
]

# Levaro: remo alzado detrás, remazo hacia delante y empujón con el remo horizontal
LEVARO_RAISE = [
    dict(hip=(60, 76), lean=-12, fF=(74, 104), fB=(48, 104), hF=(50, 46), hB=(58, 52)),
    dict(hip=(60, 76), lean=-16, fF=(74, 104), fB=(48, 104), hF=(46, 42), hB=(56, 50)),
]
LEVARO_SWING = [
    dict(hip=(66, 74), lean=14, fF=(82, 104), fB=(52, 104), hF=(94, 56), hB=(82, 58)),
    dict(hip=(68, 74), lean=18, fF=(84, 104), fB=(52, 104), hF=(98, 70), hB=(86, 70)),
]
LEVARO_PUSH = [
    dict(hip=(66, 74), lean=12, fF=(82, 104), fB=(52, 104), hF=(88, 56), hB=(78, 58)),
    dict(hip=(70, 74), lean=20, fF=(90, 104), fB=(54, 104), hF=(94, 58), hB=(84, 58)),
]

DIVER = dict(hip=(64, 72), lean=0, fF=(68, 104), fB=(60, 104), hF=(67, 30), hB=(62, 31))
UPPERCUT = dict(hip=(64, 70), lean=8, fF=(74, 100), fB=(58, 97), hF=(84, 22), hB=(50, 58))


# ------------------------------------------------------------ efectos suelo
def swoosh(cv, info=None):
    cv.line([(92, 32), (108, 44), (114, 62), (106, 78)], "#ffffff", 3.0, outline=False, opacity=0.85)
    cv.line([(86, 40), (99, 50), (103, 64)], "#ffffff", 1.8, outline=False, opacity=0.6)


def feathers(cv, info=None):
    for (x, y, a) in [(110, 30, -30), (100, 20, 20), (114, 46, 40), (92, 26, -60)]:
        pts = [rot((x + dx, y + dy), (x, y), a) for dx, dy in [(-6, 0), (0, -2.6), (6, 0), (0, 2.6)]]
        cv.poly(pts, "#ffffff", sw=1.2)


def pebbles(cv, info=None):
    """Likan: piedrecitas flotando sobre sus manos al invocar."""
    for (x, y, r, a) in [(98, 24, 4.2, 20), (110, 34, 3.2, -30), (88, 14, 3.0, 50), (104, 12, 2.6, 0)]:
        pts = [rot((x + dx, y + dy), (x, y), a) for dx, dy in [(-r, 0), (-r * 0.4, -r), (r * 0.8, -r * 0.7),
                                                               (r, r * 0.5), (-r * 0.2, r)]]
        cv.poly(pts, "#9a9ea9", sw=1.4)


def noodle_swirl(cv, info=None):
    """Aukin: tallarines que se enroscan al caer desde sus manos."""
    for (x0, y0, ph) in [(104, 100, 0), (96, 96, 1)]:
        pts = [(x0 + 5 * math.sin(i * 1.3 + ph), y0 + i * 2.4) for i in range(0, 5)]
        cv.line(pts, "#f2c94c", 3.2)


def cigarette(cv, info):
    """Ñanco: cigarro en la boca con brasa y una voluta de humo."""
    hx, hy = info["head"]
    cv.line([(hx + 5, hy + 3), (hx + 15, hy + 5)], "#f4f0e6", 2.6)
    cv.disc(hx + 16.5, hy + 5.3, 2.3, "#ff6a2b")
    cv.disc(hx + 16.5, hy + 5.3, 1.1, "#ffd27a")
    for i, (dx, dy, r) in enumerate([(20, -2, 3.0), (24, -9, 4.0), (21, -17, 4.8)]):
        cv.disc(hx + dx, hy + dy, r, "#d8dde6", opacity=0.75 - i * 0.18)


def smoke_blow(cv, info):
    """Ñanco exhala: nube de humo delante de la cara."""
    hx, hy = info["head"]
    for i, (dx, dy, r) in enumerate([(12, 4, 3.5), (21, 2, 5.0), (31, 0, 6.5), (43, -2, 8.0)]):
        cv.disc(hx + dx, hy + dy, r, "#dfe4ec", opacity=0.9 - i * 0.15)
    cigarette_stub = [(hx + 4, hy + 4), (hx + 10, hy + 5)]
    cv.line(cigarette_stub, "#f4f0e6", 2.4)


def spike_burst(cv, info=None):
    """Winkul: tres pinchos que asoman del suelo junto a su mano."""
    for x, h in [(100, 16), (110, 24), (120, 14)]:
        cv.poly([(x - 5, GROUND), (x, GROUND - h), (x + 5, GROUND)], "#cfd8e3", sw=1.8)


def rod(dx, dy):
    """Fábrica de extras: una caña de pescar que sale de la mano delantera hacia (dx, dy)."""
    def draw(cv, info):
        hx, hy = info["hand_f"]
        cv.line([(hx, hy), (hx + dx, hy + dy)], "#8a5a2b", 2.6)
        cv.disc(hx + dx, hy + dy, 1.7, "#e8e8f0")          # punta de la caña
        cv.disc(hx, hy, 2.8, "#4a4a5e")                    # carrete
    return draw


def oar(dx, dy):
    """Fábrica de extras: un remo (palo de madera y pala ancha en la punta) que sale de la mano delantera."""
    def draw(cv, info):
        hx, hy = info["hand_f"]
        L = math.hypot(dx, dy)
        ux, uy = dx / L, dy / L                           # dirección del remo
        px, py = -uy, ux                                  # perpendicular (ancho de la pala)
        tx, ty = hx + dx, hy + dy
        cv.line([(hx - ux * 7, hy - uy * 7), (tx, ty)], "#8a5a2b", 2.6)               # palo (sobresale por detrás de la mano)
        bl = 9.0                                         # largo de la pala
        pts = [(tx - px * 2.4, ty - py * 2.4), (tx + ux * bl - px * 4.8, ty + uy * bl - py * 4.8),
               (tx + ux * (bl + 3) , ty + uy * (bl + 3)),
               (tx + ux * bl + px * 4.8, ty + uy * bl + py * 4.8), (tx + px * 2.4, ty + py * 2.4)]
        cv.poly(pts, "#c58a4a")
        cv.line([(tx + ux * 2, ty + uy * 2), (tx + ux * (bl + 1), ty + uy * (bl + 1))], "#7a4f22", 1.2, outline=False)
    return draw


def nose(length):
    """JP: nariz larguísima que sale de la cara hacia delante (con la punta roja)."""
    def draw(cv, info):
        hx, hy = info["head"]
        x0, y0 = hx + 5.0, hy + 2.5
        x1, y1 = x0 + length, y0 + 1.5
        cv.line([(x0, y0), (x1, y1)], "#f0b9a0", 5.0)
        cv.disc(x1, y1, 3.4, "#e0505a")
        cv.disc(x1 - 1.0, y1 - 1.0, 1.0, "#ffd6d6")
    return draw


def ground_fx(cv, strength, seed):
    """Agujero, borde de tierra y trozos volando. strength 0..1"""
    rnd = random.Random(seed)
    rx = 14 + 14 * strength
    cv.raw('<ellipse cx="64" cy="%s" rx="%s" ry="5.5" fill="#3a2314"/>' % (GROUND + 2, fmt(rx)))
    return rx


def ground_front(cv, strength, seed, bits=True):
    rnd = random.Random(seed)
    rx = 14 + 14 * strength
    # montículos de tierra al borde del agujero
    for sign in (-1, 1):
        x0 = 64 + sign * rx
        cv.raw('<path d="M %s %s Q %s %s %s %s Z" fill="#8b5a3c" stroke="%s" stroke-width="2.4" '
               'stroke-linejoin="round"/>'
               % (fmt(x0 - 9), GROUND + 4, fmt(x0), fmt(GROUND - 10 - 6 * strength),
                  fmt(x0 + 9), GROUND + 4, OUTLINE))
    if bits and strength > 0.15:
        for i in range(7):
            ang = rnd.uniform(-160, -20)
            dist = 14 + 36 * strength * rnd.uniform(0.5, 1.0)
            px = 64 + math.cos(math.radians(ang)) * dist * 1.1
            py = GROUND - abs(math.sin(math.radians(ang))) * dist * 0.9
            cv.disc(px, py, rnd.uniform(2.0, 3.8), "#8b5a3c" if i % 2 else "#a6714b")


# -------------------------------------------------------------- personajes
CHARACTERS = {
    "gaviotero": dict(color="#2f7ddb", hat="sailor", shirt="#4f9fe8", pants="#2a4a78", hair="#6b4a2b",
                      hair_style="tuft", glasses=None),
    # Topo = "Mole Man": bajo y ancho, antiparras negras, pelo ralo, abrigo raído y garras para cavar
    "topo": dict(color="#a8622a", hat=None, shirt="#6e5b3a", pants="#4b4030", hair="#c9c9bd", hair_style="tuft",
                 glasses="goggles", claws=True, build="stocky", skin="#e6cba6", shoe="#3b2f22"),
}

# Personajes creados con tools/nuevo_personaje.py (color y sombrero de cada uno).
_EXTRA = os.path.join(HERE, "personajes_extra.json")
if os.path.exists(_EXTRA):
    import json
    with open(_EXTRA, encoding="utf-8") as _f:
        CHARACTERS.update(json.load(_f))


def pose_canvas(pose, ch, clip=None, extras=None, size=None):
    cv = Canvas(clip=clip, out_size=size)
    info = draw_stickman(cv, pose, ch)
    if extras:
        extras(cv, info)                  # info = {"head": (x, y), "hand_f": (x, y)}
    return cv


def build_frames(name, ch):
    """Devuelve {animacion: [Canvas, ...]}"""
    anims = {}
    anims["idle"] = [pose_canvas(idle_pose(k), ch) for k in range(2)]
    anims["run"] = [pose_canvas(run_pose(k), ch) for k in range(6)]
    anims["jump"] = [pose_canvas(JUMP, ch)]
    anims["fall"] = [pose_canvas(FALL, ch)]
    anims["hurt"] = [pose_canvas(HURT, ch)]
    anims["attack"] = [pose_canvas(ATTACK[0], ch),
                       pose_canvas(ATTACK[1], ch, extras=swoosh),
                       pose_canvas(ATTACK[2], ch)]
    if name != "topo":
        # El Gaviotero suelta plumas; cualquier personaje nuevo usa la misma pose de "invocar".
        fx = {"gaviotero": feathers, "likan": pebbles, "aukin": noodle_swirl}.get(name)
        poses = POUR if name == "aukin" else SUMMON
        if name == "winkul":
            poses = [SUMMON[0], SUMMON[1], POUR[2]]            # alza las manos y las clava en el suelo
            fxs = [None, None, spike_burst]
        elif name == "nanco":
            poses = SMOKE                                      # fuma y exhala
            fxs = [cigarette, cigarette, smoke_blow]
        elif name == "jorge":
            poses = JORGE_CAST                                 # lanza la caña
            fxs = [rod(-16, -26), rod(30, -8), rod(30, -8)]
        else:
            fxs = [None, fx, fx]
        anims["special"] = [pose_canvas(poses[0], ch, extras=fxs[0]),
                            pose_canvas(poses[1], ch, extras=fxs[1]),
                            pose_canvas(poses[2], ch, extras=fxs[2])]
    if name == "levaro":
        # "special" = remo alzado (aviso); "swing" = remazo; "push" = empujón final
        anims["special"] = [pose_canvas(LEVARO_RAISE[0], ch, extras=oar(-8, -24)),
                            pose_canvas(LEVARO_RAISE[1], ch, extras=oar(-12, -22))]
        anims["swing"] = [pose_canvas(LEVARO_SWING[0], ch, extras=oar(16, 14)),
                          pose_canvas(LEVARO_SWING[1], ch, extras=oar(20, 8))]
        anims["push"] = [pose_canvas(LEVARO_PUSH[0], ch, extras=oar(20, -3)),
                         pose_canvas(LEVARO_PUSH[1], ch, extras=oar(22, -2))]
    if name == "jp":
        # "special" = la nariz empieza a crecer (aviso); "swing" = estocada; "push" = nariz al máximo (empujón)
        anims["special"] = [pose_canvas(LEVARO_RAISE[0], ch, extras=nose(8)),
                            pose_canvas(LEVARO_RAISE[1], ch, extras=nose(14))]
        anims["swing"] = [pose_canvas(LEVARO_SWING[0], ch, extras=nose(22)),
                          pose_canvas(LEVARO_SWING[1], ch, extras=nose(28))]
        anims["push"] = [pose_canvas(LEVARO_PUSH[0], ch, extras=nose(30)),
                         pose_canvas(LEVARO_PUSH[1], ch, extras=nose(34))]
    if name == "jorge":
        # tirón: la caña sube sobre la cabeza y se voltea hacia atrás (lanza al rival al otro lado)
        anims["throw"] = [pose_canvas(JORGE_THROW[0], ch, extras=rod(22, -22)),
                          pose_canvas(JORGE_THROW[1], ch, extras=rod(-30, -8))]
    if name == "topo":
        dive = []
        for i, dy in enumerate([0, 16, 38, 62, 92]):
            cv = Canvas()
            st = i / 4.0
            ground_fx(cv, st, 10 + i)
            cv.clip = CLIP
            draw_stickman(cv, dict(DIVER, dy=dy), ch)
            cv.clip = None
            ground_front(cv, st, 10 + i)
            dive.append(cv)
        anims["dive"] = dive
        emerge = []
        specs = [(DIVER, 84, 1.0), (DIVER, 46, 0.8), (UPPERCUT, 14, 0.7), (UPPERCUT, 0, 0.45), (idle_pose(0), 0, 0.2)]
        for i, (pose, dy, st) in enumerate(specs):
            cv = Canvas()
            ground_fx(cv, st, 40 + i)
            cv.clip = CLIP
            draw_stickman(cv, dict(pose, dy=dy), ch)
            cv.clip = None
            ground_front(cv, st, 40 + i)
            emerge.append(cv)
        anims["emerge"] = emerge
    return anims


FPS = {"idle": 3, "run": 12, "jump": 1, "fall": 1, "hurt": 1, "attack": 12,
       "special": 8, "swing": 12, "push": 12, "throw": 12, "dive": 12, "emerge": 14}
LOOP = {"idle": True, "run": True}


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(text)


def write_frames_tres(path, anim_files):
    """anim_files: {anim: [res://...svg, ...]} -> SpriteFrames .tres"""
    ids, ext = {}, []
    for files in anim_files.values():
        for f in files:
            if f not in ids:
                ids[f] = len(ids) + 1
                ext.append('[ext_resource path="%s" type="Texture" id=%d]' % (f, ids[f]))
    blocks = []
    for anim, files in anim_files.items():
        frames = ", ".join("ExtResource( %d )" % ids[f] for f in files)
        blocks.append('{\n"frames": [ %s ],\n"loop": %s,\n"name": "%s",\n"speed": %s\n}'
                      % (frames, "true" if LOOP.get(anim, False) else "false", anim,
                         fmt(float(FPS.get(anim, 10)))))
    text = '[gd_resource type="SpriteFrames" load_steps=%d format=2]\n\n%s\n\n[resource]\nanimations = [ %s ]\n' % (
        len(ids) + 1, "\n".join(ext), ", ".join(blocks))
    write(path, text)


# ------------------------------------------------------------------ gaviota
def gull_svg(phase):
    tips = {0: (34, 2), 1: (12, 24), 2: (28, 60)}
    tx, ty = tips[phase]
    O, sw = OUTLINE, 2.4
    p = []

    def wing(dx, dy, fill):
        x, y = tx + dx, ty + dy
        return ('<path d="M %s 34 Q %s %s %s %s Q %s %s %s 37 Z" fill="%s" stroke="%s" '
                'stroke-width="%s" stroke-linejoin="round"/>'
                % (fmt(60 + dx * 0.4), fmt(x + 34), fmt((y + 34) / 2 - 6), fmt(x), fmt(y),
                   fmt(x + 6), fmt((y + 37) / 2 + 10), fmt(40 + dx * 0.4), fill, O, sw))

    p.append(wing(10, 4, "#cfd8e3"))                                   # ala lejana
    p.append('<polygon points="30,34 6,29 8,43 30,41" fill="#ffffff" stroke="%s" stroke-width="%s" '
             'stroke-linejoin="round"/>' % (O, sw))                    # cola
    p.append('<ellipse cx="50" cy="37" rx="24" ry="11" fill="#ffffff" stroke="%s" stroke-width="%s"/>' % (O, sw))
    p.append('<circle cx="74" cy="29" r="8.6" fill="#ffffff" stroke="%s" stroke-width="%s"/>' % (O, sw))
    p.append('<polygon points="80,27 94,31 80,35" fill="#f5a623" stroke="%s" stroke-width="2" '
             'stroke-linejoin="round"/>' % O)
    p.append('<circle cx="77" cy="27" r="1.9" fill="%s"/>' % O)
    p.append(wing(0, 0, "#f4f7fb"))                                    # ala cercana
    p.append('<circle cx="%s" cy="%s" r="3.2" fill="#3a3f55"/>' % (fmt(tx), fmt(ty)))
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="96" height="64" viewBox="0 0 96 64">\n%s\n</svg>\n'
            % "\n".join(p))


# --------------------------------------------------------------- escenario
def bg_svg():
    clouds = []
    for (x, y, s) in [(180, 120, 1.0), (520, 70, 0.8), (860, 170, 1.2), (1120, 90, 0.7)]:
        for dx, dy, rx, ry in [(0, 0, 70, 26), (-40, 8, 46, 20), (44, 10, 52, 22), (6, -16, 40, 22)]:
            clouds.append('<ellipse cx="%s" cy="%s" rx="%s" ry="%s" fill="#ffffff" fill-opacity="0.92"/>'
                          % (fmt(x + dx * s), fmt(y + dy * s), fmt(rx * s), fmt(ry * s)))
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720" viewBox="0 0 1280 720">\n'
            '<defs><linearGradient id="sky" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="720">'
            '<stop offset="0" stop-color="#4fa9ee"/><stop offset="0.65" stop-color="#bfe6fb"/>'
            '<stop offset="1" stop-color="#eef9ff"/></linearGradient></defs>\n'
            '<rect width="1280" height="720" fill="url(#sky)"/>\n'
            '<circle cx="1040" cy="150" r="96" fill="#fff6c2" fill-opacity="0.35"/>\n'
            '<circle cx="1040" cy="150" r="60" fill="#fff3b0"/>\n%s\n'
            '<polygon points="0,560 140,380 260,500 420,330 600,520 760,360 940,520 1100,400 1280,540 1280,720 0,720" '
            'fill="#a9c8e4"/>\n'
            '<polygon points="0,640 180,500 330,600 520,470 700,610 900,490 1100,610 1280,520 1280,720 0,720" '
            'fill="#86bb98"/>\n</svg>\n' % "\n".join(clouds))


def platform_main_svg():
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="720" height="236" viewBox="0 0 720 236">\n'
            '<path d="M 4 26 L 716 26 L 698 150 Q 640 196 520 188 L 360 232 L 224 194 Q 90 190 22 150 Z" '
            'fill="#8b5a3c" stroke="%s" stroke-width="4" stroke-linejoin="round"/>\n'
            '<path d="M 60 70 Q 120 90 180 66 M 300 96 Q 380 120 460 92 M 540 60 Q 600 80 650 62 '
            'M 200 140 Q 260 160 330 142" fill="none" stroke="#6f4630" stroke-width="5" stroke-linecap="round"/>\n'
            '<ellipse cx="120" cy="112" rx="14" ry="9" fill="#a6714b"/>\n'
            '<ellipse cx="560" cy="124" rx="18" ry="10" fill="#a6714b"/>\n'
            '<rect x="2" y="2" width="716" height="36" rx="14" fill="#6cc04a" stroke="%s" stroke-width="4"/>\n'
            '<rect x="12" y="8" width="696" height="7" rx="3.5" fill="#92dc6e"/>\n</svg>\n' % (OUTLINE, OUTLINE))


def platform_small_svg():
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="44" viewBox="0 0 200 44">\n'
            '<path d="M 6 14 L 194 14 L 182 36 Q 100 46 18 36 Z" fill="#c98f55" stroke="%s" stroke-width="3.5" '
            'stroke-linejoin="round"/>\n'
            '<rect x="2" y="2" width="196" height="16" rx="8" fill="#6cc04a" stroke="%s" stroke-width="3.5"/>\n'
            '<rect x="10" y="6" width="180" height="4" rx="2" fill="#92dc6e"/>\n</svg>\n' % (OUTLINE, OUTLINE))


def fx_svgs():
    return {
        "dirt": '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">'
                '<circle cx="7" cy="7" r="6" fill="#8b5a3c" stroke="#4b2e1c" stroke-width="1.5"/></svg>\n',
        "feather": '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="10" viewBox="0 0 20 10">'
                   '<polygon points="1,5 10,1 19,5 10,9" fill="#ffffff" stroke="#9aa6b8" stroke-width="1" '
                   'stroke-linejoin="round"/></svg>\n',
        "star": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">'
                '<polygon points="12,0 15,9 24,12 15,15 12,24 9,15 0,12 9,9" fill="#ffe45e" stroke="#ffffff" '
                'stroke-width="1.5" stroke-linejoin="round"/></svg>\n',
        "rock": '<svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 44 44">'
                '<polygon points="6,30 4,16 14,5 28,3 40,12 41,28 31,40 14,40" fill="#8c909c" stroke="%s" '
                'stroke-width="3" stroke-linejoin="round"/>'
                '<polygon points="12,14 18,9 27,8 22,16 14,20" fill="#b9bdc9"/>'
                '<polyline points="26,22 31,28 28,35" fill="none" stroke="#5f636f" stroke-width="2.5" '
                'stroke-linecap="round" stroke-linejoin="round"/></svg>\n' % OUTLINE,
        "rock_chip": '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">'
                     '<polygon points="2,9 3,3 9,1 13,6 10,12" fill="#8c909c" stroke="%s" stroke-width="1.6" '
                     'stroke-linejoin="round"/></svg>\n' % OUTLINE,
        "shadow": '<svg xmlns="http://www.w3.org/2000/svg" width="72" height="18" viewBox="0 0 72 18">'
                  '<ellipse cx="36" cy="9" rx="33" ry="7" fill="#1b1b2f" fill-opacity="0.55"/>'
                  '<ellipse cx="36" cy="9" rx="33" ry="7" fill="none" stroke="#ff5a4d" stroke-width="2.5" '
                  'stroke-opacity="0.9"/></svg>\n',
        "smoke": '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48">'
                 '<circle cx="24" cy="24" r="22" fill="#cfd5df" fill-opacity="0.35"/>'
                 '<circle cx="24" cy="24" r="15" fill="#e4e8ef" fill-opacity="0.55"/>'
                 '<circle cx="22" cy="22" r="8" fill="#f4f6fa" fill-opacity="0.7"/></svg>\n',
        "mound": '<svg xmlns="http://www.w3.org/2000/svg" width="72" height="36" viewBox="0 0 72 36">'
                 '<path d="M 3 33 Q 12 5 36 5 Q 60 5 69 33 Z" fill="#8b5a3c" stroke="%s" stroke-width="3" '
                 'stroke-linejoin="round"/><path d="M 20 26 Q 30 14 44 16" fill="none" stroke="#a6714b" '
                 'stroke-width="4" stroke-linecap="round"/></svg>\n' % OUTLINE,
    }


def icon_svg(ch_color="#2f7ddb"):
    cv = Canvas(out_size=(128, 128))
    cv.raw('<rect x="4" y="4" width="120" height="120" rx="24" fill="#bfe6fb" stroke="%s" stroke-width="5"/>' % OUTLINE)
    draw_stickman(cv, dict(hip=(52, 84), lean=6, fF=(64, 112), fB=(40, 112), hF=(74, 62), hB=(66, 70)),
                  CHARACTERS["gaviotero"])
    cv.raw('<polygon points="96,40 112,52 100,56 114,64 92,60" fill="#ffe45e" stroke="%s" stroke-width="2.5" '
           'stroke-linejoin="round"/>' % OUTLINE)
    return cv.svg()


def main():
    for name, ch in CHARACTERS.items():
        anims = build_frames(name, ch)
        files = {}
        for anim, cvs in anims.items():
            files[anim] = []
            for i, cv in enumerate(cvs):
                rel = "assets/sprites/%s/%s_%d.svg" % (name, anim, i)
                write(os.path.join(PROJ, rel), cv.svg())
                files[anim].append("res://" + rel)
        write_frames_tres(os.path.join(RES, "%s_frames.tres" % name), files)
        # retrato grande (256x256) para el menú de selección
        portrait = Canvas(out_size=(256, 256), view=(14, 10, 100, 100))
        draw_stickman(portrait, idle_pose(0), ch)
        write(os.path.join(SPR, name, "portrait.svg"), portrait.svg())

    gull_files = []
    for ph in range(3):
        rel = "assets/sprites/gull/gull_%d.svg" % ph
        write(os.path.join(PROJ, rel), gull_svg(ph))
        gull_files.append("res://" + rel)
    # ciclo de aleteo: arriba, medio, abajo, medio
    seq = [gull_files[0], gull_files[1], gull_files[2], gull_files[1]]
    FPS["fly"] = 10
    LOOP["fly"] = True
    write_frames_tres(os.path.join(RES, "gull_frames.tres"), {"fly": seq})

    write(os.path.join(SPR, "stage", "bg.svg"), bg_svg())
    write(os.path.join(SPR, "stage", "platform_main.svg"), platform_main_svg())
    write(os.path.join(SPR, "stage", "platform_small.svg"), platform_small_svg())
    for n, s in fx_svgs().items():
        write(os.path.join(SPR, "fx", n + ".svg"), s)
    write(os.path.join(PROJ, "icon.svg"), icon_svg())
    print("Sprites generados en", SPR)


if __name__ == "__main__":
    main()
