# Smash Stick (prueba) — Godot 3.5.3

Prototipo de juego de lucha 2D tipo *Smash Bros* con personajes stickman, habilidades
especiales, selección de personajes, dos jugadores en el mismo teclado y modo práctica.

## Empezar en 30 segundos

1. Abre **Godot 3.5.3** → *Importar* → selecciona `project.godot`.
2. Pulsa **F5**.
3. Jugador 1: **A D W S F G**. Jugador 2: **← → ↑ ↓ K L**.

## Documentación completa

Toda la explicación está en la carpeta **[docs/](docs/00_LEEME_PRIMERO.md)**, en español:

- Cómo está organizado el proyecto.
- Cómo funciona el código.
- Cómo cambiar las estadísticas de un personaje.
- Cómo crear un personaje nuevo (con un comando).
- Cómo funcionan las habilidades especiales.
- Cómo regenerar sprites, sonidos y música.
- Cómo ejecutar las pruebas.
- Qué falta (multijugador por WiFi).

## Resumen rápido de carpetas

```
characters/   fichas de personaje (.tres) — aquí cambias números de cada personaje
scenes/       escenas (.tscn)
scripts/      código, por tema: core, fighters, effects, stage, ui
assets/       sprites SVG, sonidos y música
tools/        generadores y pruebas
docs/         documentación
```

## Crear un personaje nuevo

```bash
python3 tools/nuevo_personaje.py rayo "Rayo" --color "#e0b000" --especial "Puño relámpago"
```

Detalle en [docs/06_CREAR_UN_PERSONAJE_NUEVO.md](docs/06_CREAR_UN_PERSONAJE_NUEVO.md).

## Pruebas

```bash
godot --path . -s tools/test_headless.gd
godot --path . -s tools/test_dodge_bugs.gd
godot --path . -s tools/test_personajes.gd
```

Cada una termina con `RESULTADO: 0 fallos` si todo está bien.
