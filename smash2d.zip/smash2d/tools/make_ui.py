#!/usr/bin/env python3
"""Genera las texturas de los botones y el tema de la interfaz:
   - assets/ui/btn_normal|hover|pressed|disabled|focus.png   (9-patch, 96x64)
   - resources/ui_theme.tres                                  (Theme global del proyecto)

El tema se aplica a TODOS los Button/ProgressBar del juego (project.godot > gui/theme/custom),
asi que cambiar el aspecto de los botones es editar estos PNG o los colores de abajo y correr:
    python3 tools/make_ui.py        (requiere Pillow)
"""
import math
import os

from PIL import Image, ImageChops, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, ".."))
OUT = os.path.join(PROJ, "assets", "ui")
THEME = os.path.join(PROJ, "resources", "ui_theme.tres")

W, H, SS, R = 96, 64, 4, 18       # tamano final, supermuestreo y radio de esquina
MARGIN = 24                        # margen del 9-patch (px): lo que NO se estira

# (color arriba, color abajo, borde, brillo superior)
LOOKS = {
    "normal":   ((86, 112, 214), (44, 58, 142), (22, 26, 66),  (170, 190, 255)),
    "hover":    ((112, 140, 240), (62, 80, 176), (255, 214, 90), (210, 224, 255)),
    "pressed":  ((38, 50, 120), (28, 36, 92),   (255, 190, 60), (90, 110, 190)),
    "disabled": ((96, 102, 124), (70, 74, 94),  (44, 46, 60),  (140, 146, 166)),
}


def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def rr_mask(w, h, r, inset=0):
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle([inset, inset, w - 1 - inset, h - 1 - inset], radius=r, fill=255)
    return m


def body(look, pressed=False):
    top, bot, border, shine = LOOKS[look]
    w, h, r = W * SS, H * SS, R * SS
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    grad = Image.new("RGBA", (w, h))
    gd = ImageDraw.Draw(grad)
    for y in range(h):
        gd.line([(0, y), (w, y)], fill=lerp(top, bot, y / (h - 1)) + (255,))
    # textura: rayas diagonales muy suaves + puntitos
    tex = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    td = ImageDraw.Draw(tex)
    step = 14 * SS
    for x in range(-h, w + h, step):
        td.line([(x, h), (x + h, 0)], fill=(255, 255, 255, 16), width=5 * SS)
    grad.alpha_composite(tex)
    # brillo superior (media luna suave)
    gl = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gld = ImageDraw.Draw(gl)
    if not pressed:
        gld.rounded_rectangle([5 * SS, 4 * SS, w - 5 * SS, h * 0.46], radius=r - 4 * SS, fill=shine + (58,))
    grad.alpha_composite(gl)
    # sombra interior abajo
    sh = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    sd = ImageDraw.Draw(sh)
    for i in range(10 * SS):
        sd.line([(0, h - 1 - i), (w, h - 1 - i)], fill=(0, 0, 20, int(70 * (1 - i / (10 * SS)))))
    grad.alpha_composite(sh)
    img.paste(grad, (0, 0), rr_mask(w, h, r))
    ring = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(ring).rounded_rectangle([0, 0, w - 1, h - 1], radius=r, outline=border + (255,), width=4 * SS)
    # filo claro interior fino
    ImageDraw.Draw(ring).rounded_rectangle([4 * SS, 4 * SS, w - 1 - 4 * SS, h - 1 - 4 * SS], radius=r - 4 * SS,
                                           outline=shine + (70 if not pressed else 25,), width=SS)
    img.alpha_composite(ring)
    return img.resize((W, H), Image.LANCZOS)


def focus_ring():
    w, h, r = W * SS, H * SS, R * SS
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i, a in enumerate((60, 110, 255)):
        d.rounded_rectangle([i * SS, i * SS, w - 1 - i * SS, h - 1 - i * SS], radius=r - i * SS,
                            outline=(255, 214, 90, a), width=SS if i < 2 else 3 * SS)
    return img.resize((W, H), Image.LANCZOS)


def box(name, tex_id, pad_v=(10, 12), draw_center=True):
    return ('[sub_resource type="StyleBoxTexture" id=%d]\n'
            'texture = ExtResource( %d )\n'
            'margin_left = %d.0\nmargin_right = %d.0\nmargin_top = %d.0\nmargin_bottom = %d.0\n'
            'content_margin_left = 22.0\ncontent_margin_right = 22.0\n'
            'content_margin_top = %d.0\ncontent_margin_bottom = %d.0\n'
            'draw_center = %s\n' % (tex_id + 10, tex_id, MARGIN, MARGIN, MARGIN, MARGIN, pad_v[0], pad_v[1],
                                    "true" if draw_center else "false"))


def write_theme():
    names = ["normal", "hover", "pressed", "disabled", "focus"]
    L = ['[gd_resource type="Theme" load_steps=15 format=2]', '']
    for i, n in enumerate(names, 1):
        L.append('[ext_resource path="res://assets/ui/btn_%s.png" type="Texture" id=%d]' % (n, i))
    L.append('[ext_resource path="res://resources/font_med.tres" type="DynamicFont" id=6]')
    L.append('')
    for i, n in enumerate(names, 1):
        pad = (8, 14) if n == "pressed" else (12, 10)         # al pulsar el texto "baja" 2 px
        L.append(box(n, i, pad, draw_center=(n != "focus")))
    L.append('[sub_resource type="StyleBoxFlat" id=20]\nbg_color = Color( 0.08, 0.09, 0.15, 0.85 )\n'
             'corner_radius_top_left = 9\ncorner_radius_top_right = 9\ncorner_radius_bottom_right = 9\ncorner_radius_bottom_left = 9\n'
             'border_width_left = 2\nborder_width_top = 2\nborder_width_right = 2\nborder_width_bottom = 2\n'
             'border_color = Color( 0.3, 0.33, 0.5, 1 )\nanti_aliasing = true\n')
    L.append('[sub_resource type="StyleBoxFlat" id=21]\nbg_color = Color( 1, 0.78, 0.25, 1 )\n'
             'corner_radius_top_left = 9\ncorner_radius_top_right = 9\ncorner_radius_bottom_right = 9\ncorner_radius_bottom_left = 9\n'
             'anti_aliasing = true\n')
    L.append('[resource]')
    for n in ["normal", "hover", "pressed", "disabled", "focus"]:
        L.append('Button/styles/%s = SubResource( %d )' % (n, 11 + names.index(n)))
    L.append('Button/colors/font_color = Color( 1, 1, 1, 1 )')
    L.append('Button/colors/font_color_hover = Color( 1, 0.95, 0.75, 1 )')
    L.append('Button/colors/font_color_focus = Color( 1, 0.95, 0.75, 1 )')
    L.append('Button/colors/font_color_pressed = Color( 1, 0.85, 0.4, 1 )')
    L.append('Button/colors/font_color_disabled = Color( 0.78, 0.8, 0.88, 0.7 )')
    L.append('Button/colors/font_color_shadow = Color( 0.05, 0.06, 0.2, 0.9 )')
    L.append('Button/constants/shadow_offset_x = 2')
    L.append('Button/constants/shadow_offset_y = 2')
    L.append('Button/fonts/font = ExtResource( 6 )')
    L.append('ProgressBar/styles/bg = SubResource( 20 )')
    L.append('ProgressBar/styles/fg = SubResource( 21 )')
    with open(THEME, "w") as f:
        f.write("\n".join(L) + "\n")


def main():
    os.makedirs(OUT, exist_ok=True)
    for n in ("normal", "hover", "disabled"):
        body(n).save(os.path.join(OUT, "btn_%s.png" % n))
    body("pressed", pressed=True).save(os.path.join(OUT, "btn_pressed.png"))
    focus_ring().save(os.path.join(OUT, "btn_focus.png"))
    write_theme()
    print("UI generada en", OUT, "y", THEME)


if __name__ == "__main__":
    main()
