extends SceneTree
var fails := 0
func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)
func wait(sec): yield(create_timer(sec), "timeout")
func reset(f, pos):
	f.position = pos; f.velocity = Vector2.ZERO; f.percent = 0.0
	f.state = f.State.NORMAL; f.invulnerable = false; f.invuln_timer = 0.0
	f.special_timer = 0.0; f.frozen = false; f.collision_layer = 2; f.sprite.visible = true

func gull_count(arena):
	var n = 0
	for c in arena.get_node("Fighters").get_children():
		if c.get_script() != null and c.get_script().resource_path.ends_with("Gull.gd"):
			n += 1
	return n

func _initialize(): _run()
func _run():
	var game = root.get_node("Game")
	game.selected = ["gaviotero", "topo"]; game.practice = false
	var arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(3.6), "completed")
	var f1 = arena.fighters[0]
	var f2 = arena.fighters[1]
	check("stats aplicados (no null)", f1.stats != null and f2.stats != null)
	check("nombre desde .tres", f1.display_name == "Gaviotero" and f2.display_name == "Topo")

	print("== Esquivar gaviota saltando")
	reset(f1, Vector2(400, 440)); reset(f2, Vector2(780, 440))
	f1.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.06), "completed"); Input.action_release("p1_special")
	# saltar cuando sale la gaviota y mantenerse arriba con doble salto mientras cruza
	var gguard = 0
	while gull_count(arena) == 0 and gguard < 100:
		yield(wait(0.02), "completed")
		gguard += 1
	Input.action_press("p2_jump"); yield(wait(0.05), "completed"); Input.action_release("p2_jump")
	yield(wait(0.25), "completed")
	Input.action_press("p2_jump"); yield(wait(0.05), "completed"); Input.action_release("p2_jump")
	yield(wait(0.6), "completed")
	check("P2 esquiva la gaviota saltando", f2.percent == 0.0, "percent=%s" % f2.percent)
	yield(wait(1.5), "completed")

	print("== special_windup del Gaviotero se respeta (retrasa la salida de la gaviota)")
	var gv = game.CHARACTERS["gaviotero"]
	var old_windup = gv.special_windup
	gv.special_windup = 1.0
	reset(f1, Vector2(400, 440)); reset(f2, Vector2(780, 440))
	f1.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.06), "completed"); Input.action_release("p1_special")
	yield(wait(0.75), "completed")
	check("con windup 1.0 no hay gaviota a los ~0.8 s", gull_count(arena) == 0 and f2.percent == 0.0)
	yield(wait(0.5), "completed")
	check("con windup 1.0 la gaviota ya salió a los ~1.3 s", gull_count(arena) == 1)
	gv.special_windup = 0.1
	yield(wait(2.5), "completed")
	reset(f1, Vector2(400, 440)); reset(f2, Vector2(780, 440))
	f1.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.06), "completed"); Input.action_release("p1_special")
	yield(wait(0.3), "completed")
	check("con windup 0.1 la gaviota sale enseguida", gull_count(arena) == 1)
	gv.special_windup = old_windup
	yield(wait(2.5), "completed")

	print("== Gaviota SI golpea si no se esquiva")
	reset(f1, Vector2(400, 440)); reset(f2, Vector2(780, 440))
	f1.facing = 1
	yield(wait(0.3), "completed")
	Input.action_press("p1_special"); yield(wait(0.06), "completed"); Input.action_release("p1_special")
	yield(wait(1.0), "completed")
	check("P2 recibe dano si se queda quieto", f2.percent > 0.0, "percent=%s" % f2.percent)
	yield(wait(1.5), "completed")

	print("== Topo: no se puede usar en plataforma aerea")
	reset(f1, Vector2(450, 440))
	reset(f2, Vector2(400, 310))   # pies sobre PlatformLeft (superficie en y=350), no el suelo principal
	yield(wait(0.3), "completed")
	check("P2 esta sobre una plataforma (on_floor fisico)", f2.is_on_floor())
	check("_on_main_floor() es falso en plataforma aerea", not f2._on_main_floor())
	f2.special_timer = 0.0
	Input.action_press("p2_special"); yield(wait(0.08), "completed"); Input.action_release("p2_special")
	yield(wait(0.05), "completed")
	check("el especial NO se activa desde la plataforma", f2.state != f2.State.SPECIAL, "state=%s" % f2.state)
	yield(wait(0.3), "completed")

	print("== Topo: emerge siempre en el suelo principal, nunca en el aire")
	reset(f1, Vector2(400, 310))   # rival objetivo sobre la plataforma aerea
	reset(f2, Vector2(640, 440))   # topo en el suelo principal
	yield(wait(0.3), "completed")
	f2.special_timer = 0.0
	Input.action_press("p2_special"); yield(wait(0.08), "completed"); Input.action_release("p2_special")
	var guard = 0
	while f2.phase != f2.Phase.EMERGE and guard < 150:
		yield(wait(0.02), "completed"); guard += 1
	check("topo emergio", f2.phase == f2.Phase.EMERGE, "guard=%s" % guard)
	check("topo emerge SOBRE EL SUELO, no en el aire junto a la plataforma",
		abs(f2.position.y - 440.0) < 10.0, "y=%s (esperado ~440)" % f2.position.y)
	check("topo esta en el suelo fisico al emerger", f2.is_on_floor())
	yield(wait(1.0), "completed")

	print("== Esquivar el golpe del topo (hay aviso antes del golpe)")
	reset(f1, Vector2(480, 440)); reset(f2, Vector2(800, 440))
	f2.facing = -1
	yield(wait(0.3), "completed")
	f2.special_timer = 0.0
	Input.action_press("p2_special"); yield(wait(0.08), "completed"); Input.action_release("p2_special")
	var g2 = 0
	while f2.phase != f2.Phase.EMERGE and g2 < 150:
		yield(wait(0.02), "completed"); g2 += 1
	# en cuanto emerge, P1 salta para esquivar el golpe retardado (dig_emerge_delay)
	Input.action_press("p1_jump"); yield(wait(0.05), "completed"); Input.action_release("p1_jump")
	yield(wait(0.5), "completed")
	check("P1 puede esquivar el golpe del topo saltando a tiempo", f1.percent == 0.0, "percent=%s" % f1.percent)
	yield(wait(1.5), "completed")

	print(""); print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
