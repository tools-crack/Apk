#!/bin/bash
# Prueba de red: arranca un anfitrión y un cliente (dos procesos de Godot) en esta misma máquina.
#   bash tools/probar_red.sh [ruta/a/godot]
GODOT=${1:-godot}
cd "$(dirname "$0")/.."
$GODOT --path . --no-window -s tools/test_red_host.gd > ${TMPDIR:-/tmp}/red_host.log 2>&1 &
H=$!
sleep 1.5
$GODOT --path . --no-window -s tools/test_red_cliente.gd > ${TMPDIR:-/tmp}/red_cliente.log 2>&1 &
C=$!
wait $H $C
echo "---- anfitrión"; cat ${TMPDIR:-/tmp}/red_host.log
echo "---- cliente";   cat ${TMPDIR:-/tmp}/red_cliente.log
