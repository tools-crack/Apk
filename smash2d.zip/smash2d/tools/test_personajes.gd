extends SceneTree
# ============================================================================
#  test_personajes.gd — "contrato" que debe cumplir CADA personaje
# ----------------------------------------------------------------------------
#  Úsalo después de crear un personaje nuevo:
#      godot --path . -s tools/test_personajes.gd
#  Para cada personaje de la carpeta characters/ comprueba que:
#    - su ficha tiene escena, retrato, nombre y estadísticas válidas
#    - su SpriteFrames tiene las animaciones obligatorias
#    - en la arena puede usar su especial y este TERMINA (vuelve a NORMAL)
#  No hace falta editarlo: detecta los personajes solo.
# ============================================================================

const REQUIRED_ANIMS := ["idle", "run", "jump", "fall", "hurt", "attack"]

var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func _initialize():
	_run()


func _run():
	var game = root.get_node("Game")
	check("hay al menos 2 personajes", game.ORDER.size() >= 2, str(game.ORDER))
	for id in game.ORDER:
		var d = game.CHARACTERS[id]
		print("== Personaje: ", id)
		check(id + ": ficha con escena y retrato", d.scene != null and d.portrait != null)
		check(id + ": nombre y especial con texto", d.display_name != "" and d.special_name != "")
		check(id + ": estadisticas validas", d.move_speed > 0.0 and d.jump_speed > 0.0 and d.gravity > 0.0 \
			and d.max_stocks >= 1 and d.attack_total > d.attack_startup and d.special_cooldown > 0.0)

		# animaciones obligatorias
		var probe = d.scene.instance()
		var frames = probe.get_node("Sprite").frames
		var missing = []
		for a in REQUIRED_ANIMS:
			if not frames.has_animation(a):
				missing.append(a)
		check(id + ": animaciones obligatorias", missing.empty(), "faltan: %s" % str(missing))
		check(id + ": tiene animacion para su especial", frames.has_animation("special") or frames.has_animation("dive"))
		probe.free()

		# el especial se activa y termina, jugando como P1 Y como P2 (cada jugador tiene sus teclas)
		var other = game.ORDER[(game.ORDER.find(id) + 1) % game.ORDER.size()]
		for slot in [0, 1]:
			var tag = "%s (como P%d)" % [id, slot + 1]
			game.selected = [id, other] if slot == 0 else [other, id]
			game.practice = false
			var arena = load("res://scenes/Arena.tscn").instance()
			root.add_child(arena)
			yield(wait(3.6), "completed")
			var f = arena.fighters[slot]
			check(tag + ": aparece en el suelo", f.is_on_floor())
			check(tag + ": es el personaje elegido", f.display_name == d.display_name and f.stats == d)
			var action = "p%d_special" % (slot + 1)
			Input.action_press(action)
			yield(wait(0.06), "completed")
			Input.action_release(action)
			yield(wait(0.1), "completed")
			check(tag + ": el especial se activa (recarga iniciada)", f.special_timer > 0.0, "special_timer=%s" % f.special_timer)
			var t = 0.0
			while f.state == f.State.SPECIAL and t < 4.0:
				yield(wait(0.05), "completed")
				t += 0.05
			check(tag + ": el especial TERMINA y vuelve a NORMAL", f.state == f.State.NORMAL, "dura %.2fs, state=%s" % [t, f.state])
			check(tag + ": no queda invulnerable ni congelado", not f.invulnerable and not f.frozen)
			arena.queue_free()
			yield(wait(0.2), "completed")

	print("")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
