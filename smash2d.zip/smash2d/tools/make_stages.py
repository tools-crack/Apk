#!/usr/bin/env python3
"""Genera el ARTE de los escenarios nuevos (fondos SVG de 1280x720 y capas animadas):
   - assets/sprites/stage/bg_desierto.svg   + nubes_desierto.svg (capa que se desplaza)
   - assets/sprites/stage/bg_azotea.svg     + estrellas_azotea.svg (capa que titila)
(El fondo de la pradera lo genera tools/make_sprites.py; los tiles, tools/make_tileset.py.)

Solo dibuja imagenes: la forma del escenario (suelo y plataformas) esta en scenes/stages/*.tscn.
Uso: python3 tools/make_stages.py
"""
import math
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.normpath(os.path.join(HERE, "..", "assets", "sprites", "stage"))
W, H = 1280, 720


def svg(body, w=W, h=H, defs=""):
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d">\n<defs>%s</defs>\n%s\n</svg>\n'
            % (w, h, w, h, defs, body))


def lin(id_, stops, x2=0, y2=1):
    s = "".join('<stop offset="%s" stop-color="%s"%s/>' % (o, c, (' stop-opacity="%s"' % a) if a is not None else "")
                for o, c, a in stops)
    return '<linearGradient id="%s" x1="0" y1="0" x2="%d" y2="%d">%s</linearGradient>' % (id_, x2, y2, s)


def rad(id_, stops):
    s = "".join('<stop offset="%s" stop-color="%s" stop-opacity="%s"/>' % st for st in stops)
    return '<radialGradient id="%s">%s</radialGradient>' % (id_, s)


def dune(y0, amp, seed, fill, bottom=H, step=40, extra=""):
    rnd = random.Random(seed)
    ph = [rnd.uniform(0, 6.28) for _ in range(3)]
    pts = []
    for x in range(-step, W + step * 2, step):
        y = y0 + amp * (0.6 * math.sin(x / 210 + ph[0]) + 0.3 * math.sin(x / 90 + ph[1]) + 0.15 * math.sin(x / 47 + ph[2]))
        pts.append((x, y))
    d = "M %d %d " % (pts[0][0], bottom) + " ".join("L %.1f %.1f" % p for p in pts) + " L %d %d Z" % (pts[-1][0], bottom)
    return '<path d="%s" fill="%s" %s/>' % (d, fill, extra)


# ------------------------------------------------------------------ desierto
def cactus(x, base, h, col, shade):
    w = h * 0.16
    parts = ['<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="%.1f" fill="%s"/>' % (x - w / 2, base - h, w, h, w / 2, col)]
    parts.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="%.1f" fill="%s"/>' % (x + w * 0.1, base - h, w * 0.4, h, w / 4, shade))
    for sgn, hh, yy in ((-1, 0.38, 0.45), (1, 0.30, 0.6)):
        ax = x + sgn * w * 1.5
        parts.append('<path d="M %.1f %.1f L %.1f %.1f" stroke="%s" stroke-width="%.1f" stroke-linecap="round" fill="none"/>'
                     % (x, base - h * yy, ax, base - h * yy, col, w * 0.7))
        parts.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="%.1f" fill="%s"/>'
                     % (ax - w * 0.35, base - h * yy - h * hh, w * 0.7, h * hh, w * 0.35, col))
    return "".join(parts)


def desert_bg():
    defs = lin("sky", [(0, "#22205e", None), (0.3, "#6a2f86", None), (0.55, "#d6476a", None), (0.8, "#ff9450", None),
                       (1, "#ffd27d", None)])
    defs += rad("glow", [(0, "#fff0b0", 0.95), (0.35, "#ffb55a", 0.55), (1, "#ff7a4a", 0)])
    defs += lin("sun", [(0, "#fff6c4", None), (1, "#ffb347", None)])
    b = ['<rect width="%d" height="%d" fill="url(#sky)"/>' % (W, H)]
    rnd = random.Random(7)
    for _ in range(70):                                         # estrellas arriba
        x, y = rnd.uniform(0, W), rnd.uniform(0, 250)
        b.append('<circle cx="%.0f" cy="%.0f" r="%.1f" fill="#ffffff" fill-opacity="%.2f"/>' % (x, y, rnd.uniform(0.6, 1.6), rnd.uniform(0.25, 0.8) * (1 - y / 300)))
    b.append('<circle cx="900" cy="430" r="330" fill="url(#glow)"/>')
    b.append('<circle cx="900" cy="430" r="118" fill="url(#sun)"/>')
    for i in range(5):                                          # franjas de sol retro
        y = 430 + i * 17
        b.append('<rect x="780" y="%d" width="240" height="%.1f" fill="#f26b4b" fill-opacity="0.85"/>' % (y, 3 + i * 1.6))
    b.append(dune(470, 26, 1, "#7e3a86"))                       # dunas lejanas
    for (cx, w, h) in ((250, 170, 118), (400, 110, 76), (1040, 130, 90)):      # piramides
        base = 492
        b.append('<polygon points="%d,%d %d,%d %d,%d" fill="#8a3a74"/>' % (cx - w, base, cx, base - h, cx + w, base))
        b.append('<polygon points="%d,%d %d,%d %d,%d" fill="#a24a7e"/>' % (cx, base - h, cx + w, base, cx, base))
    b.append(dune(520, 22, 2, "#b84b6e"))
    b.append(dune(575, 28, 3, "#d9683f"))
    b.append(dune(640, 30, 4, "#b8522f"))
    b.append(dune(690, 18, 5, "#8f3d2c"))
    for (x, h) in ((86, 210), (180, 120), (1130, 190), (1215, 110)):
        b.append(cactus(x, 700, h, "#3d2a3c", "#4d3548"))
    return svg("\n".join(b), defs=defs)


def clouds_strip():
    """Tira de 1280x240 que se repite al desplazarse (los extremos coinciden)."""
    rnd = random.Random(11)
    b = []
    for (x, y, w, h) in ((80, 60, 420, 30), (480, 120, 360, 24), (880, 40, 300, 22), (1040, 150, 420, 28), (-120, 150, 380, 26)):
        for dx in (0, 1280, -1280):
            for k in range(4):
                yy = y + k * h * 0.55
                ww = w * (1 - k * 0.2)
                b.append('<ellipse cx="%.0f" cy="%.0f" rx="%.0f" ry="%.0f" fill="#ffb7a0" fill-opacity="%.2f"/>'
                         % (x + dx + ww * 0.1 * k, yy, ww / 2, h * 0.5, 0.40 - k * 0.07))
    return svg("\n".join(b), w=1280, h=240)


# ------------------------------------------------------------------ azotea
def building(x, w, top, base, col, win_col, rnd, lit=0.35, antenna=False, roof=None):
    out = ['<rect x="%d" y="%d" width="%d" height="%d" fill="%s"/>' % (x, top, w, base - top, col)]
    if roof == "tank":
        out.append('<rect x="%d" y="%d" width="%d" height="%d" rx="4" fill="%s"/>' % (x + w * 0.3, top - 38, w * 0.4, 34, col))
        out.append('<polygon points="%d,%d %d,%d %d,%d" fill="%s"/>' % (x + w * 0.28, top - 36, x + w * 0.5, top - 56, x + w * 0.72, top - 36, col))
        out.append('<rect x="%d" y="%d" width="4" height="8" fill="%s"/><rect x="%d" y="%d" width="4" height="8" fill="%s"/>'
                   % (x + w * 0.34, top - 6, col, x + w * 0.62, top - 6, col))
    if antenna:
        out.append('<rect x="%d" y="%d" width="3" height="%d" fill="%s"/>' % (x + w / 2, top - 70, 70, col))
        out.append('<circle cx="%d" cy="%d" r="4" fill="#ff4a4a"/><circle cx="%d" cy="%d" r="10" fill="#ff4a4a" fill-opacity="0.25"/>'
                   % (x + w / 2 + 1, top - 70, x + w / 2 + 1, top - 70))
    cols = max(2, int(w // 26))
    gap = w / cols
    y = top + 18
    while y < base - 20:
        for c in range(cols):
            if rnd.random() < lit:
                out.append('<rect x="%.1f" y="%d" width="%.1f" height="12" fill="%s" fill-opacity="%.2f"/>'
                           % (x + c * gap + gap * 0.25, y, gap * 0.5, win_col[rnd.randrange(len(win_col))], rnd.uniform(0.65, 1)))
        y += 28
    return "".join(out)


def rooftop_bg():
    defs = lin("sky", [(0, "#070a26", None), (0.35, "#161b5a", None), (0.62, "#4a2a82", None), (0.82, "#b44a84", None),
                       (1, "#ff8a7a", None)])
    defs += rad("moon", [(0, "#fffbe8", 0.9), (0.4, "#c8d4ff", 0.35), (1, "#9fb4ff", 0)])
    defs += lin("haze", [(0, "#ff7ac0", 0.0), (0.55, "#ff7ac0", 0.38), (1, "#ff7ac0", 0.0)])
    rnd = random.Random(21)
    b = ['<rect width="%d" height="%d" fill="url(#sky)"/>' % (W, H)]
    b.append('<circle cx="240" cy="170" r="190" fill="url(#moon)"/>')
    b.append('<circle cx="240" cy="170" r="74" fill="#f6f2dc"/>')
    for (cx, cy, r) in ((218, 150, 15), (262, 196, 11), (232, 202, 7), (270, 148, 8)):
        b.append('<circle cx="%d" cy="%d" r="%d" fill="#dcd6bc"/>' % (cx, cy, r))
    b.append('<circle cx="240" cy="170" r="74" fill="none" stroke="#ffffff" stroke-opacity="0.35" stroke-width="3"/>')
    pal_far = ["#2a2a68", "#2f2f72"]
    x = -20
    while x < W:                                              # edificios lejanos
        w = rnd.randrange(60, 120)
        top = rnd.randrange(330, 430)
        b.append(building(x, w, top, 730, pal_far[rnd.randrange(2)], ["#ffd36b", "#9fd0ff"], rnd, lit=0.18))
        x += w + rnd.randrange(0, 10)
    b.append('<rect x="0" y="420" width="%d" height="300" fill="url(#haze)"/>' % W)
    x = -30
    while x < W:                                              # edificios medios
        w = rnd.randrange(90, 170)
        top = rnd.randrange(390, 500)
        b.append(building(x, w, top, 730, "#1a1a4a", ["#ffd36b", "#ffb0e0", "#9fd0ff"], rnd, lit=0.3,
                          antenna=rnd.random() < 0.25, roof="tank" if rnd.random() < 0.15 else None))
        x += w + rnd.randrange(4, 16)
    # carteles de neon
    for (x0, y0, w0, h0, col) in ((820, 440, 90, 44, "#ff4fb8"), (150, 470, 70, 36, "#38e8ff")):
        b.append('<rect x="%d" y="%d" width="%d" height="%d" rx="8" fill="#0d0d2e" stroke="%s" stroke-width="4"/>' % (x0, y0, w0, h0, col))
        b.append('<rect x="%d" y="%d" width="%d" height="%d" rx="14" fill="%s" fill-opacity="0.16"/>' % (x0 - 10, y0 - 10, w0 + 20, h0 + 20, col))
        b.append('<path d="M %d %d L %d %d L %d %d" stroke="%s" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
                 % (x0 + 16, y0 + h0 - 12, x0 + w0 / 2, y0 + 12, x0 + w0 - 16, y0 + h0 - 12, col))
    # costados cercanos (donde se ve el vacio bajo las plataformas)
    b.append('<rect x="-4" y="560" width="250" height="170" fill="#0c0c2a"/>')
    b.append('<rect x="1034" y="580" width="250" height="150" fill="#0c0c2a"/>')
    for k in range(5):
        b.append('<rect x="%d" y="%d" width="26" height="14" fill="#ffd36b" fill-opacity="%.2f"/>' % (22 + k * 44, 600 + (k % 2) * 40, 0.4 + 0.12 * k))
    for k in range(5):
        b.append('<rect x="%d" y="%d" width="26" height="14" fill="#9fd0ff" fill-opacity="%.2f"/>' % (1056 + k * 44, 620 + (k % 2) * 40, 0.4 + 0.1 * k))
    return svg("\n".join(b), defs=defs)


def stars_strip():
    rnd = random.Random(5)
    b = []
    for _ in range(150):
        x, y = rnd.uniform(0, W), rnd.uniform(0, 380)
        r = rnd.choice((0.8, 1.0, 1.2, 1.6, 2.0))
        b.append('<circle cx="%.0f" cy="%.0f" r="%.1f" fill="#ffffff" fill-opacity="%.2f"/>' % (x, y, r, rnd.uniform(0.45, 1) * (1 - y / 520)))
    for _ in range(14):                                         # brillos en cruz
        x, y = rnd.uniform(0, W), rnd.uniform(0, 300)
        b.append('<path d="M %.0f %.0f h 10 M %.0f %.0f v 10" stroke="#ffffff" stroke-width="1.2" stroke-opacity="0.8" transform="translate(-5,-5)"/>' % (x, y + 5, x + 5, y))
    return svg("\n".join(b), w=1280, h=400)


def main():
    os.makedirs(OUT, exist_ok=True)
    for name, content in (("bg_desierto.svg", desert_bg()), ("nubes_desierto.svg", clouds_strip()),
                          ("bg_azotea.svg", rooftop_bg()), ("estrellas_azotea.svg", stars_strip())):
        with open(os.path.join(OUT, name), "w") as f:
            f.write(content)
        print("Escrito", name)


if __name__ == "__main__":
    main()
