extends SceneTree
# Cada escenario: carga bien, los luchadores aparecen sobre el suelo, aterrizan en
# CADA plataforma, las plataformas están alcanzables con salto + doble salto y
# dentro de la zona de KO.   godot --path . -s tools/test_escenarios.gd

var fails := 0


func check(name, ok, extra = "") -> void:
	if ok:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FALLO]", name, " ", extra)


func wait(t: float):
	yield(create_timer(t), "timeout")


func _init() -> void:
	call_deferred("_run")


func _run():
	var game = root.get_node("Game")
	var Config = root.get_node("Config")
	for si in range(game.STAGES.size()):
		var id: String = game.STAGES[si]["id"]
		print("== Escenario ", id)
		game.stage_index = si
		game.selected = ["gaviotero", "topo"]
		var arena = load("res://scenes/Arena.tscn").instance()
		root.add_child(arena)
		yield(wait(1.0), "completed")
		var st = arena.get_node("Stage")
		check(id + ": existe Stage con fondo, suelo y plataformas", st.has_node("Background") and st.has_node("Ground") \
			and st.has_node("GroundTiles"))
		var f = arena.fighters[0]
		check(id + ": P1 aparece y se queda sobre el suelo", f.is_on_floor() and abs(f.position.y - (480.0 - Config.FEET_OFFSET)) < 3.0, str(f.position))
		check(id + ": P2 aparece y se queda sobre el suelo", arena.fighters[1].is_on_floor(), str(arena.fighters[1].position))
		var mus = load(game.STAGES[si]["music"])
		check(id + ": su música existe y dura más de 30 s", mus != null and mus.get_length() > 30.0, str(mus.get_length() if mus else 0))
		check(id + ": la arena toca la música del escenario", game.current_music == game.STAGES[si]["music"] and game.music_player.playing \
			and game.music_player.stream.loop)
		var ground = st.get_node("Ground")
		var gw: float = ground.get_node("Shape").shape.extents.x
		check(id + ": el suelo cubre los puntos de aparición", ground.position.x - gw < Config.SPAWN_POINTS[0].x and ground.position.x + gw > Config.SPAWN_POINTS[1].x)
		# el dibujo de tiles coincide con la colisión
		var tiles = st.get_node("GroundTiles")
		var tile_w: float = tiles.cols * 48.0
		check(id + ": tiles del suelo = ancho de la colisión", abs(tiles.position.x - (ground.position.x - gw)) < 1.0 and abs(tile_w - gw * 2.0) < 1.0)
		var jump_h: float = pow(f.stats.jump_speed, 2) / (2.0 * f.stats.gravity)
		var reach: float = jump_h * (1.0 + Config.AIR_JUMP_MULTIPLIER * Config.AIR_JUMP_MULTIPLIER)   # salto + doble salto
		for body in st.get_children():
			if not (body is StaticBody2D) or body == ground:
				continue
			var half: float = body.get_node("Shape").shape.extents.x
			var top: float = body.position.y - body.get_node("Shape").shape.extents.y
			var pt = st.get_node(body.name + "Tiles")
			check("%s: %s tiles alineados con la colisión" % [id, body.name], abs(pt.position.x - (body.position.x - half)) < 1.0 \
				and abs(pt.position.y - top) < 1.0 and abs(pt.cols * 48.0 - half * 2.0) < 1.0)
			f.position = Vector2(body.position.x, top - 120.0)
			f.velocity = Vector2.ZERO
			yield(wait(0.7), "completed")
			check("%s: se aterriza sobre %s" % [id, body.name], f.is_on_floor() and abs(f.position.y - (top - Config.FEET_OFFSET)) < 3.0, str(f.position))
			check("%s: %s dentro de la zona de KO" % [id, body.name], body.position.x - half > Config.BLAST_LEFT and body.position.x + half < Config.BLAST_RIGHT)
			# alcanzable: desde el suelo o desde otra plataforma mas baja a <= alcance (con margen)
			var best := 480.0 - top
			for other in st.get_children():
				if other is StaticBody2D and other != body and other != ground:
					var otop: float = other.position.y - other.get_node("Shape").shape.extents.y
					if otop > top:
						best = min(best, otop - top)
			check("%s: %s alcanzable (sube %d px, alcance %d)" % [id, body.name, best, reach], best <= reach * 0.9)
		arena._finish(0)
		yield(wait(0.2), "completed")
		check(id + ": al ganar suena la fanfarria una sola vez", game.current_music == game.VICTORY_MUSIC and game.music_player.playing \
			and not game.music_player.stream.loop)
		arena.queue_free()
		yield(wait(0.1), "completed")
	for path in [game.MENU_MUSIC, game.SELECT_MUSIC, game.BATTLE_MUSIC, game.VICTORY_MUSIC]:
		var m = load(path)
		check("música " + path.get_file(), m != null and m.get_length() > 5.0)
	game.stage_index = 0
	print("")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
