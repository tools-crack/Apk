#!/usr/bin/env python3
"""Sintetiza todos los efectos de sonido (WAV) y la música (OGG) del proyecto.

Uso:  python3 tools/make_audio.py
Requiere numpy y ffmpeg (ffmpeg solo para convertir la música a .ogg).
"""
import os
import subprocess
import wave

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, ".."))
SND = os.path.join(PROJ, "assets", "sounds")
MUS = os.path.join(PROJ, "assets", "music")
SR = 44100
RNG = np.random.RandomState(7)


# ------------------------------------------------------------- utilidades
def t_axis(dur):
    return np.arange(int(SR * dur)) / SR


def env_exp(n, decay):
    return np.exp(-np.arange(n) / SR * decay)


def adsr(n, a=0.005, d=0.05, s=0.7, r=0.05):
    e = np.ones(n) * s
    na, nd, nr = int(a * SR), int(d * SR), int(r * SR)
    na, nd, nr = min(na, n), min(nd, max(n - na, 0)), min(nr, n)
    if na:
        e[:na] = np.linspace(0, 1, na)
    if nd:
        e[na:na + nd] = np.linspace(1, s, nd)
    if nr:
        e[n - nr:] *= np.linspace(1, 0, nr)
    return e


def noise(dur):
    return RNG.uniform(-1, 1, int(SR * dur))


def fft_filter(x, lo=None, hi=None):
    """Filtro pasa-banda sencillo por FFT (lo = pasa-altos, hi = pasa-bajos)."""
    spec = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    mask = np.ones_like(f)
    if lo:
        mask *= 1 / (1 + (lo / np.maximum(f, 1e-3)) ** 4)
    if hi:
        mask *= 1 / (1 + (f / hi) ** 4)
    return np.fft.irfft(spec * mask, len(x))


def sweep_phase(freqs):
    return 2 * np.pi * np.cumsum(freqs) / SR


def osc(kind, freq, n, duty=0.5):
    """freq puede ser un escalar o un array de n valores."""
    f = np.full(n, float(freq)) if np.isscalar(freq) else freq
    ph = (np.cumsum(f) / SR) % 1.0
    if kind == "sine":
        return np.sin(2 * np.pi * ph)
    if kind == "square":
        return np.where(ph < duty, 1.0, -1.0)
    if kind == "saw":
        return 2 * ph - 1
    if kind == "tri":
        return 4 * np.abs(ph - 0.5) - 1
    raise ValueError(kind)


def norm(x, peak=0.9):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak


def save_wav(name, x):
    os.makedirs(SND, exist_ok=True)
    x = np.clip(x, -1, 1)
    data = (x * 32767).astype("<i2")
    with wave.open(os.path.join(SND, name), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


def fade_out(x, ms=8):
    n = int(SR * ms / 1000)
    x = x.copy()
    x[-n:] *= np.linspace(1, 0, n)
    return x


def midi(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


# ---------------------------------------------------------------- efectos
def sfx_jump():
    n = int(SR * 0.2)
    f = np.linspace(280, 720, n)
    return norm(osc("sine", f, n) * env_exp(n, 12), 0.7)


def sfx_land():
    n = int(SR * 0.14)
    th = osc("sine", np.linspace(120, 50, n), n) * env_exp(n, 30)
    nz = fft_filter(noise(0.14), hi=900) * env_exp(n, 40)
    return norm(th + 0.6 * nz, 0.7)


def sfx_swing():
    n = int(SR * 0.22)
    nz = fft_filter(noise(0.22), lo=700, hi=5000)
    e = np.sin(np.linspace(0, np.pi, n)) ** 2
    return norm(nz * e, 0.65)


def sfx_hit():
    n = int(SR * 0.28)
    th = osc("sine", np.linspace(180, 45, n), n) * env_exp(n, 16)
    crack = fft_filter(noise(0.28), lo=1500) * env_exp(n, 45)
    return norm(th + 0.7 * crack, 0.95)


def sfx_gull():
    """Dos graznidos de gaviota ('kiii-aah')."""
    def call(dur, f0, fpk, f1):
        n = int(SR * dur)
        t = np.arange(n) / SR
        k = int(n * 0.25)
        f = np.concatenate([np.linspace(f0, fpk, k), np.linspace(fpk, f1, n - k)])
        f = f * (1 + 0.035 * np.sin(2 * np.pi * 27 * t))        # vibrato rápido
        ph = 2 * np.pi * np.cumsum(f) / SR
        s = sum(np.sin(h * ph) / (h ** 0.8) for h in range(1, 9))
        s += 0.25 * fft_filter(noise(dur), lo=1500, hi=6000)    # aspereza
        e = adsr(n, a=0.02, d=0.08, s=0.8, r=0.12)
        return s * e
    a = call(0.28, 1000, 2100, 1500)
    gap = np.zeros(int(SR * 0.05))
    b = call(0.42, 1100, 2000, 900)
    return norm(np.concatenate([a, gap, b]), 0.8)


def crackle(dur, density, decay=None):
    n = int(SR * dur)
    imp = (RNG.uniform(0, 1, n) < density / SR) * RNG.uniform(-1, 1, n)
    out = fft_filter(imp, lo=400, hi=4000)
    if decay:
        out *= env_exp(n, decay)
    return out


def sfx_dig():
    n = int(SR * 0.55)
    nz = noise(0.55)
    # ruido que se vuelve más grave: mezcla de dos filtros con fundido cruzado
    hi_part = fft_filter(nz, lo=300, hi=3500)
    lo_part = fft_filter(nz, hi=450)
    mix = np.linspace(1, 0, n)
    body = (hi_part * mix + lo_part * (1 - mix) * 1.5) * adsr(n, a=0.01, d=0.1, s=0.8, r=0.2)
    thump = osc("sine", np.linspace(110, 45, n), n) * env_exp(n, 7) * 0.8
    return norm(body + thump + crackle(0.55, 90, 3) * 1.4, 0.9)


def sfx_rumble():
    n = int(SR * 0.75)
    t = np.arange(n) / SR
    low = fft_filter(noise(0.75), hi=260) * 3
    trem = 0.65 + 0.35 * np.sin(2 * np.pi * 15 * t)
    e = adsr(n, a=0.05, d=0.05, s=0.9, r=0.18)
    return norm(low * trem * e + crackle(0.75, 70) * 0.9 * e, 0.8)


def sfx_emerge():
    n = int(SR * 0.5)
    nz = noise(0.5)
    lo_part, hi_part = fft_filter(nz, hi=500), fft_filter(nz, lo=500, hi=4500)
    mix = np.linspace(0, 1, n)
    body = (lo_part * (1 - mix) * 2 + hi_part * mix) * adsr(n, a=0.12, d=0.1, s=0.7, r=0.15)
    pop_n = int(SR * 0.3)
    pop = np.zeros(n)
    pop[int(SR * 0.12):int(SR * 0.12) + pop_n] = osc("sine", np.linspace(160, 50, pop_n), pop_n) * env_exp(pop_n, 13)
    return norm(body * 0.7 + pop * 1.1 + crackle(0.5, 80, 2), 0.9)


def sfx_rock():
    """Impacto de una roca (Likan): golpe grave + restos de piedra."""
    n = int(SR * 0.6)
    thump = osc("sine", np.linspace(130, 40, n), n) * env_exp(n, 9) * 1.2
    body = fft_filter(noise(0.6), lo=120, hi=2500) * env_exp(n, 7) * 0.8
    return norm(thump + body + crackle(0.6, 160, 5) * 1.6, 0.9)


def sfx_noodle():
    """Tallarines brotando (Aukin): chapoteo húmedo que sube de tono."""
    n = int(SR * 0.55)
    t = np.arange(n) / SR
    wet = fft_filter(noise(0.55), lo=500, hi=2800) * (0.6 + 0.4 * np.sin(2 * np.pi * 22 * t))
    wet *= adsr(n, a=0.08, d=0.1, s=0.7, r=0.15)
    glide = osc("sine", np.linspace(180, 520, n), n) * adsr(n, a=0.05, d=0.1, s=0.6, r=0.2) * 0.45
    return norm(wet * 1.2 + glide + crackle(0.55, 60, 4) * 0.5, 0.85)


def sfx_drag():
    """Aspirar un cigarro (Ñanco): crepitar de la brasa + siseo que sube."""
    n = int(SR * 0.55)
    hiss = fft_filter(noise(0.55), lo=2000, hi=7000) * np.linspace(0.2, 1.0, n) * adsr(n, a=0.12, d=0.05, s=0.8, r=0.15)
    burn = crackle(0.55, 180, 3) * np.linspace(0.4, 1.4, n)
    return norm(hiss * 1.1 + burn, 0.8)


def sfx_smoke():
    """Soplar humo (Ñanco): ráfaga de aire grave que se apaga."""
    n = int(SR * 0.7)
    air = fft_filter(noise(0.7), lo=250, hi=2600) * adsr(n, a=0.08, d=0.15, s=0.6, r=0.3)
    sweep = fft_filter(noise(0.7), hi=500) * env_exp(n, 3.5) * 0.9
    return norm(air * 1.2 + sweep, 0.85)


def sfx_spike():
    """Pinchos que brotan (Winkul): golpe seco + chasquido metálico."""
    n = int(SR * 0.4)
    thump = osc("sine", np.linspace(150, 55, n), n) * env_exp(n, 12) * 1.0
    ping = osc("sine", np.linspace(2100, 1500, n), n) * env_exp(n, 16) * 0.35
    scrape = fft_filter(noise(0.4), lo=1500, hi=6500) * env_exp(n, 20) * 0.9
    return norm(thump + ping + scrape, 0.9)


def sfx_cast():
    """Lanzar la caña (Jorge): zumbido de línea que sale disparada."""
    n = int(SR * 0.4)
    whoosh = fft_filter(noise(0.4), lo=900, hi=7000) * adsr(n, a=0.05, d=0.08, s=0.5, r=0.2)
    zip_ = osc("sine", np.linspace(500, 2400, n), n) * env_exp(n, 7) * 0.25
    return norm(whoosh + zip_, 0.8)


def sfx_reel():
    """Carrete recogiendo (Jorge): clics rápidos de matraca + tirón."""
    n = int(SR * 0.5)
    clicks = np.zeros(n)
    for i in range(0, n, int(SR * 0.035)):
        m = min(int(SR * 0.012), n - i)
        clicks[i:i + m] += fft_filter(noise(0.012), lo=1500, hi=6000)[:m] * np.linspace(1, 0, m)
    thump = osc("sine", np.linspace(180, 70, n), n) * env_exp(n, 14) * 0.5
    return norm(clicks * 1.4 + thump, 0.85)


def sfx_ko():
    n = int(SR * 0.8)
    f = np.linspace(700, 70, n)
    s = osc("saw", f, n) * env_exp(n, 3.2) * 0.6
    burst = fft_filter(noise(0.8), lo=500) * env_exp(n, 14)
    ping = osc("sine", 1800, n) * env_exp(n, 9) * 0.25
    return norm(s + burst * 0.8 + ping, 0.9)


def blip(freqs, step, kind="square", vol=0.5, decay=14):
    out = []
    for fr in freqs:
        n = int(SR * step)
        out.append(osc(kind, fr, n, 0.4) * env_exp(n, decay) * vol)
    return np.concatenate(out)


def sfx_select():
    return norm(blip([880], 0.07), 0.55)


def sfx_confirm():
    return norm(blip([660, 990], 0.08), 0.6)


def sfx_back():
    return norm(blip([520, 390], 0.07), 0.55)


def sfx_count():
    return norm(blip([660], 0.16, decay=8), 0.6)


def sfx_go():
    return norm(blip([880, 1320], 0.18, decay=5), 0.7)


def sfx_nope():
    n = int(SR * 0.14)
    return norm(osc("square", 110, n, 0.5) * env_exp(n, 18), 0.4)


def sfx_win():
    notes = [72, 76, 79, 84, 79, 84]
    out = []
    for i, m in enumerate(notes):
        dur = 0.13 if i < 5 else 0.5
        n = int(SR * dur)
        out.append(osc("square", midi(m), n, 0.35) * adsr(n, a=0.004, d=0.04, s=0.6, r=0.08) * 0.5)
    return norm(np.concatenate(out), 0.7)


# ----------------------------------------------------------------- música
def note(kind, m, n, vol=0.5, duty=0.5, a=0.004, d=0.06, s=0.6, r=0.04):
    return osc(kind, midi(m), n, duty) * adsr(n, a, d, s, r) * vol


def kick(n=int(SR * 0.22)):
    return osc("sine", np.linspace(150, 45, n), n) * env_exp(n, 20) * 0.9


def snare(n=int(SR * 0.16)):
    return fft_filter(noise(n / SR), lo=1200) * env_exp(n, 26) * 0.5 + \
        osc("sine", 190, n) * env_exp(n, 30) * 0.2


def hat(n=int(SR * 0.05)):
    return fft_filter(noise(n / SR), lo=6000) * env_exp(n, 90) * 0.3


class Track:
    def __init__(self, bpm, bars, tail=1.5):
        self.beat = 60.0 / bpm
        self.bars = bars
        self.len = int(SR * self.beat * 4 * bars)
        self.buf = np.zeros(self.len + int(SR * tail))

    def add(self, beat_pos, sound):
        i = int(SR * self.beat * beat_pos)
        end = min(i + len(sound), len(self.buf))
        self.buf[i:end] += sound[:end - i]

    def render(self):
        out = self.buf[:self.len].copy()
        tail = self.buf[self.len:]
        out[:len(tail)] += tail          # el final se pliega sobre el principio -> bucle sin cortes
        return norm(out, 0.85)


def song_menu():
    tr = Track(92, 8)
    roots = [48, 45, 41, 43, 48, 45, 41, 43]
    arps = [(60, 64, 67), (60, 64, 69), (60, 65, 69), (59, 62, 67)] * 2
    arps[1] = (57, 60, 64)
    melody = [
        [(0, 1.5, 76), (1.5, .5, 74), (2, 1, 72), (3, 1, 67)],
        [(0, 1, 69), (1, 1, 72), (2, 2, 76)],
        [(0, 1.5, 77), (1.5, .5, 76), (2, 1, 74), (3, 1, 72)],
        [(0, 2, 74), (2, 1, 71), (3, 1, 67)],
        [(0, 1, 72), (1, 1, 76), (2, 1, 79), (3, 1, 76)],
        [(0, 1.5, 77), (1.5, .5, 76), (2, 2, 72)],
        [(0, 1, 74), (1, 1, 77), (2, 1, 81), (3, 1, 77)],
        [(0, 1, 79), (1, 1, 74), (2, 2, 71)],
    ]
    for b in range(8):
        base = b * 4
        nb = int(SR * tr.beat * 1.9)
        tr.add(base, note("tri", roots[b] - 12 + 12, nb, 0.55, s=0.8, r=0.1))
        tr.add(base + 2, note("tri", roots[b] + 7 - 12 + 12, nb, 0.45, s=0.8, r=0.1))
        for i in range(8):                                   # arpegio en corcheas
            m = arps[b][i % 3] + (12 if i % 6 == 5 else 0)
            tr.add(base + i * 0.5, note("square", m, int(SR * tr.beat * 0.45), 0.16, duty=0.125, d=0.05, s=0.4))
        for (p, ln, m) in melody[b]:
            tr.add(base + p, note("square", m, int(SR * tr.beat * ln * 0.95), 0.2, duty=0.25, a=0.01, d=0.1, s=0.6, r=0.08))
        for i in range(4):
            tr.add(base + i + 0.5, hat() * 0.8)
        tr.add(base, kick() * 0.6)
        tr.add(base + 2, kick() * 0.45)
    return tr.render()


def song_battle():
    tr = Track(152, 16)
    roots = [45, 41, 48, 43, 45, 41, 43, 40] * 2
    arps = {45: (60, 64, 69), 41: (60, 65, 69), 48: (60, 64, 67), 43: (59, 62, 67), 40: (59, 64, 68)}
    phrase_a = [
        [(0, .5, 81), (.5, .5, 81), (1, 1, 84), (2, .5, 83), (2.5, .5, 81), (3, 1, 76)],
        [(0, .5, 77), (.5, .5, 77), (1, 1, 81), (2, .5, 79), (2.5, .5, 77), (3, 1, 72)],
        [(0, .5, 79), (.5, .5, 79), (1, 1, 84), (2, .5, 83), (2.5, .5, 79), (3, 1, 76)],
        [(0, 1, 79), (1, .5, 78), (1.5, .5, 79), (2, 2, 83)],
        [(0, .5, 81), (.5, .5, 84), (1, 1, 88), (2, .5, 86), (2.5, .5, 84), (3, 1, 81)],
        [(0, .5, 84), (.5, .5, 81), (1, 1, 77), (2, .5, 81), (2.5, .5, 84), (3, 1, 89)],
        [(0, 1, 86), (1, 1, 83), (2, 1, 79), (3, 1, 74)],
        [(0, .5, 76), (.5, .5, 80), (1, .5, 83), (1.5, .5, 80), (2, 2, 88)],
    ]
    for b in range(16):
        base = b * 4
        r = roots[b]
        for i in range(8):                                   # bajo en corcheas
            m = r if i % 4 != 3 else r + 12
            tr.add(base + i * 0.5, note("tri", m, int(SR * tr.beat * 0.48), 0.6, s=0.8, r=0.03))
        tri = arps[r]
        for i in range(16):                                  # arpegio en semicorcheas
            m = tri[i % 3] + (12 if (i // 3) % 2 else 0)
            tr.add(base + i * 0.25, note("square", m, int(SR * tr.beat * 0.22), 0.1, duty=0.125, d=0.03, s=0.4, r=0.02))
        phrase = phrase_a[b % 8]
        octave = 0 if b < 8 else 0
        for (p, ln, m) in phrase:
            m2 = m + octave
            tr.add(base + p, note("square", m2, int(SR * tr.beat * ln * 0.92), 0.2, duty=0.25, a=0.006, d=0.08, s=0.65, r=0.05))
            if b >= 8:                                       # segunda mitad: lead doblado una octava abajo
                tr.add(base + p, note("square", m2 - 12, int(SR * tr.beat * ln * 0.92), 0.1, duty=0.5, d=0.08, s=0.6, r=0.05))
        for i in range(4):
            tr.add(base + i, hat() * (1.0 if i % 2 else 0.7))
            tr.add(base + i + 0.5, hat() * 0.6)
        tr.add(base, kick())
        tr.add(base + 1.5, kick() * 0.7)
        tr.add(base + 2, kick())
        tr.add(base + 1, snare())
        tr.add(base + 3, snare())
    return tr.render()


def save_ogg(name, x):
    os.makedirs(MUS, exist_ok=True)
    tmp = os.path.join(MUS, name + ".tmp.wav")
    with wave.open(tmp, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())
    out = os.path.join(MUS, name + ".ogg")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libvorbis", "-q:a", "4", out], check=True)
    os.remove(tmp)


def main():
    sfx = {
        "jump": sfx_jump, "land": sfx_land, "swing": sfx_swing, "hit": sfx_hit, "gull": sfx_gull,
        "dig": sfx_dig, "rumble": sfx_rumble, "emerge": sfx_emerge, "ko": sfx_ko,
        "select": sfx_select, "confirm": sfx_confirm, "back": sfx_back, "count": sfx_count,
        "go": sfx_go, "nope": sfx_nope, "win": sfx_win,
    }
    for name, fn in sfx.items():
        save_wav(name + ".wav", fade_out(fn()))
    save_ogg("menu_theme", song_menu())
    save_ogg("battle_theme", song_battle())
    # Sonidos de personajes añadidos después (van al final para no alterar la música generada antes)
    for name, fn in {"rock": sfx_rock, "noodle": sfx_noodle, "drag": sfx_drag, "smoke": sfx_smoke, "spike": sfx_spike, "cast": sfx_cast, "reel": sfx_reel}.items():
        save_wav(name + ".wav", fade_out(fn()))
    print("Audio generado en", SND, "y", MUS)


if __name__ == "__main__":
    main()
