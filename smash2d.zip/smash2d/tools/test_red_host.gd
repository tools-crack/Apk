extends SceneTree
# ============================================================================
#  test_red_host.gd — mitad ANFITRIÓN de la prueba de red (ejecutar a la vez que test_red_cliente.gd)
# ----------------------------------------------------------------------------
#      godot --path . --no-window -s tools/test_red_host.gd      &
#      godot --path . --no-window -s tools/test_red_cliente.gd   &
#  O con todo junto:  bash tools/probar_red.sh
#  El anfitrión (P1 = Jorge) espera al cliente (P2 = Gaviotero), arranca la partida, comprueba que los botones
#  del cliente mueven al P2 en el anfitrión, y lanza la caña de Jorge para que el cliente compruebe
#  que el anzuelo (un efecto) se replica bien.
# ============================================================================
const TEST_PORT := 7791
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func _initialize():
	_run()


func _run():
	var net = root.get_node("Net")
	var game = root.get_node("Game")
	print("== RED (anfitrión)")
	check("el anfitrión abre el puerto", net.start_host(TEST_PORT) == OK)
	var g := 0
	while net.peer_id == 0 and g < 600:                       # hasta 30 s esperando al cliente
		yield(wait(0.05), "completed")
		g += 1
	check("el cliente se conecta", net.peer_id != 0)
	if net.peer_id == 0:
		quit(1)
		return
	game.selected = ["jorge", "gaviotero"]
	game.practice = false
	game.stage_index = 0
	var arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	var p1 = arena.fighters[0]
	var p2 = arena.fighters[1]
	arena.net_sync.debug_stats = true
	check("P2 queda como jugador remoto", p2.net_remote and not p1.net_remote)
	g = 0
	while not net.client_ready and g < 400:
		yield(wait(0.05), "completed")
		g += 1
	check("el cliente carga la arena y avisa", net.client_ready)
	g = 0
	while not p1.input_enabled and g < 400:                    # cuenta atrás 3-2-1
		yield(wait(0.05), "completed")
		g += 1
	check("empieza la partida", p1.input_enabled and p2.input_enabled)
	var t0 = p2.position.x
	yield(wait(1.4), "completed")                              # el cliente mantiene "izquierda" ~0.7 s (hacia el P1)
	check("los botones del cliente mueven al P2 en el anfitrión", p2.position.x < t0 - 40.0, "dx=%.0f" % (p2.position.x - t0))
	yield(wait(4.8), "completed")
	check("el especial del P2 (gaviota) sube el % del P1", p1.percent > 0.0, "percent=%.1f" % p1.percent)
	print("   tamaño de un paquete de estado: %d bytes  %s" % [arena.net_sync.debug_bytes, str(arena.net_sync.debug_parts)])
	check("un paquete de estado es pequeño (< 1300 bytes (cabe en un paquete UDP sin fragmentar))", arena.net_sync.debug_bytes > 0 and arena.net_sync.debug_bytes < 1300)
	yield(wait(1.0), "completed")
	Input.action_press("p1_special")                           # Jorge lanza la caña
	yield(wait(0.1), "completed")
	Input.action_release("p1_special")
	check("la partida sigue conectada", net.is_host() and net.peer_id != 0)
	yield(wait(7.0), "completed")                              # el cliente termina y se va: el anfitrión debe soportarlo sin caerse
	print("RESULTADO anfitrión: %s" % ("TODO OK" if fails == 0 else "%d fallos" % fails))
	net.stop()
	quit(1 if fails > 0 else 0)
