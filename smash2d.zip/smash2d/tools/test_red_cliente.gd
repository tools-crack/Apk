extends SceneTree
# ============================================================================
#  test_red_cliente.gd — mitad CLIENTE de la prueba de red (ver test_red_host.gd)
# ----------------------------------------------------------------------------
#  Se conecta, mueve a su luchador con p2_right, lanza la especial (gaviota) y comprueba que lo
#  que ve (posiciones, efectos, variables) coincide con lo que simula el anfitrión.
# ============================================================================
const TEST_PORT := 7791
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func find_all(node, script_name, out := []):
	for c in node.get_children():
		if c.get_script() != null and c.get_script().resource_path.ends_with(script_name):
			out.append(c)
		find_all(c, script_name, out)
	return out


func _initialize():
	_run()


func _run():
	var net = root.get_node("Net")
	print("== RED (cliente)")
	# --- descubrimiento: un paquete "SMASH2D|puerto|nombre" aparece en la lista
	net.start_discovery()
	var udp = PacketPeerUDP.new()
	udp.set_dest_address("127.0.0.1", net.DISCOVERY_PORT)
	udp.put_packet(("%s|%d|PruebaPC" % [net.MAGIC, TEST_PORT]).to_utf8())
	yield(wait(0.5), "completed")
	check("el cliente descubre partidas por UDP", net.found_hosts.has("127.0.0.1") and net.found_hosts["127.0.0.1"]["name"] == "PruebaPC", str(net.found_hosts))
	net.stop_discovery()
	udp.close()
	var connected := [false]
	net.connect("connected", self, "_on_connected", [connected])
	check("el cliente inicia la conexión", net.join("127.0.0.1", TEST_PORT) == OK)
	var g := 0
	while not connected[0] and g < 400:
		yield(wait(0.05), "completed")
		g += 1
	check("conectado al anfitrión", connected[0] and net.is_client() and net.peer_id == 1)
	# net_begin lo manda el anfitrión al abrir su arena y nos lleva a ella
	g = 0
	var arena = null
	while arena == null and g < 600:
		yield(wait(0.05), "completed")
		arena = root.get_node_or_null("Arena")
		g += 1
	check("el cliente salta a la arena solo", arena != null)
	if arena == null:
		quit(1)
		return
	check("el cliente recibió los personajes", root.get_node("Game").selected == ["jorge", "gaviotero"], str(root.get_node("Game").selected))
	var p1 = arena.fighters[0]
	var p2 = arena.fighters[1]
	check("los luchadores del cliente son fantasmas", p1.net_puppet and p2.net_puppet)
	check("el cliente no simula nada", not p1.is_physics_processing() and not p2.is_physics_processing())
	g = 0
	while not p2.input_enabled and g < 600:                    # input_enabled llega por la red
		yield(wait(0.05), "completed")
		g += 1
	check("el cliente ve que empezó la partida (variables replicadas)", p2.input_enabled)
	check("el mensaje de la arena se replica", arena.message.text == "¡YA!" or arena.message.text == "")
	# --- mover por la red
	var x0 = p2.position.x
	Input.action_press("p2_left")
	yield(wait(0.7), "completed")
	Input.action_release("p2_left")
	yield(wait(0.3), "completed")
	check("lo que mando se ve en mi pantalla (ida y vuelta)", p2.position.x < x0 - 40.0, "dx=%.0f" % (p2.position.x - x0))
	check("la animación del P2 es de correr o parar", p2.sprite.animation in ["run", "idle"], p2.sprite.animation)
	# --- especial: Gaviota
	Input.action_press("p2_special")
	yield(wait(0.1), "completed")
	Input.action_release("p2_special")
	g = 0
	var gulls := []
	while gulls.empty() and g < 60:
		yield(wait(0.05), "completed")
		gulls = find_all(arena, "Gull.gd")
		g += 1
	check("la gaviota (efecto) aparece en el cliente", not gulls.empty())
	if not gulls.empty():
		var gull = gulls[0]
		var xa = gull.position.x
		yield(wait(0.3), "completed")
		check("la gaviota se mueve en el cliente", abs(gull.position.x - xa) > 30.0, "dx=%.0f" % (gull.position.x - xa))
		check("la gaviota sabe quién la lanzó (nodo replicado)", gull.shooter == p2)
		check("la gaviota no hace daño por su cuenta en el cliente", not gull.monitoring)
	yield(wait(4.0), "completed")
	check("el daño que hace la gaviota llega al cliente (percent del P1)", p1.percent > 0.0, "percent=%.1f" % p1.percent)
	# --- especial de Jorge (lo lanza el anfitrión)
	g = 0
	var hooks := []
	while hooks.empty() and g < 400:
		yield(wait(0.05), "completed")
		hooks = find_all(arena, "Hook.gd")
		g += 1
	check("el anzuelo de Jorge aparece en el cliente", not hooks.empty())
	if not hooks.empty():
		var h = hooks[0]
		check("el anzuelo sabe quién lo lanzó (Jorge)", h.shooter == p1)
		check("el anzuelo tiene su ficha (recurso replicado)", h.stats != null and h.stats.hook_range > 0.0)
		var phases := {}
		for i in range(20):
			if is_instance_valid(h):
				phases[h.phase] = true
			yield(wait(0.05), "completed")
		check("la fase del anzuelo se actualiza en el cliente", phases.size() >= 1, str(phases.keys()))
	yield(wait(3.0), "completed")
	check("el anzuelo desaparece del cliente al terminar", find_all(arena, "Hook.gd").empty())
	check("sigue conectado", net.is_client() and net.peer_id == 1)
	print("RESULTADO cliente: %s" % ("TODO OK" if fails == 0 else "%d fallos" % fails))
	net.stop()
	quit(1 if fails > 0 else 0)


func _on_connected(flag):
	flag[0] = true
