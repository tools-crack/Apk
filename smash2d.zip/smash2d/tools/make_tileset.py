#!/usr/bin/env python3
"""Genera el tileset del escenario (suelo y plataformas, NO el fondo):
   - assets/sprites/stage/tileset_atlas.png  (atlas de tiles, con sangrado anti-costuras)
   - resources/stage_tileset.tres            (TileSet de Godot 3.5 que lo referencia)

Estilo "pradera soleada": pasto con volumen (borde ondulado, brillo arriba, brizna y flores),
tierra cálida con estratos, piedritas y motas. Los tiles de en medio encajan SIN costura
(las motas y piedras "dan la vuelta" por los bordes) y solo los tiles del borde llevan
contorno oscuro. Se dibuja al cuádruple de tamaño y se reduce, para que quede suave.

Estilos (cada uno con su atlas y su .tres; el nombre de los tiles es el mismo en todos, asi
StageTiles.gd funciona con cualquiera):
  pradera -> assets/sprites/stage/tileset_atlas.png         + resources/stage_tileset.tres
  desierto-> assets/sprites/stage/tileset_desierto.png      + resources/stage_tileset_desierto.tres
  azotea  -> assets/sprites/stage/tileset_azotea.png        + resources/stage_tileset_azotea.tres

Uso: python3 tools/make_tileset.py   (requiere Pillow)
Para cambiar colores o el aspecto edita la sección PALETA y las funciones de dibujo.
"""
import math
import os
import random

from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, ".."))
OUT_PNG = os.path.join(PROJ, "assets", "sprites", "stage", "tileset_atlas.png")
OUT_TRES = os.path.join(PROJ, "resources", "stage_tileset.tres")

T = 48            # tamaño visible de cada tile (px)
PAD = 2           # sangrado por lado (anti-costuras al filtrar la textura)
CELL = T + PAD * 2
COLS, ROWS = 4, 3
SS = 4            # supermuestreo: se dibuja a SS veces el tamaño y se reduce
W = T * SS

# ------------------------------------------------------------------ PALETA
GRASS_LIGHT = (164, 224, 92)
GRASS = (112, 195, 66)
GRASS_DARK = (66, 150, 52)
GRASS_LIP = (44, 110, 48)        # borde inferior del pasto (sombra que cae sobre la tierra)
DIRT = (150, 100, 62)
DIRT_LIGHT = (176, 124, 80)
DIRT_DARK = (118, 77, 48)
DIRT_DEEP = (84, 54, 36)
PEBBLE = (206, 172, 132)
PEBBLE_SHADE = (128, 94, 68)
OUTLINE = (52, 36, 30)
GRASS_OUTLINE = (36, 92, 44)
FLOWER_WHITE = (255, 250, 238)
FLOWER_YELLOW = (255, 216, 74)
FLOWER_PINK = (255, 150, 170)

CAP = 15          # alto del pasto (px finales)
RADIUS = 16       # radio de las esquinas redondeadas (px finales)
OUTLINE_W = 2     # grosor del contorno (px finales)


def s(v):
    return int(round(v * SS))


def wrap_positions(x, y, wrap_x=True, wrap_y=False):
    """Las posiciones donde hay que dibujar un detalle para que el tile sea continuo."""
    xs = [x, x - W, x + W] if wrap_x else [x]
    ys = [y, y - W, y + W] if wrap_y else [y]
    return [(a, b) for a in xs for b in ys]


# ------------------------------------------------------------------ tierra
def dirt_base(seed, wrap_y):
    """Tierra sin costuras: color base + estratos suaves + piedritas + motas."""
    img = Image.new("RGB", (W, W), DIRT)
    d = ImageDraw.Draw(img, "RGBA")                 # "RGBA" = mezcla (blend) la transparencia al dibujar
    rnd = random.Random(seed)
    # estratos: bandas horizontales apenas más claras / oscuras
    for i in range(3):
        y = (i * 17 + rnd.uniform(0, 6)) % T
        h = rnd.uniform(3, 6)
        col = DIRT_LIGHT if i % 2 == 0 else DIRT_DARK
        for (xx, yy) in wrap_positions(0, s(y), True, wrap_y):
            d.rectangle([xx, yy, xx + W, yy + s(h)], fill=col + (70,))
    # motas oscuras
    for _ in range(11):
        x, y, r = rnd.uniform(0, T), rnd.uniform(2, T - 2), rnd.uniform(0.7, 1.5)
        for (xx, yy) in wrap_positions(s(x), s(y), True, wrap_y):
            d.ellipse([xx - s(r), yy - s(r), xx + s(r), yy + s(r)], fill=DIRT_DEEP + (150,))
    # piedritas (claras con sombra por debajo)
    for _ in range(4):
        x, y = rnd.uniform(4, T - 4), rnd.uniform(8, T - 6)
        rx, ry = rnd.uniform(2.2, 4.2), rnd.uniform(1.6, 2.8)
        for (xx, yy) in wrap_positions(s(x), s(y), True, wrap_y):
            d.ellipse([xx - s(rx), yy - s(ry) + s(0.9), xx + s(rx), yy + s(ry) + s(0.9)], fill=PEBBLE_SHADE + (255,))
            d.ellipse([xx - s(rx), yy - s(ry), xx + s(rx), yy + s(ry)], fill=PEBBLE + (255,))
            d.ellipse([xx - s(rx * 0.55), yy - s(ry * 0.7), xx, yy - s(ry * 0.1)], fill=(236, 214, 182, 200))
    return img


# ------------------------------------------------------------------ pasto
def grass_cap(img, seed, flowers=False):
    """Pone el pasto arriba: sombra bajo el borde, borde de "festones", brillo y briznas."""
    d = ImageDraw.Draw(img, "RGBA")
    rnd = random.Random(seed)
    period = 8
    # sombra suave que el pasto proyecta sobre la tierra
    for i in range(6):
        a = int(90 * (1 - i / 6.0))
        d.rectangle([0, s(CAP + 2 + i), W, s(CAP + 3 + i)], fill=DIRT_DEEP + (a,))
    # borde inferior oscuro (festones) y cuerpo del pasto
    for x in range(-period, T + period, period):
        d.ellipse([s(x), s(CAP - 7), s(x + period), s(CAP + 3)], fill=GRASS_LIP + (255,))
    d.rectangle([0, 0, W, s(CAP - 3)], fill=GRASS_LIP + (255,))
    for x in range(-period, T + period, period):
        d.ellipse([s(x), s(CAP - 8), s(x + period), s(CAP + 1)], fill=GRASS + (255,))
    d.rectangle([0, 0, W, s(CAP - 4)], fill=GRASS + (255,))
    # banda de luz arriba y degradado oscuro hacia abajo
    d.rectangle([0, 0, W, s(4)], fill=GRASS_LIGHT + (255,))
    d.rectangle([0, s(4), W, s(5.5)], fill=GRASS_LIGHT + (110,))
    for i in range(4):
        d.rectangle([0, s(CAP - 7 + i), W, s(CAP - 6 + i)], fill=GRASS_DARK + (60 + 25 * i,))
    # briznas (trazos verticales oscuros y claros), repartidas con la vuelta por los bordes
    for _ in range(16):
        x, y0, h = rnd.uniform(0, T), rnd.uniform(3, 8), rnd.uniform(3, 6)
        col = GRASS_DARK if rnd.random() < 0.6 else GRASS_LIGHT
        for (xx, yy) in wrap_positions(s(x), s(y0), True, False):
            d.line([(xx, yy), (xx + s(rnd.uniform(-0.8, 0.8)), yy + s(h))], fill=col + (230,), width=s(1.1))
    if flowers:
        for x, col in ((11, FLOWER_WHITE), (27, FLOWER_YELLOW), (39, FLOWER_PINK)):
            y = 8 + rnd.uniform(-1, 1)
            for k in range(5):
                a = k * 2 * math.pi / 5
                px, py = x + math.cos(a) * 2.1, y + math.sin(a) * 2.1
                d.ellipse([s(px - 1.4), s(py - 1.4), s(px + 1.4), s(py + 1.4)], fill=col + (255,))
            d.ellipse([s(x - 1.1), s(y - 1.1), s(x + 1.1), s(y + 1.1)], fill=(224, 150, 30, 255))


def bottom_shade(img):
    """Oscurece hacia abajo (base de las plataformas flotantes)."""
    d = ImageDraw.Draw(img, "RGBA")
    for i in range(14):
        a = int(150 * (i / 13.0) ** 1.6)
        d.rectangle([0, s(T - 14 + i), W, s(T - 13 + i)], fill=DIRT_DEEP + (a,))


# ------------------------------------------------------------------ forma y contorno
def shape_and_outline(img, left, right, top, bottom, round_tl=False, round_tr=False, round_bl=False, round_br=False):
    """Recorta con esquinas redondeadas y pone contorno SOLO en los lados expuestos.

    left/right/top/bottom: True si ese lado del tile da al vacío (lleva contorno)."""
    ox0 = 0 if left else -3 * W
    ox1 = W if right else 4 * W
    oy0 = 0 if top else -3 * W
    oy1 = W if bottom else 4 * W
    corners = (round_tl, round_tr, round_br, round_bl)
    r = s(RADIUS)
    mask = Image.new("L", (W, W), 0)
    md = ImageDraw.Draw(mask)
    md.rounded_rectangle([ox0, oy0, ox1 - 1, oy1 - 1], radius=r, fill=255, corners=corners)
    out = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    out.paste(img.convert("RGBA"), (0, 0), mask)
    ring = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring)
    rd.rounded_rectangle([ox0, oy0, ox1 - 1, oy1 - 1], radius=r, outline=OUTLINE + (255,),
                         width=s(OUTLINE_W), corners=corners)
    out.alpha_composite(Image.composite(ring, Image.new("RGBA", (W, W), (0, 0, 0, 0)), mask))
    return out


def finish(img):
    return img.resize((T, T), Image.LANCZOS)


# ------------------------------------------------------------------ tiles
def make_top(kind, variant):
    """kind: 'left' | 'mid' | 'right'"""
    img = base_fn(100 + variant, wrap_y=False)
    cap_fn(img, 200 + variant, variant == 2)
    return finish(shape_and_outline(img, left=(kind == "left"), right=(kind == "right"), top=True, bottom=False,
                                    round_tl=(kind == "left"), round_tr=(kind == "right")))


def make_mid(kind, variant):
    img = base_fn(300 + variant, wrap_y=True)
    return finish(shape_and_outline(img, left=(kind == "left"), right=(kind == "right"), top=False, bottom=False))


def make_bottom(kind):
    img = base_fn(400, wrap_y=False)
    bottom_shade(img)
    return finish(shape_and_outline(img, left=(kind == "left"), right=(kind == "right"), top=False, bottom=True,
                                    round_bl=(kind == "left"), round_br=(kind == "right")))


def make_tiles():
    return {
        "top_left": (0, 0, make_top("left", 0)),
        "top_mid": (1, 0, make_top("mid", 0)),
        "top_mid_b": (2, 0, make_top("mid", 1)),
        "top_right": (3, 0, make_top("right", 0)),
        "mid_left": (0, 1, make_mid("left", 0)),
        "mid": (1, 1, make_mid("mid", 1)),
        "mid_b": (2, 1, make_mid("mid", 2)),
        "mid_right": (3, 1, make_mid("right", 3)),
        "bot_left": (0, 2, make_bottom("left")),
        "bot_mid": (1, 2, make_bottom("mid")),
        "bot_right": (2, 2, make_bottom("right")),
        "top_mid_c": (3, 2, make_top("mid", 2)),       # variante con detalle (florecitas, piedras, neon)
    }


def bleed(img):
    """Lienzo CELLxCELL con el tile centrado y bordes replicados (evita costuras)."""
    out = Image.new("RGBA", (CELL, CELL), (0, 0, 0, 0))
    out.paste(img, (PAD, PAD))
    out.paste(img.crop((0, 0, 1, T)).resize((PAD, T)), (0, PAD))
    out.paste(img.crop((T - 1, 0, T, T)).resize((PAD, T)), (CELL - PAD, PAD))
    out.paste(out.crop((0, PAD, CELL, PAD + 1)).resize((CELL, PAD)), (0, 0))
    out.paste(out.crop((0, CELL - PAD - 1, CELL, CELL - PAD)).resize((CELL, PAD)), (0, CELL - PAD))
    return out


def build_atlas(out_png):
    atlas = Image.new("RGBA", (COLS * CELL, ROWS * CELL), (0, 0, 0, 0))
    regions = {}
    for name, (col, row, img) in make_tiles().items():
        atlas.paste(bleed(img), (col * CELL, row * CELL))
        regions[name] = (col * CELL + PAD, row * CELL + PAD, T, T)
    os.makedirs(os.path.dirname(out_png), exist_ok=True)
    atlas.save(out_png)
    return regions


def write_tileset(regions, rel, out_tres):
    lines = [
        '[gd_resource type="TileSet" load_steps=2 format=2]',
        "",
        '[ext_resource path="%s" type="Texture" id=1]' % rel,
        "",
        "[resource]",
    ]
    for i, (name, (x, y, w, h)) in enumerate(regions.items()):
        lines.append('%d/name = "%s"' % (i, name))
        lines.append("%d/texture = ExtResource( 1 )" % i)
        lines.append("%d/tex_offset = Vector2( 0, 0 )" % i)
        lines.append("%d/modulate = Color( 1, 1, 1, 1 )" % i)
        lines.append("%d/region = Rect2( %d, %d, %d, %d )" % (i, x, y, w, h))
        lines.append("%d/tile_mode = 0" % i)
        lines.append("%d/shapes = [  ]" % i)
        lines.append("%d/z_index = 0" % i)
    os.makedirs(os.path.dirname(out_tres), exist_ok=True)
    with open(out_tres, "w") as f:
        f.write("\n".join(lines) + "\n")


# ------------------------------------------------------------------ estilos nuevos
def sand_cap(img, seed, detail=False):
    """Desierto: capa de arena con ondulaciones (dunas), rayitas de viento y piedritas."""
    d = ImageDraw.Draw(img, "RGBA")
    rnd = random.Random(seed)
    period = 12
    for i in range(6):
        a = int(90 * (1 - i / 6.0))
        d.rectangle([0, s(CAP + 2 + i), W, s(CAP + 3 + i)], fill=DIRT_DEEP + (a,))
    for x in range(-period, T + period, period):
        d.ellipse([s(x), s(CAP - 6), s(x + period), s(CAP + 3)], fill=GRASS_LIP + (255,))
    d.rectangle([0, 0, W, s(CAP - 3)], fill=GRASS_LIP + (255,))
    for x in range(-period, T + period, period):
        d.ellipse([s(x), s(CAP - 7), s(x + period), s(CAP + 1)], fill=GRASS + (255,))
    d.rectangle([0, 0, W, s(CAP - 4)], fill=GRASS + (255,))
    d.rectangle([0, 0, W, s(4)], fill=GRASS_LIGHT + (255,))
    d.rectangle([0, s(4), W, s(5.5)], fill=GRASS_LIGHT + (110,))
    # ondas de viento (se repiten por los lados para que no haya costura)
    for k in range(3):
        y0 = 5 + k * 3.2 + rnd.uniform(-0.4, 0.4)
        ph = rnd.uniform(0, 6.28)
        pts = [(s(x), s(y0 + 1.1 * math.sin(x / T * 6.28318 * 2 + ph))) for x in range(0, T + 1, 2)]
        d.line(pts, fill=GRASS_DARK + (150,), width=s(0.9))
    for _ in range(5):
        x, y = rnd.uniform(2, T - 2), rnd.uniform(4, 10)
        for (xx, yy) in wrap_positions(s(x), s(y), True, False):
            d.ellipse([xx - s(1.1), yy - s(0.8), xx + s(1.1), yy + s(0.8)], fill=PEBBLE_SHADE + (210,))
    if detail:        # una piedra mas grande y un cactus chiquito
        d.ellipse([s(10), s(6), s(17), s(11)], fill=PEBBLE_SHADE + (255,))
        d.ellipse([s(10.5), s(5), s(16.5), s(9.5)], fill=PEBBLE + (255,))
        d.rounded_rectangle([s(33), s(1), s(36.4), s(11)], radius=s(1.6), fill=(70, 150, 84, 255))
        d.rounded_rectangle([s(30.5), s(4), s(33.4), s(7.6)], radius=s(1.4), fill=(70, 150, 84, 255))
        d.rounded_rectangle([s(36), s(3), s(38.8), s(6.4)], radius=s(1.3), fill=(70, 150, 84, 255))


def ledge_cap(img, seed, detail=False):
    """Azotea: cornisa de metal/hormigon con franjas de peligro (o neon en la variante)."""
    d = ImageDraw.Draw(img, "RGBA")
    for i in range(6):
        a = int(100 * (1 - i / 6.0))
        d.rectangle([0, s(CAP + 2 + i), W, s(CAP + 3 + i)], fill=DIRT_DEEP + (a,))
    d.rectangle([0, 0, W, s(CAP)], fill=GRASS_LIP + (255,))
    d.rectangle([0, 0, W, s(CAP - 2)], fill=GRASS + (255,))
    d.rectangle([0, 0, W, s(3.2)], fill=GRASS_LIGHT + (255,))
    d.rectangle([0, s(3.2), W, s(4.4)], fill=(255, 255, 255, 60))
    if detail:        # tubo de neon rosa
        for w, a in ((5.0, 50), (3.2, 110)):
            d.rectangle([0, s(8.5 - w / 2), W, s(8.5 + w / 2)], fill=(255, 90, 190, a))
        d.rectangle([0, s(7.7), W, s(9.3)], fill=(255, 190, 240, 255))
    else:             # franjas amarillas y oscuras
        for x in range(-16, T + 16, 12):
            d.polygon([(s(x), s(CAP - 2)), (s(x + 6), s(CAP - 2)), (s(x + 12), s(CAP - 8)), (s(x + 6), s(CAP - 8))],
                      fill=(246, 196, 48, 255))
            d.polygon([(s(x + 6), s(CAP - 2)), (s(x + 12), s(CAP - 2)), (s(x + 18), s(CAP - 8)), (s(x + 12), s(CAP - 8))],
                      fill=(40, 42, 56, 255))
        d.rectangle([0, s(CAP - 9), W, s(CAP - 8)], fill=(0, 0, 0, 60))
    rnd = random.Random(seed)
    for _ in range(4):                                       # remaches
        x = rnd.uniform(3, T - 3)
        for (xx, yy) in wrap_positions(s(x), s(6.3), True, False):
            d.ellipse([xx - s(0.9), yy - s(0.9), xx + s(0.9), yy + s(0.9)], fill=GRASS_DARK + (255,))


def brick_base(seed, wrap_y):
    """Ladrillo / hormigon oscuro, sin costuras."""
    img = Image.new("RGB", (W, W), DIRT)
    d = ImageDraw.Draw(img, "RGBA")
    rnd = random.Random(seed)
    bh, bw = T / 3.0, T / 2.0
    for row in range(3):
        off = (bw / 2) if row % 2 else 0
        for col in range(-1, 3):
            x0, y0 = col * bw + off, row * bh
            tone = rnd.choice((DIRT_LIGHT, DIRT, DIRT_DARK))
            d.rectangle([s(x0 + 1), s(y0 + 1), s(x0 + bw - 1), s(y0 + bh - 1)], fill=tone + (255,))
            d.rectangle([s(x0 + 1), s(y0 + 1), s(x0 + bw - 1), s(y0 + 2.4)], fill=(255, 255, 255, 26))
            d.rectangle([s(x0 + 1), s(y0 + bh - 2.4), s(x0 + bw - 1), s(y0 + bh - 1)], fill=(0, 0, 20, 46))
    for row in range(3):                                      # juntas
        d.line([(0, s(row * bh)), (W, s(row * bh))], fill=DIRT_DEEP + (255,), width=s(1.2))
        off = (bw / 2) if row % 2 else 0
        for col in range(-1, 3):
            x = col * bw + off
            d.line([(s(x), s(row * bh)), (s(x), s((row + 1) * bh))], fill=DIRT_DEEP + (255,), width=s(1.2))
    for _ in range(6):                                        # manchas
        x, y, r = rnd.uniform(0, T), rnd.uniform(2, T - 2), rnd.uniform(1.0, 2.2)
        for (xx, yy) in wrap_positions(s(x), s(y), True, wrap_y):
            d.ellipse([xx - s(r), yy - s(r), xx + s(r), yy + s(r)], fill=(0, 0, 20, 40))
    return img


STYLES = {
    "pradera": dict(
        png="assets/sprites/stage/tileset_atlas.png", tres="resources/stage_tileset.tres",
        cap="grass", base="dirt"),
    "desierto": dict(
        png="assets/sprites/stage/tileset_desierto.png", tres="resources/stage_tileset_desierto.tres",
        cap="sand", base="dirt",
        pal=dict(GRASS_LIGHT=(255, 236, 178), GRASS=(244, 204, 128), GRASS_DARK=(206, 150, 84), GRASS_LIP=(170, 112, 66),
                 DIRT=(214, 150, 86), DIRT_LIGHT=(236, 182, 114), DIRT_DARK=(178, 114, 66), DIRT_DEEP=(124, 72, 48),
                 PEBBLE=(250, 226, 176), PEBBLE_SHADE=(160, 104, 66), OUTLINE=(86, 46, 36), GRASS_OUTLINE=(86, 46, 36))),
    "azotea": dict(
        png="assets/sprites/stage/tileset_azotea.png", tres="resources/stage_tileset_azotea.tres",
        cap="ledge", base="brick",
        pal=dict(GRASS_LIGHT=(206, 214, 232), GRASS=(150, 160, 186), GRASS_DARK=(92, 100, 128), GRASS_LIP=(58, 64, 88),
                 DIRT=(92, 98, 128), DIRT_LIGHT=(112, 120, 152), DIRT_DARK=(72, 78, 104), DIRT_DEEP=(36, 40, 62),
                 PEBBLE=(150, 160, 186), PEBBLE_SHADE=(60, 66, 90), OUTLINE=(22, 24, 40), GRASS_OUTLINE=(22, 24, 40))),
}
_DEFAULT_PAL = {k: globals()[k] for k in ("GRASS_LIGHT", "GRASS", "GRASS_DARK", "GRASS_LIP", "DIRT", "DIRT_LIGHT",
                                            "DIRT_DARK", "DIRT_DEEP", "PEBBLE", "PEBBLE_SHADE", "OUTLINE", "GRASS_OUTLINE")}
CAPS = {"grass": grass_cap, "sand": sand_cap, "ledge": ledge_cap}
BASES = {"dirt": dirt_base, "brick": brick_base}
cap_fn = grass_cap
base_fn = dirt_base


def use_style(name):
    global cap_fn, base_fn
    st = STYLES[name]
    globals().update(_DEFAULT_PAL)
    globals().update(st.get("pal", {}))
    cap_fn, base_fn = CAPS[st["cap"]], BASES[st["base"]]


def main(only=None):
    for name, st in STYLES.items():
        if only and name not in only:
            continue
        use_style(name)
        regions = build_atlas(os.path.join(PROJ, st["png"]))
        write_tileset(regions, "res://" + st["png"], os.path.join(PROJ, st["tres"]))
        print("Tileset %-8s -> %s / %s  (%d tiles)" % (name, st["png"], st["tres"], len(regions)))


if __name__ == "__main__":
    import sys
    main(sys.argv[1:] or None)
