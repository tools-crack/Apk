extends SceneTree
# Revisa que NINGÚN texto se desborde de su caja ni se monte sobre otro, en todas
# las pantallas (menú, controles, selección, escenarios y HUD de la arena), y que
# Keybinds guarde / intercambie / restaure bien las teclas.
#   godot --path . -s tools/test_ui_layout.gd

var fails := 0


func check(name, ok, extra = "") -> void:
	if ok:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FALLO]", name, " ", extra)


func wait(t: float):
	yield(create_timer(t), "timeout")


# Tamaño que ocupa el texto de una Label dentro de su ancho actual.
func text_size(l: Label) -> Vector2:
	var f: Font = l.get_font("font")
	if l.autowrap:
		return f.get_wordwrap_string_size(l.text, l.rect_size.x)
	var w := 0.0
	var lines := l.text.split("\n")
	for ln in lines:
		w = max(w, f.get_string_size(ln).x)
	return Vector2(w, f.get_height() * lines.size())


func visible_in_tree(n: Node) -> bool:
	while n != null and n != root:
		if n is CanvasItem and not n.visible:
			return false
		n = n.get_parent()
	return true


func labels_of(n: Node, out := []) -> Array:
	if n is Label and visible_in_tree(n):
		out.append(n)
	for c in n.get_children():
		labels_of(c, out)
	return out


# Rectángulo REAL (en pantalla) que ocupa el texto de la etiqueta.
func text_rect(l: Label) -> Rect2:
	var sz := text_size(l)
	sz.x = min(sz.x, l.rect_size.x)
	sz.y = min(sz.y, l.rect_size.y)
	var x := 0.0
	match l.align:
		Label.ALIGN_CENTER: x = (l.rect_size.x - sz.x) * 0.5
		Label.ALIGN_RIGHT: x = l.rect_size.x - sz.x
	var y := 0.0
	match l.valign:
		Label.VALIGN_CENTER: y = (l.rect_size.y - sz.y) * 0.5
		Label.VALIGN_BOTTOM: y = l.rect_size.y - sz.y
	return Rect2(l.get_global_position() + Vector2(x, y), sz)


func audit(screen_name: String, scene: Node) -> void:
	var labs := labels_of(scene)
	var overflow := []
	for l in labs:
		if l.text == "":
			continue
		var need := text_size(l)
		if need.x > l.rect_size.x + 1.0 or need.y > l.rect_size.y + 1.0:
			if not (l.clip_text and need.x <= l.rect_size.x + 1.0 and l.autowrap == false and false):
				overflow.append("%s «%s» necesita %s y tiene %s" % [l.name, l.text.left(30), need, l.rect_size])
	check(screen_name + ": ningún texto se desborda de su caja", overflow.empty(), str(overflow))
	var overlaps := []
	for i in range(labs.size()):
		for j in range(i + 1, labs.size()):
			var a: Label = labs[i]
			var b: Label = labs[j]
			if a.text == "" or b.text == "" or a.is_a_parent_of(b) or b.is_a_parent_of(a):
				continue
			var ra := text_rect(a)
			var rb := text_rect(b)
			if ra.size.x > 0 and rb.size.x > 0 and ra.intersects(rb):
				overlaps.append("%s «%s» x %s «%s»" % [a.name, a.text.left(18), b.name, b.text.left(18)])
	check(screen_name + ": ningún texto se monta sobre otro", overlaps.empty(), str(overlaps))
	var offscreen := []
	for l in labs:
		var r := Rect2(l.get_global_position(), l.rect_size)
		if l.text != "" and not Rect2(Vector2.ZERO, Vector2(1280, 720)).encloses(r.grow(-1)):
			offscreen.append(l.name)
	check(screen_name + ": todo dentro de la pantalla", offscreen.empty(), str(offscreen))


func _init() -> void:
	call_deferred("_run")


func _run():
	var game = root.get_node("Game")
	var kb = root.get_node("Keybinds")

	print("== Keybinds")
	var d1: int = kb.get_scancode("p1_left")
	var d2: int = kb.get_scancode("p1_right")
	check("teclas de fábrica P1 A/D", d1 == KEY_A and d2 == KEY_D)
	var swapped: String = kb.set_key("p1_left", KEY_Q)
	check("cambiar tecla libre", kb.get_scancode("p1_left") == KEY_Q and swapped == "")
	swapped = kb.set_key("p1_right", KEY_Q)
	check("choque: se intercambian", swapped == "p1_left" and kb.get_scancode("p1_right") == KEY_Q and kb.get_scancode("p1_left") == KEY_D)
	check("Esc reservada", kb.set_key("p1_jump", KEY_ESCAPE) == "" and kb.get_scancode("p1_jump") == KEY_W)
	var cfg := ConfigFile.new()
	check("se guardó el archivo", cfg.load(kb.SAVE_PATH) == OK and int(cfg.get_value("teclas", "p1_right")) == KEY_Q)
	kb.reset(0)
	check("restaurar todo", kb.get_scancode("p1_left") == KEY_A and kb.get_scancode("p1_right") == KEY_D \
		and kb.get_scancode("p2_attack") == KEY_K)
	var all_ok := true
	for act in kb.all_actions():
		all_ok = all_ok and InputMap.get_action_list(act).size() == 1
	check("cada acción queda con exactamente 1 tecla", all_ok)

	print("== Pantallas")
	for path in ["res://scenes/ui/MainMenu.tscn", "res://scenes/ui/Controls.tscn", "res://scenes/ui/StageSelect.tscn"]:
		var s = load(path).instance()
		root.add_child(s)
		yield(wait(0.6), "completed")
		audit(path.get_file(), s)
		s.queue_free()
		yield(wait(0.1), "completed")

	# Selección de personajes: peor caso = cada personaje en el panel (descripción más larga)
	var cs = load("res://scenes/ui/CharSelect.tscn").instance()
	root.add_child(cs)
	yield(wait(0.3), "completed")
	for i in range(game.ORDER.size()):
		cs.pick1.set_index(i)
		cs.pick2.set_index((i + 3) % game.ORDER.size())
		yield(wait(0.05), "completed")
		audit("CharSelect (%s)" % game.ORDER[i], cs)
	cs.pick1._set_ready(true)
	yield(wait(0.05), "completed")
	audit("CharSelect (listo)", cs)
	cs.queue_free()
	yield(wait(0.1), "completed")

	# Arena + HUD con cada escenario
	for si in range(game.STAGES.size()):
		game.stage_index = si
		game.selected = ["gaviotero", "topo"]
		var arena = load("res://scenes/Arena.tscn").instance()
		root.add_child(arena)
		yield(wait(0.4), "completed")
		arena.fighters[0].percent = 999.0
		arena.fighters[1].percent = 188.0
		yield(wait(0.1), "completed")
		check("arena %s: carga el escenario" % game.STAGES[si]["id"], arena.has_node("Stage/Ground") and arena.has_node("Stage/Background"))
		audit("Arena " + game.STAGES[si]["id"], arena.get_node("HUD"))
		arena.queue_free()
		yield(wait(0.1), "completed")
	game.stage_index = 0

	print("")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
