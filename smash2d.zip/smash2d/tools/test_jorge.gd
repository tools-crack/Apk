extends SceneTree
# ============================================================================
#  test_jorge.gd — comprueba el especial de Jorge (Caña de pescar)
# ----------------------------------------------------------------------------
#      godot --path . -s tools/test_jorge.gd
#  Lanza el anzuelo (con aviso), engancha, recoge al rival delante de Jorge y lo
#  lanza al OTRO lado; se esquiva saltando o quedando fuera de alcance; si
#  golpean a Jorge, el especial NO se anula (solo pierde el control un rato).
# ============================================================================
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func reset(f, pos):
	f.position = pos
	f.velocity = Vector2.ZERO
	f.percent = 0.0
	f.state = f.State.NORMAL
	f.invulnerable = false
	f.invuln_timer = 0.0
	f.special_timer = 0.0
	f.frozen = false
	f.wrapped_time = 0.0
	f.collision_layer = 2
	f.sprite.visible = true


func press(action, sec = 0.06):
	Input.action_press(action)
	yield(create_timer(sec), "timeout")
	Input.action_release(action)


func find_all(node, script_name, out := []):
	for c in node.get_children():
		if c.get_script() != null and c.get_script().resource_path.ends_with(script_name):
			out.append(c)
		find_all(c, script_name, out)
	return out


func _initialize():
	_run()


func _run():
	var game = root.get_node("Game")
	print("== Jorge: Caña de pescar")
	game.selected = ["jorge", "gaviotero"]
	game.practice = false
	var arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(3.6), "completed")
	var jorge = arena.fighters[0]
	var rival = arena.fighters[1]
	check("Jorge: ficha cargada", jorge.display_name == "Jorge" and jorge.stats.hook_range == 420.0)
	check("Jorge: tiene animaciones special y throw", jorge.sprite.frames.has_animation("special") and jorge.sprite.frames.has_animation("throw"))

	# ---- engancha y lanza al otro lado (Jorge mira a la derecha -> rival sale hacia la izquierda)
	reset(jorge, Vector2(400, 440))
	jorge.facing = 1
	reset(rival, Vector2(700, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.2), "completed")
	check("Jorge: mientras lanza la caña (aviso) aún no hay anzuelo ni daño", find_all(arena, "Hook.gd").size() == 0 and rival.percent == 0.0)
	var guard = 0
	while rival.wrapped_time <= 0.0 and guard < 100:
		yield(wait(0.02), "completed")
		guard += 1
	check("Jorge: el anzuelo engancha al rival", rival.wrapped_time > 0.0 and rival.frozen, "espera=%.2fs" % (guard * 0.02))
	check("Jorge: el enganche hace el 25 % del daño", abs(rival.percent - 3.0) < 0.01, "percent=%s" % rival.percent)
	guard = 0
	var hook = find_all(arena, "Hook.gd")[0]
	while hook.phase != hook.Phase.HELD and guard < 100:
		yield(wait(0.02), "completed")
		guard += 1
	check("Jorge: recoge al rival delante de él", abs(rival.position.x - 456.0) < 4.0 and abs(rival.position.y - 440.0) < 4.0, "pos=%s" % rival.position)
	guard = 0
	while rival.percent < 4.0 and guard < 100:
		yield(wait(0.02), "completed")
		guard += 1
	check("Jorge: el lanzamiento completa el daño total", abs(rival.percent - 12.0) < 0.01, "percent=%s" % rival.percent)
	check("Jorge: lo lanza al OTRO lado (hacia la izquierda) y hacia arriba", rival.velocity.x < 0.0 and rival.velocity.y < 0.0, "v=%s" % rival.velocity)
	check("Jorge: el rival ya no está inmovilizado", not rival.frozen and rival.wrapped_time <= 0.0)
	yield(wait(0.8), "completed")
	check("Jorge: vuelve a NORMAL y se borra el anzuelo", jorge.state == jorge.State.NORMAL and find_all(arena, "Hook.gd").size() == 0)

	# ---- mirando a la izquierda: sale hacia la derecha
	print("== Jorge: mirando a la izquierda")
	reset(jorge, Vector2(800, 440))
	jorge.facing = -1
	reset(rival, Vector2(500, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	guard = 0
	while rival.percent < 4.0 and guard < 200:
		yield(wait(0.02), "completed")
		guard += 1
	check("Jorge: mirando a la izquierda lanza al rival hacia la derecha", rival.percent > 3.5 and rival.velocity.x > 0.0, "v=%s percent=%s" % [rival.velocity, rival.percent])
	yield(wait(1.0), "completed")

	# ---- esquivar
	print("== Jorge: se esquiva")
	reset(jorge, Vector2(400, 440))
	jorge.facing = 1
	reset(rival, Vector2(960, 440))                 # más lejos que hook_range (420)
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.5), "completed")
	check("Jorge: el anzuelo vuela pero no llega (alcance limitado)", find_all(arena, "Hook.gd").size() == 1 and rival.percent == 0.0)
	yield(wait(1.5), "completed")
	check("Jorge: si falla, el anzuelo vuelve y Jorge recupera el control", find_all(arena, "Hook.gd").size() == 0 and jorge.state == jorge.State.NORMAL and rival.percent == 0.0)
	reset(jorge, Vector2(400, 440))
	reset(rival, Vector2(700, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.25), "completed")
	rival.position.y = 320.0                        # salta: el anzuelo pasa por debajo
	rival.frozen = true
	yield(wait(0.9), "completed")
	rival.frozen = false
	check("Jorge: saltando por encima del anzuelo no lo engancha", rival.percent == 0.0 and rival.wrapped_time <= 0.0, "percent=%s" % rival.percent)
	yield(wait(1.0), "completed")

	# ---- el anzuelo engancha TAMBIÉN al volver (fase RETURN)
	print("== Jorge: engancha al volver")
	reset(jorge, Vector2(400, 440))
	jorge.facing = 1
	reset(rival, Vector2(700, 440))
	rival.invulnerable = true                       # el vuelo de ida lo pasa de largo
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	guard = 0
	while guard < 300:
		var hs = find_all(arena, "Hook.gd")
		if hs.size() > 0 and hs[0].phase == hs[0].Phase.RETURN:
			break
		yield(wait(0.01), "completed")
		guard += 1
	rival.invulnerable = false                      # ahora sí: el anzuelo vuelve y pasa por él
	guard = 0
	while rival.wrapped_time <= 0.0 and guard < 100:
		yield(wait(0.01), "completed")
		guard += 1
	check("Jorge: el anzuelo que vuelve engancha al rival", rival.wrapped_time > 0.0 or rival.percent > 0.0, "wrapped=%s" % rival.wrapped_time)
	guard = 0
	while (jorge.state == jorge.State.SPECIAL or find_all(arena, "Hook.gd").size() > 0) and guard < 300:
		yield(wait(0.02), "completed")
		guard += 1
	check("Jorge: tras engancharlo al volver, lo lanza", rival.percent > 8.0, "percent=%s" % rival.percent)
	yield(wait(1.0), "completed")

	# ---- golpearlo durante el especial NO lo cancela
	print("== Jorge: golpeado durante el especial sigue")
	reset(jorge, Vector2(400, 440))
	jorge.facing = 1
	reset(rival, Vector2(700, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	guard = 0
	while rival.wrapped_time <= 0.0 and guard < 100:
		yield(wait(0.02), "completed")
		guard += 1
	jorge.take_hit(1.0, Vector2(100, -100), rival)   # golpean a Jorge mientras recoge
	yield(wait(0.1), "completed")
	check("Jorge: golpeado sigue en su especial (no se anula)", jorge.state == jorge.State.SPECIAL and jorge.special_stun > 0.0, "state=%s stun=%s" % [jorge.state, jorge.special_stun])
	check("Jorge: el anzuelo sigue en pie y el rival sigue enganchado", find_all(arena, "Hook.gd").size() == 1 and rival.wrapped_time > 0.0)
	guard = 0
	while rival.percent < 8.0 and guard < 300:
		yield(wait(0.02), "completed")
		guard += 1
	check("Jorge: al pasar el golpe, termina el lanzamiento", rival.percent > 8.0, "percent=%s" % rival.percent)

	print("")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
