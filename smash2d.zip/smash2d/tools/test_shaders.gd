extends SceneTree
# Shaders: que carguen, que el luchador destelle al recibir un golpe, que se disuelva al reaparecer,
# y que los escenarios tengan sus materiales.   godot --path . -s tools/test_shaders.gd
# OJO: el Godot headless no dibuja ni compila shaders (driver "dummy"): aquí se prueba la LÓGICA,
# que los archivos carguen y que los materiales estén puestos. Un error DENTRO del código GLSL
# solo aparece al abrir el proyecto con el editor o al ejecutarlo con ventana: míralo en la
# pestaña Salida del editor la primera vez.

var fails := 0


func check(name, ok, extra = "") -> void:
	if ok:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FALLO]", name, " ", extra)


func wait(t: float):
	yield(create_timer(t), "timeout")


func _init() -> void:
	call_deferred("_run")


func _run():
	var game = root.get_node("Game")
	var Config = root.get_node("Config")

	print("== Archivos de shader")
	for path in ["res://assets/shaders/fighter_fx.shader", "res://assets/shaders/heat_haze.shader",
			"res://assets/shaders/neon_scanlines.shader"]:
		var sh = load(path)
		check("carga " + path.get_file(), sh is Shader and sh.resource_path == path)

	print("== Luchador: destello y disolución")
	game.selected = ["gaviotero", "topo"]
	var arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(0.4), "completed")
	var f = arena.fighters[0]
	f.input_enabled = false
	check("sin material al empezar", f._fx_mat == null)
	f.take_hit(10.0, Vector2(200, -100), arena.fighters[1])
	check("golpe activa el destello", f._fx_flash == 1.0)
	yield(wait(0.05), "completed")
	check("el destello se apaga con el tiempo", f._fx_flash < 1.0 and f._fx_flash > 0.0, str(f._fx_flash))
	check("el luchador tiene material de efectos", f.sprite.material is ShaderMaterial and f.sprite.material.shader == load("res://assets/shaders/fighter_fx.shader"))
	check("el material del luchador se creó una vez", f._fx_mat != null and f.sprite.material == f._fx_mat)
	yield(wait(Config.RESPAWN_INVULNERABLE_TIME + 0.1), "completed")
	f._die()
	f.percent = 0.0
	yield(wait(Config.RESPAWN_DELAY + 0.1), "completed")
	f._respawn()
	check("reaparecer empieza disolviéndose (dissolve=1)", f._fx_dissolve == 1.0)
	yield(wait(0.1), "completed")
	check("la disolución baja con el tiempo", f._fx_dissolve < 1.0 and f._fx_dissolve > 0.0, str(f._fx_dissolve))
	yield(wait(0.6), "completed")
	check("al terminar la aparición ya es visible del todo", f._fx_dissolve == 0.0)
	arena.queue_free()
	yield(wait(0.1), "completed")

	print("== Escenarios")
	for si in range(game.STAGES.size()):
		game.stage_index = si
		var a2 = load("res://scenes/Arena.tscn").instance()
		root.add_child(a2)
		yield(wait(0.3), "completed")
		var id: String = game.STAGES[si]["id"]
		if id == "desierto":
			var bg = a2.get_node("Stage/Background")
			check("desierto: el fondo tiembla (heat_haze)", bg.material is ShaderMaterial \
				and bg.material.shader.resource_path.get_file() == "heat_haze.shader")
		elif id == "azotea":
			var sc = a2.get_node("Stage/Retro/Scan")
			check("azotea: overlay de scanlines", sc.material is ShaderMaterial \
				and sc.material.shader.resource_path.get_file() == "neon_scanlines.shader")
		else:
			check("pradera: sin shaders de escenario", not a2.get_node("Stage").has_node("Retro"))
		a2.queue_free()
		yield(wait(0.1), "completed")
	game.stage_index = 0

	print("")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
