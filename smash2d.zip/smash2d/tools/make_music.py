#!/usr/bin/env python3
"""Compone la MUSICA del juego (canciones originales), la guarda como MIDI y la convierte a OGG.

    python3 tools/make_music.py            # todas las canciones
    python3 tools/make_music.py battle     # solo las que tengan "battle" en el nombre

Que hace, paso a paso:
  1. Cada cancion se COMPONE en codigo (acordes por compas + melodias escritas como texto + capas de
     acompanamiento: guitarra, bajo, cuerdas, bateria...) y se escribe como MIDI estandar:
        assets/music/midi/<nombre>.mid     <- ábrelo en cualquier DAW / MuseScore / editor MIDI
  2. El MIDI se interpreta con el sintetizador FluidSynth (libfluidsynth) y un SoundFont General MIDI.
  3. El audio se normaliza, la cola de reverberacion se pliega al principio para que el bucle sea
     continuo, y ffmpeg lo convierte a:
        assets/music/<nombre>.ogg          <- lo que usa el juego

Requisitos: numpy, scipy, ffmpeg, libfluidsynth.so.3 y un SoundFont (.sf2) General MIDI.
Cambiar una cancion = editar su funcion song_*() (acordes, melodias, instrumentos) y volver a correr.
Las melodias se escriben como texto, ver parse_melody(): "5:1 3:0.5 r:1" = grado 5 durante 1 pulso,
grado 3 durante medio pulso, silencio de 1 pulso. 8 = octava arriba, "b7" = grado 7 bemol, "'" = octava mas.
"""
import ctypes
import os
import random
import re
import struct
import subprocess
import sys
import tempfile
import zlib

import numpy as np
from scipy.io import wavfile

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, ".."))
OUT = os.path.join(PROJ, "assets", "music")
MIDI_DIR = os.path.join(OUT, "midi")
SR = 44100
PPQ = 480
SOUNDFONTS = ["/usr/share/sounds/sf2/TimGM6mb.sf2", "/usr/share/sounds/sf2/default-GM.sf2",
              "/usr/share/soundfonts/default.sf2"]

# ----------------------------------------------------------------- teoria
NOTE_PC = {"C": 0, "C#": 1, "Db": 1, "D": 2, "D#": 3, "Eb": 3, "E": 4, "F": 5, "F#": 6, "Gb": 6, "G": 7,
           "G#": 8, "Ab": 8, "A": 9, "A#": 10, "Bb": 10, "B": 11}
SCALES = {
    "major": [0, 2, 4, 5, 7, 9, 11],
    "minor": [0, 2, 3, 5, 7, 8, 10],
    "dorian": [0, 2, 3, 5, 7, 9, 10],
    "phryg_dom": [0, 1, 4, 5, 7, 8, 10],       # frigio dominante (sabor "arabe")
}
QUAL = {"M": [0, 4, 7], "m": [0, 3, 7], "M7": [0, 4, 7, 11], "m7": [0, 3, 7, 10], "7": [0, 4, 7, 10],
        "dim": [0, 3, 6], "sus4": [0, 5, 7], "5": [0, 7], "add9": [0, 4, 7, 14]}


class Key:
    """Tonalidad: tonica + escala. pitch(grado, octava, alteracion) -> nota MIDI. Grado 1 = tonica."""

    def __init__(self, tonic, scale, octave=4):
        self.base = 12 * (octave + 1) + NOTE_PC[tonic]
        self.scale = SCALES[scale]

    def pitch(self, degree, octave=0, acc=0):
        i = degree - 1
        return self.base + 12 * (i // 7 + octave) + self.scale[i % 7] + acc


def parse_melody(text):
    """'b7:1 5:0.5 r:1 3,:2' -> [(grado, alteracion, octava_extra, duracion) | (None,0,0,dur)]."""
    out = []
    for tok in text.split():
        head, _, dur = tok.partition(":")
        dur = float(dur) if dur else 1.0
        if head == "r":
            out.append((None, 0, 0, dur))
            continue
        m = re.match(r"^([b#]?)(-?\d+)([',]*)$", head)
        if not m:
            raise ValueError("token de melodia invalido: " + tok)
        acc = {"b": -1, "#": 1, "": 0}[m.group(1)]
        octv = m.group(3).count("'") - m.group(3).count(",")
        out.append((int(m.group(2)), acc, octv, dur))
    return out


# ------------------------------------------------------------------ cancion
class Song:
    def __init__(self, name, bpm, key, loop=True, tail=3.0):
        self.name, self.bpm, self.key, self.loop, self.tail = name, bpm, key, loop, tail
        self.notes = []            # (canal, tiempo en pulsos, duracion, nota, velocidad)
        self.chans = {}            # canal -> (programa, volumen, pan)
        self.bars = 0
        self.rnd = random.Random(zlib.crc32(name.encode()))
        self.bar_chord = {}        # compas -> (pitch classes del acorde, nombre)
        self.melody_log = []       # para la revision armonica

    def chan(self, ch, program, volume=100, pan=64):
        self.chans[ch] = (program, volume, pan)

    def note(self, ch, bar, beat, dur, pitch, vel, human=True):
        t = bar * 4 + beat
        if human and ch != 9:
            t += self.rnd.uniform(-0.012, 0.012)
            vel += self.rnd.randint(-5, 5)
        t = max(t, 0.0)
        self.notes.append((ch, t, max(dur, 0.05), int(pitch), int(max(1, min(127, vel)))))

    # --- acordes
    def chord(self, spec):
        """spec = (grado, calidad[, alteracion]) -> (fundamental en octava 0, [notas])."""
        deg, q = spec[0], spec[1]
        acc = spec[2] if len(spec) > 2 else 0
        root = self.key.pitch(deg, 0, acc)
        return root, [root + i for i in QUAL[q]]

    def set_chord(self, bar, spec):
        root, tones = self.chord(spec)
        self.bar_chord[bar] = {t % 12 for t in tones}

    def tones(self, spec, octave):
        root, tones = self.chord(spec)
        return [t + 12 * octave for t in tones]

    # --- capas de acompanamiento
    def pad(self, ch, bar, spec, octave, vel, beats=4.0, double_root=False):
        ts = self.tones(spec, octave)
        if double_root:
            ts = ts + [ts[0] + 12]
        for t in ts:
            self.note(ch, bar, 0, beats * 0.98, t, vel)

    def arp(self, ch, bar, spec, pattern, octave, vel, step=0.5, dur=None, accent=None):
        ts = self.tones(spec, octave)
        ext = ts + [t + 12 for t in ts] + [t + 24 for t in ts]
        for i, idx in enumerate(pattern):
            if idx is None:
                continue
            v = vel + (accent if accent and i % 2 == 0 else 0)
            self.note(ch, bar, i * step, dur if dur else step * 1.6, ext[idx % len(ext)], v)

    def comp(self, ch, bar, spec, hits, octave, vel, voicing=None):
        """Acordes ritmicos: hits = [(pulso, duracion[, vel_extra])]."""
        ts = self.tones(spec, octave)
        if voicing:
            ts = [ts[i % len(ts)] + 12 * (i // len(ts)) for i in voicing]
        for h in hits:
            for t in ts:
                self.note(ch, bar, h[0], h[1], t, vel + (h[2] if len(h) > 2 else 0))

    def bass(self, ch, bar, spec, pattern, vel, octave=-2):
        deg = spec[0]
        acc = spec[2] if len(spec) > 2 else 0
        root = self.key.pitch(deg, octave, acc)
        while root < 28:
            root += 12
        while root > 47:
            root -= 12
        q = spec[1]
        fifth = 6 if q == "dim" else 7
        third = 3 if q in ("m", "m7", "dim") else 4
        names = {"r": 0, "o": 12, "5": fifth, "3": third, "b7": 10, "7": 11, "4": 5, "2": 2, "b2": 1,
                 "6": 9, "p5": 7, "o5": 19}
        for (beat, dur, iv, *rest) in pattern:
            v = vel + (rest[0] if rest else 0)
            self.note(ch, bar, beat, dur, root + names[iv], v)

    def drums(self, bar, style, level=1.0, crash=False, fill=False, bars_in_phrase=None):
        pat = DRUMS[style]
        for note, steps in pat.items():
            for i, c in enumerate(steps):
                if c == ".":
                    continue
                if fill and i >= 8 and note in (36, 38, 42, 46, 37, 39, 54, 62, 47):
                    continue
                v = {"X": 112, "x": 92, "g": 54}[c] * level
                self.note(9, bar, i * 0.25, 0.2, note, v + self.rnd.randint(-4, 4), human=False)
        if fill:
            seq = [38, 38, 50, 50, 47, 47, 45, 43]
            for k, n in enumerate(seq):
                self.note(9, bar, 2.0 + k * 0.25, 0.2, n, (70 + k * 7) * level, human=False)
        if crash:
            self.note(9, bar, 0, 1.5, 49, 105 * level, human=False)

    # --- melodia
    def melody(self, ch, bar, text, octave=0, vel=90, legato=0.94, below=0):
        """Coloca una melodia escrita como texto. below=-2 -> la misma melodia una tercera mas grave."""
        beat = 0.0
        for deg, acc, octv, dur in parse_melody(text):
            if deg is not None:
                d = deg + below
                p = self.key.pitch(d, octave + octv, acc)
                v = vel + (6 if beat % 1.0 == 0 else -3)
                self.note(ch, bar, beat, dur * legato, p, v)
                if below == 0:
                    self.melody_log.append((bar, beat, p, text))
            beat += dur
        if abs(beat - 4.0) > 1e-6:
            raise ValueError("compas %d de %s suma %.2f pulsos: %s" % (bar, self.name, beat, text))

    def check_harmony(self):
        """Avisa de las notas de melodia en pulso 1 o 3 que no pertenecen al acorde (para revisar)."""
        bad = []
        for bar, beat, pitch, text in self.melody_log:
            if beat in (0.0, 2.0) and bar in self.bar_chord and pitch % 12 not in self.bar_chord[bar]:
                bad.append((bar, beat, pitch % 12, text))
        return bad


# ------------------------------------------------------------------ bateria
# Cada patron son 16 pasos (semicorcheas): X acento, x normal, g nota fantasma.
DRUMS = {
    "brush": {36: "x.......x.x.....", 38: "....g.......g...", 42: "x.x.x.x.x.x.x.x."},
    "brush_snare": {36: "x.......x.x.....", 38: "....x.......x..g", 42: "x.x.x.x.x.x.x.x.", 46: "..............g."},
    "funk": {36: "X..x..x...x.x...", 38: "....X..g.g..X..g", 42: "xgxgxgxgxgxgxgxg", 46: "..............x."},
    "rock": {36: "X..x..x.X..x.x..", 38: "....X.......X..g", 42: "x.x.x.x.x.x.x.x.", 51: "x...x...x...x..."},
    "rock_half": {36: "X.......X.x.....", 38: "........X.......", 42: "x.x.x.x.x.x.x.x."},
    "desert": {36: "X.......x.x.....", 37: "..x...x.....x.x.", 39: "....x.......x...",
               54: "x.x.x.x.x.x.x.x.", 47: "...........g..g.", 62: "..g.g.g...g.g.g."},
    "desert_build": {36: "X...x...X...x...", 47: "....x.x.....x.x.", 45: "........x.x.x.xx", 54: "xxxxxxxxxxxxxxxx"},
    "synth": {36: "X...X...X...X...", 39: "....X.......X...", 42: ".x.x.x.x.x.x.x.x", 46: "..x...x...x...x.",
              38: "...............g"},
    "synth_light": {36: "X...X...X...X...", 42: ".x.x.x.x.x.x.x.x"},
    "toms": {36: "X.......X.......", 45: "....x.......x...", 47: "........x.x.....", 50: "............x.xx"},
}


# ------------------------------------------------------------------ MIDI
def _vlq(n):
    out = [n & 0x7F]
    n >>= 7
    while n:
        out.append((n & 0x7F) | 0x80)
        n >>= 7
    return bytes(reversed(out))


def write_midi(song, path):
    end_beat = song.bars * 4
    tracks = []
    tempo = int(60_000_000 / song.bpm)
    meta = bytearray()
    name = song.name.encode()
    meta += b"\x00\xff\x03" + bytes([len(name)]) + name
    meta += b"\x00\xff\x51\x03" + tempo.to_bytes(3, "big")
    meta += b"\x00\xff\x58\x04\x04\x02\x18\x08"
    meta += _vlq(int(end_beat * PPQ)) + b"\xff\x2f\x00"
    tracks.append(bytes(meta))
    for ch in sorted({n[0] for n in song.notes} | set(song.chans)):
        prog, vol, pan = song.chans.get(ch, (0, 100, 64))
        ev = []                                       # (tick, orden, bytes)
        ev.append((0, 0, bytes([0xB0 | ch, 7, vol])))
        ev.append((0, 0, bytes([0xB0 | ch, 10, pan])))
        ev.append((0, 0, bytes([0xB0 | ch, 91, 52])))       # reverb
        ev.append((0, 0, bytes([0xC0 | ch, prog])))
        for (c, t, d, p, v) in song.notes:
            if c != ch or t >= end_beat - 1e-6:
                continue
            d = min(d, end_beat - t)
            t0 = int(round(t * PPQ))
            t1 = max(int(round((t + d) * PPQ)), t0 + 1)
            ev.append((t0, 2, bytes([0x90 | ch, p, v])))
            ev.append((t1, 1, bytes([0x80 | ch, p, 0])))
        ev.sort(key=lambda e: (e[0], e[1]))
        data = bytearray()
        label = ("canal %d" % (ch + 1)).encode()
        data += b"\x00\xff\x03" + bytes([len(label)]) + label
        last = 0
        for tick, _, b in ev:
            data += _vlq(tick - last) + b
            last = tick
        data += _vlq(max(int(end_beat * PPQ) - last, 0)) + b"\xff\x2f\x00"
        tracks.append(bytes(data))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(b"MThd" + struct.pack(">IHHH", 6, 1, len(tracks), PPQ))
        for t in tracks:
            f.write(b"MTrk" + struct.pack(">I", len(t)) + t)


# --------------------------------------------------------------- sintesis
def find_soundfont():
    for p in SOUNDFONTS:
        if os.path.exists(p):
            return p
    raise SystemExit("No encuentro un SoundFont .sf2 (instala fluid-soundfont-gm o timgm6mb-soundfont)")


def render(song, mid_path):
    fl = ctypes.CDLL("libfluidsynth.so.3")
    vp, ci, cd = ctypes.c_void_p, ctypes.c_int, ctypes.c_double
    fl.new_fluid_settings.restype = vp
    fl.new_fluid_synth.restype = vp
    fl.new_fluid_synth.argtypes = [vp]
    fl.new_fluid_player.restype = vp
    fl.new_fluid_player.argtypes = [vp]
    fl.fluid_settings_setnum.argtypes = [vp, ctypes.c_char_p, cd]
    fl.fluid_settings_setint.argtypes = [vp, ctypes.c_char_p, ci]
    fl.fluid_synth_sfload.argtypes = [vp, ctypes.c_char_p, ci]
    fl.fluid_player_add.argtypes = [vp, ctypes.c_char_p]
    fl.fluid_player_play.argtypes = [vp]
    fl.fluid_synth_write_float.argtypes = [vp, ci, vp, ci, ci, vp, ci, ci]
    st = fl.new_fluid_settings()
    fl.fluid_settings_setnum(st, b"synth.sample-rate", cd(SR))
    fl.fluid_settings_setnum(st, b"synth.gain", cd(0.7))
    fl.fluid_settings_setint(st, b"synth.polyphony", 256)
    syn = fl.new_fluid_synth(st)
    if fl.fluid_synth_sfload(syn, find_soundfont().encode(), 1) < 0:
        raise SystemExit("no se pudo cargar el SoundFont")
    try:
        fl.fluid_synth_set_reverb.argtypes = [vp, cd, cd, cd, cd]
        fl.fluid_synth_set_reverb(syn, 0.55, 0.35, 0.8, 0.55)
        fl.fluid_synth_set_chorus.argtypes = [vp, ci, cd, cd, cd, ci]
        fl.fluid_synth_set_chorus(syn, 3, 1.2, 0.3, 6.0, 0)
    except Exception:
        pass
    pl = fl.new_fluid_player(syn)
    fl.fluid_player_add(pl, mid_path.encode())
    fl.fluid_player_play(pl)
    length = song.bars * 4 * 60.0 / song.bpm
    frames = int((length + song.tail) * SR)
    left = np.zeros(frames, dtype=np.float32)
    right = np.zeros(frames, dtype=np.float32)
    block = 2048
    pos = 0
    while pos < frames:
        n = min(block, frames - pos)
        l = np.zeros(n, dtype=np.float32)
        r = np.zeros(n, dtype=np.float32)
        fl.fluid_synth_write_float(syn, n, l.ctypes.data, 0, 1, r.ctypes.data, 0, 1)
        left[pos:pos + n] = l
        right[pos:pos + n] = r
        pos += n
    body = int(length * SR)
    out = np.stack([left, right], axis=1)
    if song.loop:                                  # la cola de reverberacion se suma al principio: bucle continuo
        tail = out[body:]
        out = out[:body].copy()
        out[:len(tail)] += tail[:len(out)]
    else:
        fade = int(0.8 * SR)
        out[-fade:] *= np.linspace(1, 0, fade)[:, None]
    return out


def master(x):
    """Normaliza el volumen (RMS parecido en todas las canciones) y limita los picos."""
    rms = float(np.sqrt(np.mean(x ** 2))) + 1e-9
    x = x * (0.15 / rms)
    peak = float(np.max(np.abs(x)))
    if peak > 0.9:
        x = np.tanh(x * (0.9 / peak) * 1.15) / np.tanh(1.15) * 0.9     # limitador suave
    return x


def save_ogg(name, x):
    os.makedirs(OUT, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, name + ".wav")
        wavfile.write(wav, SR, (np.clip(x, -1, 1) * 32767).astype(np.int16))
        out = os.path.join(OUT, name + ".ogg")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "4", out], check=True)
    return out


# ------------------------------------------------------------------ plan por secciones
def layout(song, plan):
    """plan = [(nombre, [acordes, uno por compas]), ...] -> [(compas, seccion, indice, acorde)]."""
    bars = []
    b = 0
    for name, chords in plan:
        for i, spec in enumerate(chords):
            song.set_chord(b, spec)
            bars.append((b, name, i, spec))
            b += 1
    song.bars = b
    return bars


# ================================================================ CANCIONES
def song_menu():
    """Menu principal: 'Amanecer'. Re mayor, 100 bpm, guitarra + flauta + cuerdas (aire de aventura)."""
    s = Song("menu_theme", 100, Key("D", "major"))
    s.chan(0, 24, 100, 46)      # guitarra de nylon
    s.chan(1, 48, 78, 64)       # cuerdas
    s.chan(2, 73, 108, 80)      # flauta
    s.chan(3, 32, 104, 64)      # contrabajo
    s.chan(4, 11, 88, 38)       # vibrafono
    s.chan(5, 68, 92, 48)       # oboe
    s.chan(6, 46, 82, 92)       # arpa
    s.chan(9, 40, 92)           # bateria de escobillas
    INTRO = [(1, "M"), (5, "M"), (6, "m"), (4, "M")]
    A = [(1, "M"), (5, "M"), (6, "m"), (4, "M"), (1, "M"), (5, "M"), (4, "M"), (5, "M")]
    B = [(4, "M7"), (1, "M"), (2, "m7"), (5, "7"), (4, "M7"), (6, "m7"), (2, "m7"), (5, "7")]
    BR = [(6, "m"), (3, "m"), (4, "M"), (5, "M")]
    bars = layout(s, [("intro", INTRO), ("A", A), ("B", B), ("A2", A), ("bridge", BR)])
    MA = ["5:1 3:0.5 5:0.5 8:2", "7:1 5:0.5 7:0.5 9:2", "10:1 8:0.5 6:0.5 8:2", "6:1 5:0.5 4:0.5 6:1 8:1",
          "10:1.5 9:0.5 8:1 5:1", "7:1 9:1 9:0.5 10:0.5 9:1", "8:1 6:1 4:1 5:0.5 6:0.5", "7:1 9:2 r:1"]
    MB = ["11:2 10:1 8:1", "10:1.5 9:0.5 10:1 12:1", "11:1 9:1 11:1 13:1", "12:1 11:0.5 9:0.5 7:2",
          "8:1 10:1 11:1 10:0.5 8:0.5", "13:1 12:0.5 10:0.5 8:2", "9:1 11:1 13:2", "12:2 11:1 9:1"]
    MBR = ["8:2 10:2", "12:2 10:1 7:1", "11:2 8:1 6:1", "12:1.5 11:0.5 9:1 7:1"]
    for b, sec, i, spec in bars:
        s.arp(0, b, spec, [0, 1, 2, 4, 3, 4, 2, 1], -1, 70 if sec != "intro" else 62)
        if sec == "intro":
            if i >= 1:
                s.pad(1, b, spec, -1, 44, double_root=True)
            if i >= 2:
                s.bass(3, b, spec, [(0, 1.9, "r"), (2, 1.9, "5")], 74)
            if i == 3:
                for k in range(8):                                   # glissando de arpa hacia la entrada
                    s.note(6, b, 2.0 + k * 0.25, 0.6, s.key.pitch(1 + k * 1, 1), 60 + k * 3)
        if sec == "A":
            s.bass(3, b, spec, [(0, 0.9, "r"), (1, 0.9, "5"), (2, 0.9, "o"), (3, 0.9, "5")], 80)
            s.melody(2, b, MA[i], 0, 92)
            s.pad(1, b, spec, -1, 40)
            s.drums(b, "brush", 0.75, crash=(i == 0))
        if sec == "B":
            s.bass(3, b, spec, [(0, 1.4, "r"), (1.5, 0.45, "r"), (2, 0.9, "5"), (3, 0.9, "4" if i % 2 else "3")], 80)
            s.melody(5, b, MB[i], 0, 92)
            s.pad(1, b, spec, -1, 52, double_root=True)
            s.arp(4, b, spec, [None, 5, None, 4, None, 5, None, 3], 0, 58, step=0.5, dur=0.8)
            s.drums(b, "brush_snare", 0.85, crash=(i == 0), fill=(i == 7))
            if i == 0:
                for k in range(8):
                    s.note(6, b, k * 0.25, 0.5, s.key.pitch(1 + k, 0), 64 + k * 2)
        if sec == "A2":
            s.bass(3, b, spec, [(0, 0.9, "r"), (1, 0.9, "5"), (2, 0.9, "o"), (3, 0.9, "5")], 86)
            s.melody(2, b, MA[i], 0, 100)
            s.melody(5, b, MA[i], 0, 80, below=-2)                       # tercera paralela abajo
            s.pad(1, b, spec, -1, 58, double_root=True)
            s.arp(4, b, spec, [None, 4, None, 5, None, 4, None, 2], 0, 56, step=0.5, dur=0.8)
            s.drums(b, "brush_snare", 0.95, crash=(i == 0), fill=(i == 7))
        if sec == "bridge":
            s.bass(3, b, spec, [(0, 1.9, "r"), (2, 1.9, "5")], 76)
            s.melody(4, b, MBR[i], 0, 96, legato=1.0)
            s.pad(1, b, spec, -1, 56, double_root=True)
            s.drums(b, "toms", 0.7, fill=(i == 3))
    return s


def song_select():
    """Seleccion de personaje y de escenario: 'Vestuario'. Mi dorico, 118 bpm, groove funk con saxo y metales."""
    s = Song("select_theme", 118, Key("E", "dorian"))
    s.chan(0, 4, 90, 44)        # piano electrico
    s.chan(1, 28, 84, 84)       # guitarra apagada
    s.chan(2, 36, 106, 64)      # bajo slap
    s.chan(3, 65, 108, 78)      # saxo alto
    s.chan(4, 61, 92, 50)       # metales
    s.chan(5, 50, 62, 64)       # cuerdas sinteticas
    s.chan(6, 11, 72, 36)       # vibrafono
    s.chan(9, 0, 96)            # bateria
    INTRO = [(1, "m7"), (1, "m7")]
    A = [(1, "m7"), (1, "m7"), (4, "7"), (4, "7"), (1, "m7"), (1, "m7"), (7, "M"), (5, "m7")]
    B = [(3, "M7"), (7, "M"), (1, "m7"), (1, "m7"), (4, "7"), (7, "M"), (5, "m7"), (5, "7")]
    bars = layout(s, [("intro", INTRO), ("A", A), ("B", B), ("A2", A)])
    MA = ["5:0.75 3:0.25 1:0.5 3:0.5 5:1 r:1", "7:0.5 5:0.5 3:1 r:0.5 1:0.5 3:1", "8:1 6:0.5 4:0.5 6:1 8:1",
          "8:0.75 6:0.25 4:0.5 6:0.5 8:1 r:1", "5:0.75 3:0.25 1:0.5 3:0.5 5:0.5 7:0.5 8:1",
          "10:1 8:0.5 7:0.5 5:1 3:1", "7:1 4:0.5 2:0.5 4:1 7:1", "5:1 7:1 9:1 7:1"]
    MB = ["3:1 5:1 7:1 9:1", "7:1.5 5:0.5 4:1 2:1", "3:0.5 5:0.5 7:0.5 8:0.5 10:2", "8:1 7:1 5:1 3:1",
          "6:1 8:1 8:1 6:0.5 4:0.5", "7:2 9:1 7:1", "9:1 7:0.5 5:0.5 4:2", "9:1 #7:1 5:2"]
    FUNK_BASS = [(0, 0.4, "r", 6), (0.75, 0.2, "r", -14), (1.5, 0.4, "o"), (2, 0.4, "r"), (2.75, 0.2, "b7", -10),
                 (3.25, 0.5, "5")]
    FUNK_BASS_B = [(0, 0.75, "r", 6), (1, 0.4, "5"), (1.5, 0.4, "b7"), (2, 0.4, "o"), (2.5, 0.2, "b7", -12), (3, 0.4, "5"),
                   (3.5, 0.4, "4")]
    for b, sec, i, spec in bars:
        s.comp(0, b, spec, [(0, 0.45), (1.5, 0.45), (2.75, 0.2, -8), (3.5, 0.4)], 0, 66)
        s.bass(2, b, spec, FUNK_BASS if (b % 2 == 0) else FUNK_BASS_B, 92)
        rnd_steps = [1, 3, 5, 7, 9, 11, 13, 15]
        ts = s.tones(spec, -1)
        for k in rnd_steps:                                              # chop de guitarra en semicorcheas
            if (k + b) % 3 != 0:
                s.note(1, b, k * 0.25, 0.12, ts[1] + 12, 62 + (10 if k in (5, 13) else 0))
                s.note(1, b, k * 0.25, 0.12, ts[2] + 12, 58)
        if sec == "intro":
            s.drums(b, "funk", 0.7, crash=(i == 0))
        if sec in ("A", "A2"):
            s.drums(b, "funk", 1.0, crash=(i == 0), fill=(i == 7))
            s.melody(3, b, MA[i], 0, 96)
            if sec == "A2":
                s.comp(4, b, spec, [(1.5, 0.3, 10), (3.5, 0.3, 10)], 0, 84, voicing=[1, 2, 3])
                s.pad(5, b, spec, -1, 40)
        if sec == "B":
            s.drums(b, "funk", 1.05, crash=(i == 0), fill=(i == 7))
            s.melody(3, b, MB[i], 0, 98)
            s.pad(5, b, spec, -1, 54, double_root=True)
            s.arp(6, b, spec, [4, None, 3, None, 5, None, 3, 2], 0, 56, step=0.5, dur=0.6)
            s.comp(4, b, spec, [(0, 0.35, 8), (2.75, 0.25)], 0, 80, voicing=[1, 2, 3])
    return s


def song_battle_pradera():
    """Combate en la Pradera: 'Galope'. Sol mayor/mixolidio, 152 bpm, trompeta heroica y guitarra electrica."""
    s = Song("battle_theme", 152, Key("G", "major"))
    s.chan(0, 29, 92, 40)       # guitarra saturada
    s.chan(1, 38, 104, 64)      # bajo sintetico
    s.chan(2, 56, 106, 76)      # trompeta
    s.chan(3, 61, 88, 56)       # metales
    s.chan(4, 48, 76, 70)       # cuerdas
    s.chan(5, 60, 84, 46)       # trompa
    s.chan(6, 9, 100, 88)       # glockenspiel
    s.chan(7, 45, 80, 30)       # cuerdas pizzicato
    s.chan(9, 16, 98)           # bateria potente
    INTRO = [(1, "M"), (5, "M")]
    A = [(1, "M"), (7, "M", -1), (4, "M"), (1, "M"), (1, "M"), (5, "M"), (4, "M"), (5, "M")]
    B = [(6, "m"), (4, "M"), (1, "M"), (5, "M"), (6, "m"), (4, "M"), (2, "m"), (5, "M")]
    BR = [(4, "M"), (5, "M"), (6, "m"), (5, "M")]
    bars = layout(s, [("intro", INTRO), ("A", A), ("B", B), ("bridge", BR), ("A2", A)])
    MA = ["5:1 8:1 5:0.5 3:0.5 5:1", "b7:1 9:1 11:1 9:1", "8:1 6:1 4:1 6:1", "5:2 3:1 5:1",
          "8:1 10:1 12:2", "12:1 9:1 7:1 9:1", "8:1 6:0.5 4:0.5 6:1 8:1", "12:2 9:1 7:1"]
    MB = ["10:2 8:1 6:1", "11:1.5 10:0.5 8:1 6:1", "5:1 8:1 10:2", "12:1 9:1 7:2",
          "10:1 12:1 10:1 8:1", "11:1 9:0.5 8:0.5 6:1 4:1", "9:1 11:1 9:1 11:1", "12:1 10:0.5 9:0.5 7:2"]
    MBR = ["11:2 8:2", "12:2 9:2", "10:2 8:2", "12:1 9:1 7:1 9:1"]
    PM = [(0, 0.45), (0.5, 0.45), (1, 0.45), (1.5, 0.45), (2, 0.45), (2.5, 0.45), (3, 0.45), (3.5, 0.45)]
    RIFF = [(0, 0.45, "r"), (0.5, 0.45, "r"), (1, 0.45, "o"), (1.5, 0.45, "r"), (2, 0.45, "r"), (2.5, 0.45, "o"),
            (3, 0.45, "r"), (3.5, 0.45, "5")]
    for b, sec, i, spec in bars:
        if sec == "intro":
            s.drums(b, "rock_half", 0.9, crash=(i == 0), fill=(i == 1))
            s.comp(0, b, spec, [(0, 0.9), (2, 0.9), (3, 0.4)], -1, 94, voicing=[0, 2, 3])
            s.bass(1, b, spec, RIFF, 88)
            s.pad(4, b, spec, -1, 60, double_root=True)
            continue
        if sec in ("A", "A2"):
            s.comp(0, b, spec, PM, -1, 80, voicing=[0, 2, 3])
            s.bass(1, b, spec, RIFF, 94)
            s.melody(2, b, MA[i], 0, 100)
            if sec == "A2":
                s.melody(3, b, MA[i], 0, 80, below=-2)
                s.arp(6, b, spec, [None, 4, None, 5, None, 3, None, 5], 1, 80, step=0.5, dur=0.4)
                s.pad(4, b, spec, -1, 62, double_root=True)
            s.drums(b, "rock", 1.0, crash=(i == 0), fill=(i == 7))
        if sec == "B":
            s.comp(0, b, spec, [(0, 3.6)], -1, 70, voicing=[0, 2, 3])
            s.bass(1, b, spec, [(0, 0.9, "r"), (1, 0.9, "r"), (2, 0.9, "5"), (3, 0.9, "o")], 92)
            s.melody(2, b, MB[i], 0, 98)
            s.pad(4, b, spec, -1, 70, double_root=True)
            s.pad(5, b, spec, 0, 56)
            s.arp(7, b, spec, [0, 1, 2, 1, 0, 1, 2, 1], 0, 62, step=0.5, dur=0.25)
            s.drums(b, "rock", 1.05, crash=(i == 0), fill=(i == 7))
        if sec == "bridge":
            s.bass(1, b, spec, [(0, 0.4, "r"), (0.5, 0.4, "r"), (1, 0.9, "o"), (2, 0.4, "r"), (2.5, 0.4, "r"), (3, 0.9, "5")], 90)
            s.melody(5, b, MBR[i], 0, 86, legato=1.0)
            s.pad(4, b, spec, -1, 76, double_root=True)
            s.drums(b, "toms", 0.95, fill=(i == 3), crash=(i == 0))
    return s


def song_battle_desierto():
    """Combate en el Desierto: 'Dunas'. Re frigio dominante, 118 bpm, shehnai, sitar y percusion."""
    s = Song("battle_desierto", 118, Key("D", "phryg_dom"))
    s.chan(0, 104, 96, 44)      # sitar
    s.chan(1, 111, 108, 78)     # shehnai
    s.chan(2, 35, 104, 64)      # bajo fretless
    s.chan(3, 45, 86, 84)       # cuerdas pizzicato
    s.chan(4, 42, 72, 60)       # violonchelo (bordon)
    s.chan(5, 91, 60, 64)       # coro
    s.chan(6, 108, 80, 36)      # kalimba
    s.chan(9, 0, 100)           # percusion
    A = [(1, "M"), (2, "M"), (1, "M"), (2, "M"), (4, "m"), (1, "M"), (2, "M"), (1, "M")]
    B = [(4, "m"), (1, "M"), (4, "m"), (1, "M"), (2, "M"), (5, "dim"), (2, "M"), (1, "M")]
    BR = [(1, "M"), (2, "M"), (4, "m"), (1, "M")]
    INTRO = [(1, "5"), (1, "5"), (2, "M"), (1, "M")]
    bars = layout(s, [("intro", INTRO), ("A", A), ("B", B), ("bridge", BR), ("A2", A)])
    MA = ["5:1 3:0.5 5:0.5 8:1 5:0.5 3:0.5", "9:1.5 8:0.5 6:1 4:1", "3:0.5 5:0.5 8:1 10:1 8:0.5 5:0.5", "9:2 6:1 8:1",
          "4:1 6:1 8:1 6:1", "10:1.5 9:0.5 8:1 5:1", "9:1 8:0.5 9:0.5 11:1 9:1", "8:2 5:1 3:1"]
    MB = ["11:1 13:1 11:1 8:1", "10:1 8:1 5:1 3:1", "13:1.5 11:0.5 8:1 6:1", "10:2 12:1 10:1",
          "9:1.5 11:0.5 13:1 11:1", "12:1 9:1 7:1 5:1", "13:1 11:1 9:2", "10:1 8:1 5:1 3:1"]
    MBR = ["8:4", "9:4", "11:2 8:2", "10:2 8:2"]
    SITAR = [0, 2, 1, 2, 3, 2, 1, 2]
    for b, sec, i, spec in bars:
        s.pad(4, b, spec if sec != "intro" else (1, "5"), -2, 58, double_root=True)       # bordon continuo
        if sec == "intro":
            s.arp(0, b, (1, "5"), SITAR, -1, 66, step=0.5, dur=0.9)
            s.drums(b, "desert", 0.6 if i < 2 else 0.85, crash=(i == 0), fill=(i == 3)) if i >= 1 else None
            if i >= 2:
                s.bass(2, b, spec, [(0, 0.9, "r"), (2, 0.9, "r"), (3, 0.9, "5")], 80)
            continue
        s.arp(0, b, spec, SITAR if sec != "bridge" else [0, None, 1, None, 2, None, 1, None], -1, 76, step=0.5, dur=0.9)
        if sec in ("A", "A2"):
            s.melody(1, b, MA[i], 0, 98)
            s.bass(2, b, spec, [(0, 0.9, "r"), (1, 0.4, "r"), (1.5, 0.4, "b2" if spec[0] == 1 else "r"), (2, 0.9, "r"),
                                (3, 0.4, "5"), (3.5, 0.4, "o")], 90)
            for k in (1, 3):
                s.comp(3, b, spec, [(k + 0.5, 0.2, 6)], 0, 72, voicing=[0, 2])
            s.drums(b, "desert", 1.0, crash=(i == 0), fill=(i == 7))
            if sec == "A2":
                s.melody(6, b, MA[i], 1, 70)
                s.melody(0, b, MA[i], 0, 70, below=-4)
        if sec == "B":
            s.melody(1, b, MB[i], 0, 100)
            s.bass(2, b, spec, [(0, 0.9, "r"), (1, 0.9, "5"), (2, 0.9, "r"), (3, 0.4, "o"), (3.5, 0.4, "5")], 92)
            s.pad(5, b, spec, -1, 52)
            s.drums(b, "desert", 1.1, crash=(i == 0), fill=(i == 7))
            for k in (1, 3):
                s.comp(3, b, spec, [(k + 0.5, 0.2, 6)], 0, 74, voicing=[0, 2])
        if sec == "bridge":
            s.melody(1, b, MBR[i], 0, 100, legato=1.0)
            s.pad(5, b, spec, -1, 70, double_root=True)
            s.bass(2, b, spec, [(0, 1.9, "r"), (2, 1.9, "5")], 84)
            s.drums(b, "desert_build", 0.95, fill=(i == 3))
    return s


def song_battle_azotea():
    """Combate en la Azotea: 'Neon'. La menor, 134 bpm, synthwave: bajo pulsante, arpegios y lead cuadrado."""
    s = Song("battle_azotea", 134, Key("A", "minor"))
    s.chan(0, 39, 102, 64)      # bajo sintetico
    s.chan(1, 81, 82, 40)       # arpegio sierra
    s.chan(2, 89, 74, 64)       # colchon
    s.chan(3, 80, 100, 76)      # lead cuadrado
    s.chan(4, 50, 70, 88)       # cuerdas sinteticas
    s.chan(5, 98, 76, 36)       # cristal
    s.chan(6, 95, 66, 64)       # barrido
    s.chan(9, 24, 100)          # bateria electronica
    INTRO = [(1, "m"), (6, "M"), (3, "M"), (7, "M")]
    A = [(1, "m"), (6, "M"), (3, "M"), (7, "M"), (1, "m"), (6, "M"), (4, "m"), (5, "M")]
    B = [(6, "M"), (7, "M"), (1, "m"), (1, "m"), (4, "m"), (6, "M"), (5, "M"), (5, "M")]
    BR = [(1, "m"), (1, "m"), (6, "M"), (5, "M")]
    bars = layout(s, [("intro", INTRO), ("A", A), ("B", B), ("bridge", BR), ("A2", A)])
    MA = ["8:1 5:1 3:1 5:1", "6:1 8:1 10:1 8:1", "10:1 7:1 5:1 7:1", "9:1 7:1 4:1 7:1",
          "8:1.5 9:0.5 10:1 8:1", "10:1 8:1 6:2", "8:1 6:1 4:1 6:1", "9:1 #7:1 5:2"]
    MB = ["10:2 8:1 6:1", "9:2 7:1 4:1", "8:1 10:1 12:2", "10:1 9:0.5 8:0.5 5:2",
          "8:1 6:1 8:1 11:1", "10:1 8:1 10:1 13:1", "12:1 9:1 #7:1 9:1", "9:1 #7:1 5:1 #7:1"]
    MBR = ["8:4", "8:2 10:2", "10:2 8:2", "9:1 #7:1 5:2"]
    BASS16 = [(i * 0.25, 0.2, iv) for i, iv in enumerate(["r", "r", "o", "r", "5", "r", "o", "r", "r", "r", "o", "r", "5", "r", "b7", "o"])]
    BASS8 = [(i * 0.5, 0.45, "r") for i in range(8)]
    for b, sec, i, spec in bars:
        if sec == "intro":
            s.arp(1, b, spec, [0, 1, 2, 3, 2, 1, 2, 3, 0, 1, 2, 3, 2, 1, 2, 3], -1, 60 + 4 * i, step=0.25, dur=0.3)
            s.pad(2, b, spec, -1, 56 + 4 * i, double_root=True)
            if i >= 2:
                s.bass(0, b, spec, BASS8, 80)
                s.drums(b, "synth_light", 0.8, crash=(i == 2), fill=(i == 3))
            if i == 3:
                s.note(5, b, 0, 2.0, s.key.pitch(8, 1), 70)
            continue
        if sec in ("A", "A2"):
            s.bass(0, b, spec, BASS16, 96)
            s.melody(3, b, MA[i], 0, 96, legato=0.9)
            s.arp(1, b, spec, [0, 1, 2, 3, 2, 1, 2, 3, 0, 1, 2, 3, 2, 1, 2, 3], -1, 54, step=0.25, dur=0.3)
            s.pad(2, b, spec, -1, 60, double_root=True)
            s.drums(b, "synth", 1.0, crash=(i == 0), fill=(i == 7))
            if sec == "A2":
                s.melody(5, b, MA[i], 1, 62, legato=0.5)
                s.pad(4, b, spec, 0, 56)
        if sec == "B":
            s.bass(0, b, spec, BASS8 if i % 4 < 2 else BASS16, 98)
            s.melody(3, b, MB[i], 0, 100, legato=0.92)
            s.arp(1, b, spec, [0, 2, 1, 3, 2, 4, 3, 5, 4, 3, 2, 3, 1, 2, 0, 1], -1, 56, step=0.25, dur=0.3)
            s.pad(4, b, spec, 0, 64, double_root=True)
            s.pad(2, b, spec, -1, 52)
            s.drums(b, "synth", 1.05, crash=(i == 0), fill=(i == 7))
        if sec == "bridge":
            s.bass(0, b, spec, [(0, 1.9, "r"), (2, 1.9, "r")], 90)
            s.melody(5, b, MBR[i], 1, 84, legato=1.0)
            s.pad(4, b, spec, 0, 70, double_root=True)
            s.pad(6, b, spec, 0, 50) if i == 3 else None
            s.drums(b, "synth_light", 0.9, fill=(i == 3))
    return s


def song_victory():
    """Fanfarria de victoria (se toca una sola vez). Do mayor, 120 bpm."""
    s = Song("victory_theme", 120, Key("C", "major"), loop=False, tail=3.5)
    s.chan(0, 56, 110, 70)      # trompeta
    s.chan(1, 61, 96, 50)       # metales
    s.chan(2, 48, 84, 64)       # cuerdas
    s.chan(3, 47, 100, 64)      # timbales
    s.chan(4, 9, 86, 84)        # glockenspiel
    s.chan(5, 32, 100, 64)      # contrabajo
    s.chan(9, 48, 100)          # orquesta (platillos)
    chords = [(1, "M"), (4, "M"), (5, "7"), (1, "M"), (1, "M")]
    bars = layout(s, [("v", chords)])
    M = ["1:0.5 3:0.5 5:0.5 8:1.5 5:0.5 8:0.5", "4:1 6:1 8:2", "5:0.5 7:0.5 9:1 11:2", "8:1 10:1 12:2",
         "8:0.5 10:0.5 12:0.5 15:2.5"]
    for b, sec, i, spec in bars:
        s.melody(0, b, M[i], 0, 104, legato=0.95)
        s.melody(1, b, M[i], 0, 84, below=-2)
        s.pad(2, b, spec, -1, 66, double_root=True)
        s.bass(5, b, spec, [(0, 1.9, "r"), (2, 1.9, "5")], 86)
        s.note(3, b, 0, 0.4, s.key.pitch(1, -2), 100)
        for k in range(4):
            s.note(3, b, 2 + k * 0.5, 0.4, s.key.pitch(1 if i != 2 else 5, -2), 70 + k * 10)
        s.arp(4, b, spec, [4, 5, 3, 5, 4, 5, 3, 5], 1, 60, step=0.5, dur=0.4)
        if i in (0, 3, 4):
            s.note(9, b, 0, 2, 49, 100, human=False)
    return s


SONGS = [song_menu, song_select, song_battle_pradera, song_battle_desierto, song_battle_azotea, song_victory]


def main():
    only = sys.argv[1:]
    for fn in SONGS:
        song = fn()
        if only and not any(o in song.name for o in only):
            continue
        bad = song.check_harmony()
        mid = os.path.join(MIDI_DIR, song.name + ".mid")
        write_midi(song, mid)
        audio = master(render(song, mid))
        ogg = save_ogg(song.name, audio)
        secs = song.bars * 4 * 60.0 / song.bpm
        print("%-16s %3d compases  %5.1f s  %3d bpm  notas=%4d  fuera-de-acorde(pulso 1/3)=%d  -> %s" % (
            song.name, song.bars, secs, song.bpm, len(song.notes), len(bad), os.path.relpath(ogg, PROJ)))
        for b in bad[:6]:
            print("    revisar compas %d pulso %.1f nota-pc=%d  en «%s»" % b)


if __name__ == "__main__":
    main()
