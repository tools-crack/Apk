extends SceneTree
# ============================================================================
#  test_aukin_golpe.gd — ¿sigue el Aukin cuando lo golpean durante su especial?
# ----------------------------------------------------------------------------
#      godot --path . --no-window -s tools/test_aukin_golpe.gd
#  Golpea a Aukin en tres momentos y comprueba que los tallarines siguen en pie:
#   A) durante el aviso (antes de que suban)
#   B) mientras suben (ventana de agarre)
#   C) mientras ya tienen atrapado al rival (apretones)
# ============================================================================
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func reset(f, pos):
	f.position = pos
	f.velocity = Vector2.ZERO
	f.percent = 0.0
	f.state = f.State.NORMAL
	f.invulnerable = false
	f.invuln_timer = 0.0
	f.special_timer = 0.0
	f.special_stun = 0.0
	f.frozen = false
	f.wrapped_time = 0.0
	f.collision_layer = 2
	f.sprite.visible = true


func press(action, sec = 0.06):
	Input.action_press(action)
	yield(create_timer(sec), "timeout")
	Input.action_release(action)


func find_all(node, script_name, out := []):
	for c in node.get_children():
		if c.get_script() != null and c.get_script().resource_path.ends_with(script_name):
			out.append(c)
		find_all(c, script_name, out)
	return out


func _initialize():
	_run()


func _run():
	var game = root.get_node("Game")
	game.selected = ["aukin", "gaviotero"]
	game.practice = false
	var arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(3.6), "completed")
	var aukin = arena.fighters[0]
	var rival = arena.fighters[1]

	# ---- A) golpe durante el aviso
	print("== Aukin: golpeado durante el aviso")
	reset(aukin, Vector2(400, 440))
	reset(rival, Vector2(700, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.05), "completed")
	aukin.take_hit(1.0, Vector2(60, -120), rival)
	var guard = 0
	while rival.wrapped_time <= 0.0 and guard < 200:
		yield(wait(0.01), "completed")
		guard += 1
	check("A: los tallarines siguen y atrapan al rival", rival.wrapped_time > 0.0, "espera=%.2fs" % (guard * 0.01))
	yield(wait(2.0), "completed")
	check("A: el rival recibe el daño de los apretones", rival.percent > 5.0, "percent=%s" % rival.percent)

	# ---- B) golpe mientras suben
	print("== Aukin: golpeado mientras suben")
	reset(aukin, Vector2(400, 440))
	reset(rival, Vector2(700, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	guard = 0
	var nd = null
	while guard < 300:
		var ns = find_all(arena, "Noodles.gd")
		if ns.size() > 0 and ns[0].phase == ns[0].Phase.RISE:
			nd = ns[0]
			break
		yield(wait(0.01), "completed")
		guard += 1
	if nd != null:
		aukin.take_hit(1.0, Vector2(60, -120), rival)
	yield(wait(0.3), "completed")
	check("B: el rival queda atrapado pese al golpe a Aukin", rival.wrapped_time > 0.0 or rival.percent > 0.0, "percent=%s" % rival.percent)
	yield(wait(2.0), "completed")
	check("B: el rival recibe el daño total de los tallarines", rival.percent > 14.0, "percent=%s" % rival.percent)

	# ---- C) golpe cuando ya lo tienen atrapado
	print("== Aukin: golpeado con el rival atrapado")
	reset(aukin, Vector2(400, 440))
	reset(rival, Vector2(700, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	guard = 0
	while rival.wrapped_time <= 0.0 and guard < 300:
		yield(wait(0.01), "completed")
		guard += 1
	aukin.take_hit(1.0, Vector2(60, -120), rival)
	yield(wait(2.0), "completed")
	check("C: el rival recibe el daño total de los tallarines", rival.percent > 14.0, "percent=%s" % rival.percent)
	check("C: el rival es lanzado al soltarlo", rival.state == rival.State.HURT and rival.velocity.y < 0.0, "vy=%s" % rival.velocity.y)

	print("")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
