extends SceneTree
# ============================================================================
#  test_nanco_winkul.gd — comprueba los especiales de Ñanco y Winkul
# ----------------------------------------------------------------------------
#      godot --path . -s tools/test_nanco_winkul.gd
#  Ñanco  (Humo de cigarro):  fuma (aviso) -> sopla una nube que daña una vez y
#                             EMPUJA; se esquiva saltando o alejándose.
#  Winkul (Pinchos al borde): grietas de aviso -> pinchos que dañan y lanzan al
#                             rival HACIA LA ORILLA; se esquivan desde una
#                             plataforma o quedándose fuera de la fila.
# ============================================================================
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func reset(f, pos):
	f.position = pos
	f.velocity = Vector2.ZERO
	f.percent = 0.0
	f.state = f.State.NORMAL
	f.invulnerable = false
	f.invuln_timer = 0.0
	f.special_timer = 0.0
	f.frozen = false
	f.wrapped_time = 0.0
	f.collision_layer = 2
	f.sprite.visible = true


func press(action, sec = 0.06):
	Input.action_press(action)
	yield(create_timer(sec), "timeout")
	Input.action_release(action)


func find_all(node, script_name, out := []):
	for c in node.get_children():
		if c.get_script() != null and c.get_script().resource_path.ends_with(script_name):
			out.append(c)
		find_all(c, script_name, out)
	return out


func _initialize():
	_run()


func _run():
	var game = root.get_node("Game")

	# ------------------------------------------------------------------ ÑANCO
	print("== Ñanco: Humo de cigarro")
	game.selected = ["nanco", "gaviotero"]
	game.practice = false
	var arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(3.6), "completed")
	var nanco = arena.fighters[0]
	var rival = arena.fighters[1]
	check("Ñanco: ficha cargada (nombre con Ñ)", nanco.display_name == "Ñanco" and nanco.stats.smoke_length == 280.0)
	check("Ñanco: tiene animacion special", nanco.sprite.frames.has_animation("special"))

	reset(nanco, Vector2(400, 440))
	nanco.facing = 1
	reset(rival, Vector2(520, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.25), "completed")
	check("Ñanco: mientras fuma (aviso) sigue en SPECIAL y no hay nube", nanco.state == nanco.State.SPECIAL and find_all(arena, "SmokeCloud.gd").size() == 0)
	check("Ñanco: durante el aviso nadie recibe daño", rival.percent == 0.0)
	var x_before = rival.position.x
	yield(wait(0.55), "completed")
	check("Ñanco: sopla una nube de humo", find_all(arena, "SmokeCloud.gd").size() == 1)
	yield(wait(1.0), "completed")
	check("Ñanco: el humo daña special_damage una vez", abs(rival.percent - 7.0) < 0.01, "percent=%s" % rival.percent)
	check("Ñanco: el humo EMPUJA al rival hacia donde sopla", rival.position.x > x_before + 60.0, "x %s -> %s" % [x_before, rival.position.x])
	check("Ñanco: la nube se borra sola", find_all(arena, "SmokeCloud.gd").size() == 0)
	check("Ñanco: vuelve a NORMAL", nanco.state == nanco.State.NORMAL)

	print("== Ñanco: soplando hacia la izquierda")
	reset(nanco, Vector2(800, 440))
	nanco.facing = -1
	reset(rival, Vector2(680, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(1.4), "completed")
	check("Ñanco: empuja hacia la izquierda si mira a la izquierda", rival.percent > 0.0 and rival.position.x < 660.0, "x=%s percent=%s" % [rival.position.x, rival.percent])

	print("== Ñanco: se esquiva")
	reset(nanco, Vector2(400, 440))
	nanco.facing = 1
	reset(rival, Vector2(900, 440))                # más lejos que smoke_length
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(1.5), "completed")
	check("Ñanco: fuera de alcance no recibe daño", rival.percent == 0.0, "percent=%s" % rival.percent)
	reset(nanco, Vector2(400, 440))
	reset(rival, Vector2(520, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.3), "completed")
	rival.position.y = 250.0                        # por encima de la nube (alto 100)
	rival.frozen = true
	yield(wait(1.2), "completed")
	rival.frozen = false
	check("Ñanco: por encima de la nube no recibe daño", rival.percent == 0.0, "percent=%s" % rival.percent)
	arena.queue_free()
	yield(wait(0.3), "completed")

	# ------------------------------------------------------------------ WINKUL
	print("== Winkul: Pinchos al borde")
	game.selected = ["winkul", "gaviotero"]
	arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(3.6), "completed")
	var winkul = arena.fighters[0]
	rival = arena.fighters[1]
	check("Winkul: ficha cargada", winkul.display_name == "Winkul" and winkul.stats.spike_count == 6)

	reset(winkul, Vector2(400, 440))
	winkul.facing = 1
	reset(rival, Vector2(650, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.3), "completed")
	var spikes = find_all(arena, "Spike.gd")
	check("Winkul: aparecen spike_count grietas de aviso", spikes.size() == 6, "n=%d" % spikes.size())
	var all_warn = true
	for sp in spikes:
		if sp.phase != sp.Phase.WARN:
			all_warn = false
	check("Winkul: al principio solo hay grietas (sin daño)", all_warn and rival.percent == 0.0)
	var xs = []
	for sp in spikes:
		xs.append(sp.position.x)
	xs.sort()
	check("Winkul: separados spike_spacing px desde 90 px delante", abs(xs[0] - 490.0) < 1.0 and abs(xs[5] - 890.0) < 1.0, str(xs))
	var guard = 0
	while rival.percent <= 0.0 and guard < 100:
		yield(wait(0.02), "completed")
		guard += 1
	check("Winkul: el pincho daña special_damage", abs(rival.percent - 10.0) < 0.01, "percent=%s" % rival.percent)
	check("Winkul: lo lanza hacia la orilla derecha (estaba a la derecha del centro)", rival.velocity.x > 0.0 and rival.velocity.y < 0.0, "v=%s" % rival.velocity)
	yield(wait(1.5), "completed")
	check("Winkul: los pinchos se borran solos", find_all(arena, "Spike.gd").size() == 0)

	print("== Winkul: hacia la orilla izquierda si el rival está a la izquierda del centro")
	reset(winkul, Vector2(400, 440))
	winkul.facing = 1
	reset(rival, Vector2(570, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	guard = 0
	while rival.percent <= 0.0 and guard < 100:
		yield(wait(0.02), "completed")
		guard += 1
	check("Winkul: lanza hacia la izquierda", rival.percent > 0.0 and rival.velocity.x < 0.0, "v=%s percent=%s" % [rival.velocity, rival.percent])
	yield(wait(1.6), "completed")

	print("== Winkul: se esquiva")
	reset(winkul, Vector2(400, 440))
	winkul.facing = 1
	reset(rival, Vector2(880, 310))                 # sobre la plataforma derecha
	yield(wait(0.3), "completed")
	check("Winkul: el rival esta sobre la plataforma", rival.is_on_floor())
	yield(press("p1_special"), "completed")
	yield(wait(1.6), "completed")
	check("Winkul: desde una plataforma no recibe daño", rival.percent == 0.0, "percent=%s" % rival.percent)
	reset(winkul, Vector2(400, 440))
	reset(rival, Vector2(965, 440))                 # fuera de la fila (el último pincho cubre hasta x=912)
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(1.6), "completed")
	check("Winkul: fuera de la fila no recibe daño", rival.percent == 0.0, "percent=%s" % rival.percent)

	print("")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
