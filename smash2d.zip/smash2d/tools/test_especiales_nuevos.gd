extends SceneTree
# ============================================================================
#  test_especiales_nuevos.gd — comprueba los especiales de Likan y Aukin
# ----------------------------------------------------------------------------
#      godot --path . -s tools/test_especiales_nuevos.gd
#  Likan  (Lluvia de rocas):      caen rock_count rocas, avisan con sombra,
#                                 golpean si te quedas debajo y NO si te apartas.
#  Aukin  (Tallarines):           brotan bajo el rival, lo atrapan e inmovilizan,
#                                 reparten special_damage, lo sueltan y lo lanzan;
#                                 se esquivan saliendo de la zona o saltando alto.
# ============================================================================
var fails := 0


func check(name, cond, extra = ""):
	if cond:
		print("[OK]   ", name, " ", extra)
	else:
		fails += 1
		print("[FAIL] ", name, " ", extra)


func wait(sec):
	yield(create_timer(sec), "timeout")


func reset(f, pos):
	f.position = pos
	f.velocity = Vector2.ZERO
	f.percent = 0.0
	f.state = f.State.NORMAL
	f.invulnerable = false
	f.invuln_timer = 0.0
	f.special_timer = 0.0
	f.frozen = false
	f.wrapped_time = 0.0
	f.collision_layer = 2
	f.sprite.visible = true


func press(action, sec = 0.06):
	Input.action_press(action)
	yield(create_timer(sec), "timeout")
	Input.action_release(action)


# Busca recursivamente (los especiales se añaden al nodo Stage, no a la raíz de la arena).
func find_all(node, script_name, out := []):
	for c in node.get_children():
		if c.get_script() != null and c.get_script().resource_path.ends_with(script_name):
			out.append(c)
		find_all(c, script_name, out)
	return out


func count_nodes(arena, script_name):
	return find_all(arena, script_name).size()


func _initialize():
	_run()


func _run():
	var game = root.get_node("Game")

	# ------------------------------------------------------------------ LIKAN
	print("== Likan: Lluvia de rocas")
	game.selected = ["likan", "aukin"]
	game.practice = false
	var arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(3.6), "completed")
	var likan = arena.fighters[0]
	var rival = arena.fighters[1]
	check("Likan: ficha cargada", likan.display_name == "Likan" and likan.stats.rock_count == 5)

	reset(likan, Vector2(400, 440))
	reset(rival, Vector2(800, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.3), "completed")
	check("Likan: invoca rock_count rocas", count_nodes(arena, "Rock.gd") == 5, "rocas=%d" % count_nodes(arena, "Rock.gd"))
	check("Likan: durante el aviso nadie recibe daño", rival.percent == 0.0)
	var visible_rocks = 0
	for c in find_all(arena, "Rock.gd"):
		if c.rock.visible:
			visible_rocks += 1
	check("Likan: aún no hay rocas cayendo (solo sombras)", visible_rocks == 0, "cayendo=%d" % visible_rocks)
	var middle = null
	for c in find_all(arena, "Rock.gd"):
		if middle == null or abs(c.position.x - rival.position.x) < abs(middle.position.x - rival.position.x):
			middle = c
	check("Likan: una roca apunta al rival", abs(middle.position.x - rival.position.x) < 20.0, "dx=%s" % abs(middle.position.x - rival.position.x))
	check("Likan: la roca cae hasta el suelo principal (y=480), atravesando plataformas", abs(middle.land_y - 480.0) < 2.0, "land_y=%s" % middle.land_y)
	# el rival se queda quieto debajo: recibe daño
	yield(wait(3.0), "completed")
	check("Likan: quien se queda bajo la roca recibe daño", rival.percent >= 6.0, "percent=%s" % rival.percent)
	check("Likan: las rocas se borran solas", count_nodes(arena, "Rock.gd") == 0, "quedan=%d" % count_nodes(arena, "Rock.gd"))

	# esquivar: el rival se aparta de todas las rocas de la franja
	print("== Likan: las rocas se esquivan")
	reset(likan, Vector2(400, 440))
	reset(rival, Vector2(640, 440))
	yield(wait(0.4), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.25), "completed")
	var xs = []
	for c in find_all(arena, "Rock.gd"):
		xs.append(c.position.x)
	# busca un hueco: una x del suelo a >= 60 px de todas las rocas
	var safe_x = -1.0
	var cx = 320.0
	while cx <= 980.0:
		var ok = true
		for rx in xs:
			if abs(rx - cx) < 60.0:
				ok = false
		if ok:
			safe_x = cx
			break
		cx += 10.0
	check("Likan: hay un hueco seguro en la franja", safe_x > 0.0, "xs=%s" % str(xs))
	rival.position.x = safe_x
	yield(wait(3.0), "completed")
	check("Likan: apartándose a la sombra libre no recibe daño", rival.percent == 0.0, "percent=%s safe_x=%s" % [rival.percent, safe_x])

	arena.queue_free()
	yield(wait(0.3), "completed")

	# ------------------------------------------------------------------ AUKIN
	print("== Aukin: Tallarines enredadores")
	game.selected = ["aukin", "gaviotero"]
	arena = load("res://scenes/Arena.tscn").instance()
	root.add_child(arena)
	yield(wait(3.6), "completed")
	var aukin = arena.fighters[0]
	rival = arena.fighters[1]
	check("Aukin: ficha cargada", aukin.display_name == "Aukin" and aukin.stats.noodle_squeezes == 3)

	reset(aukin, Vector2(400, 440))
	reset(rival, Vector2(700, 440))
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.4), "completed")
	check("Aukin: brotan tallarines", count_nodes(arena, "Noodles.gd") == 1)
	var nd = null
	for c in find_all(arena, "Noodles.gd"):
		nd = c
	check("Aukin: brotan bajo el rival, en el suelo", nd != null and abs(nd.position.x - 700.0) < 4.0 and abs(nd.position.y - 480.0) < 2.0, "pos=%s" % (nd.position if nd != null else "null"))
	check("Aukin: en la fase de aviso no hay daño ni enredo", rival.percent == 0.0 and rival.wrapped_time <= 0.0)
	# el rival se queda quieto: queda atrapado
	var guard = 0
	while rival.wrapped_time <= 0.0 and guard < 100:
		yield(wait(0.02), "completed")
		guard += 1
	check("Aukin: el rival queda atrapado", rival.wrapped_time > 0.0 and rival.frozen and rival.state == rival.State.HURT, "espera=%.2fs" % (guard * 0.02))
	var held_pos = rival.position
	check("Aukin: el primer apretón ya hizo daño", abs(rival.percent - 5.0) < 0.01, "percent=%s" % rival.percent)
	yield(wait(0.5), "completed")
	check("Aukin: sigue inmovilizado en el mismo sitio", rival.position.distance_to(held_pos) < 1.0 and rival.frozen)
	yield(wait(0.7), "completed")
	check("Aukin: lo suelta (sin congelar) tras noodle_hold_time", not rival.frozen and rival.wrapped_time <= 0.0)
	check("Aukin: daño total = special_damage", abs(rival.percent - 15.0) < 0.01, "percent=%s" % rival.percent)
	check("Aukin: lo lanza al soltarlo", rival.state == rival.State.HURT and rival.velocity.y < 0.0, "vy=%s" % rival.velocity.y)
	yield(wait(1.5), "completed")
	check("Aukin: los tallarines se borran solos", count_nodes(arena, "Noodles.gd") == 0)
	check("Aukin: no queda congelado ni invulnerable", not aukin.frozen and not aukin.invulnerable)

	# ---- atrapa a quien ENTRA mientras los tallarines siguen arriba (no solo al brotar)
	print("== Aukin: atrapa a quien entra con los tallarines arriba")
	yield(wait(2.0), "completed")                     # deja que se borren los tallarines anteriores
	reset(aukin, Vector2(400, 440))
	reset(rival, Vector2(700, 440))
	rival.invulnerable = true                         # no puede ser atrapado mientras suben
	yield(wait(0.3), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.6), "completed")                     # ya están arriba (suben a ~0.32 s)
	check("Aukin: invulnerable mientras suben, no queda atrapado", rival.wrapped_time <= 0.0)
	rival.invulnerable = false                        # ahora entra en la zona con los tallarines arriba
	guard = 0
	while rival.wrapped_time <= 0.0 and guard < 30:
		yield(wait(0.02), "completed")
		guard += 1
	check("Aukin: quien entra con los tallarines arriba queda atrapado", rival.wrapped_time > 0.0 and rival.frozen, "espera=%.2fs" % (guard * 0.02))
	yield(wait(2.0), "completed")
	check("Aukin: al soltarlo, no vuelve a quedar atrapado en ese mismo ataque", not rival.frozen and rival.wrapped_time <= 0.0)

	# esquivar caminando fuera de la zona durante el aviso
	print("== Aukin: se esquiva saliendo de la zona")
	reset(aukin, Vector2(400, 440))
	reset(rival, Vector2(700, 440))
	yield(wait(0.4), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.3), "completed")
	rival.position.x = 820.0                      # sale de la zona (ancho 96) durante el aviso
	yield(wait(2.2), "completed")
	check("Aukin: apartándose a tiempo no recibe daño ni queda atrapado", rival.percent == 0.0 and not rival.frozen, "percent=%s" % rival.percent)

	# esquivar en el aire (más alto que los tallarines)
	print("== Aukin: se esquiva estando alto")
	reset(aukin, Vector2(400, 440))
	reset(rival, Vector2(700, 440))
	yield(wait(0.4), "completed")
	yield(press("p1_special"), "completed")
	yield(wait(0.3), "completed")
	rival.position.y = 440.0 - 200.0
	rival.frozen = true                           # lo mantiene en el aire durante el agarre
	yield(wait(0.7), "completed")                 # aviso 0.75 s desde que brotaron: ya subieron
	yield(wait(0.45), "completed")
	rival.frozen = false
	check("Aukin: en el aire, por encima de los tallarines, no lo atrapan", rival.percent == 0.0 and rival.wrapped_time <= 0.0, "percent=%s" % rival.percent)
	yield(wait(1.5), "completed")

	# sin rival no se puede usar
	print("== Aukin: sin rival vivo no se activa")
	reset(aukin, Vector2(400, 440))
	rival.state = rival.State.DEAD
	aukin.special_timer = 0.0
	check("Aukin: _can_special() es falso sin rival", not aukin._can_special())
	rival.state = rival.State.NORMAL

	print("")
	print("RESULTADO: %d fallos" % fails)
	quit(1 if fails > 0 else 0)
