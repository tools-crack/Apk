# 02 · Ejecutar el juego y controles

## Requisitos

- **Godot 3.5.3** (no sirve la 4.x: el proyecto usa sintaxis de Godot 3).
- Nada más. Todos los recursos vienen incluidos.

## Abrir y ejecutar

1. Abre Godot 3.5.3 y pulsa **Importar**.
2. Selecciona el archivo `project.godot` de la carpeta del proyecto.
3. La primera vez Godot importa los sprites, sonidos y músicas. Tarda unos segundos.
4. Pulsa **F5** (o el botón ▶). La escena principal es el menú (`scenes/ui/MainMenu.tscn`).

> Si cambias archivos desde fuera de Godot (por ejemplo, regeneras los sprites con Python),
> cierra y vuelve a abrir el proyecto para que reimporte.

## Menú principal

| Botón | Qué hace |
|---|---|
| **Jugar · 2 jugadores** | Va a la selección. Los dos jugadores eligen y luchan. |
| **Práctica · vs muñeco** | Va a la selección. P2 es un muñeco que no se mueve ni ataca. |
| **WiFi local (próximamente)** | Deshabilitado. Ver [12](12_MULTIJUGADOR_WIFI.md). |
| **Salir** | Cierra el juego. |

Se navega con las flechas del teclado (o el ratón) y se confirma con Enter.

## Controles

Los dos jugadores usan **el mismo teclado**, cada uno con su mitad:

| Acción | Jugador 1 | Jugador 2 |
|---|---|---|
| Mover izquierda | **A** | **←** |
| Mover derecha | **D** | **→** |
| Saltar (y doble salto) | **W** | **↑** |
| Bajar / atravesar plataforma | **S** | **↓** |
| Golpe básico | **F** | **K** |
| Habilidad especial | **G** | **L** |

Otras teclas:

| Tecla | Dónde | Qué hace |
|---|---|---|
| **Esc** | Combate | Vuelve al menú |
| **Esc** | Selección | Vuelve al menú |
| **Enter** | Fin de partida | Revancha |

### Selección de personajes

| Acción | Jugador 1 | Jugador 2 |
|---|---|---|
| Cambiar personaje | **A / D** | **← / →** |
| Confirmar ("listo") | **F** | **K** |
| Cancelar confirmación | **G** | **L** |

Cuando los dos están listos aparece el aviso "¡A LUCHAR!" y se entra a la arena.
En **práctica**, P2 es el muñeco: usa automáticamente el personaje siguiente al de P1.

## Cómo se juega

- Cada luchador empieza con **3 vidas** (stocks) y **0 % de daño**.
- Cada golpe **sube el porcentaje**. Cuanto más alto, **más lejos vuela** el luchador.
- Si un luchador **sale de la pantalla** (por los lados, por arriba o por abajo), pierde una vida.
- Cuando se queda sin vidas, el otro gana. Se ve en el mensaje "¡GANA P1!".
- La **barra del especial** del marcador se llena mientras recarga. Cuando está llena, el especial vuelve a estar disponible.
- Al empezar hay una cuenta atrás: **3, 2, 1, ¡YA!**. Hasta el "¡YA!" nadie puede moverse.

## Cambiar las teclas

**Dentro del juego:** menú principal > **Controles**. Pulsa la acción, luego la tecla nueva
(Esc cancela; si la tecla ya está en uso, las dos acciones se intercambian). Se guarda sola en
`user://controles.cfg` y todos los textos de ayuda se actualizan.

**Teclas de fábrica (para el desarrollador):** Proyecto > Ajustes del proyecto > **Mapa de entrada**,
acciones `p1_left`, `p1_attack`... (o `p2_*`). El menú "Restaurar" vuelve a estas.
Para borrar lo guardado: botón "Restaurar todo" o borra `controles.cfg` (Proyecto > Abrir carpeta de datos del proyecto).
