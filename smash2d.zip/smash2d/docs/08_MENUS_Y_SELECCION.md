# 08 · Menús y selección de personajes

Las pantallas están en `scenes/ui/`, con sus scripts en `scripts/ui/`.

## Aspecto de los botones (tema + animación)

- **Tema global:** `resources/ui_theme.tres` (activado en `project.godot > gui > theme > custom`).
  Da a **todos** los `Button` y `ProgressBar` su aspecto: textura 9-patch con relieve y rayas
  (`assets/ui/btn_normal|hover|pressed|disabled|focus.png`), borde dorado al enfocar, texto con sombra.
  Se regenera con `python3 tools/make_ui.py` (ahí están los colores).
- **Animación:** `scripts/ui/AnimButton.gd`, para poner como script de un `Button`. Crece al pasar
  el mouse / recibir foco, "se aplasta" al pulsar, hace sonido y tiene `pop_in(delay)` para entrar
  animado. El mouse sobre un botón le da el foco, así teclado y mouse se ven igual.
  Para un botón nuevo con estas animaciones: crea un `Button` y arrástrale ese script.

## Reglas para que los textos NO se monten unos sobre otros

- Los menús usan **contenedores** (`VBoxContainer`, `HBoxContainer`, `MarginContainer`), no posiciones sueltas.
- Los textos largos (descripción de personajes) van en una `Label` con caja fija, `autowrap` y
  `clip_text`: si algo no cabe se recorta, nunca invade al vecino. Si añades un texto largo, usa
  `font_tiny.tres` (16 px) o agranda la caja.
- Fuentes: `font_tiny` 16, `font_small` 20, `font_med` 30, `font_pct` 54 (el %), `font_big` 72.
- `godot --path . -s tools/test_ui_layout.gd` (ver doc 11) mide cada texto y falla si algo se desborda o se monta.

## Menú principal (`MainMenu`)

- **Escena:** `scenes/ui/MainMenu.tscn`
- **Script:** `scripts/ui/MainMenu.gd`
- **Qué tiene:** fondo, icono, título (que "respira"), subtítulo, botones (Jugar, Práctica,
  Controles, WiFi —deshabilitado—, Salir) y las teclas actuales de cada jugador.

Los botones están en `Margin/Col/ButtonsRow/Buttons`. Para añadir uno nuevo:

1. Duplica un botón dentro de `Buttons` (ya trae `AnimButton`).
2. En `MainMenu.gd`, en `_ready()`, conéctalo: `btn_nuevo.connect("pressed", self, "_on_nuevo")`.
3. Añade su función `_on_nuevo()`.

## Menú de controles (`Controls`)

- **Escena:** `scenes/ui/Controls.tscn`, **script:** `scripts/ui/Controls.gd`
- Dos columnas (P1 y P2) con las 6 acciones. Pulsa una fila y luego la tecla nueva; **Esc cancela**.
  Si la tecla ya la usaba otra acción, **se intercambian**. Hay botones para restaurar P1, P2 o todo.
- Las teclas se guardan en `user://controles.cfg` (autoload `Keybinds`, `scripts/core/Keybinds.gd`).
  Los textos de ayuda del menú, de la selección y del HUD de la arena las leen de ahí.
- Para cambiar las teclas **de fábrica** edita el Mapa de entrada de Godot (`p1_*`, `p2_*`);
  `Keybinds` las toma como valores por defecto. Esc está reservada.

## Selección de personajes (`CharSelect`)

- **Escena:** `scenes/ui/CharSelect.tscn`
- **Script:** `scripts/ui/CharSelect.gd`
- **Qué tiene:** fondo, velo oscuro, título, dos paneles (`Pick1` y `Pick2`), un "VS" entre
  ellos, un pie con la ayuda y un banner "¡A LUCHAR!".

La lógica:

1. Cada panel muestra un personaje de `Game.ORDER`.
2. Cuando **los dos** están listos, `CharSelect` guarda la elección en `Game.selected`,
   muestra el banner y, a los 0.7 segundos, pasa a la selección de escenario.
3. Esc vuelve al menú (mientras no esté arrancando la partida).
4. En **práctica**, `Pick2` se bloquea como muñeco y sigue automáticamente al personaje
   siguiente al de P1 (`_process`).

## Selección de escenario (`StageSelect`)

- **Escena:** `scenes/ui/StageSelect.tscn`, **script:** `scripts/ui/StageSelect.gd`
- Una tarjeta por cada escenario de `Game.STAGES` + "Aleatorio". Se elige con flechas, con las teclas
  izquierda/derecha de cualquier jugador o con el mouse; se confirma con Enter, clic o la tecla de golpe.
  El fondo de la pantalla cambia al del escenario enfocado. Esc vuelve a la selección de personajes.
- Guarda `Game.stage_index` y entra a la arena. La revancha (Enter) repite el mismo escenario.

## Panel de un jugador (`PickPanel`)

- **Escena:** `scenes/ui/PickPanel.tscn`
- **Script:** `scripts/ui/PickPanel.gd`

Cada panel es independiente: lee **sus propias teclas** según `player_id`
(`p1_*` o `p2_*` del Input Map). Muestra:

| Elemento | Dónde | Cambia con |
|---|---|---|
| Marco y barra superior | `AccentBar`, borde del panel | color del personaje |
| Retrato | `PortraitFrame/Portrait` | personaje elegido |
| Nombre | `CharName` | personaje elegido |
| Chip del especial | `SpecialChip` | personaje elegido |
| Descripción | `Desc` | personaje elegido |
| Puntos ●○ | `Dots` | posición en la lista |
| Insignia "¡LISTO!" | `ReadyBadge` | confirmado o no |

El estilo (esquinas redondeadas, sombra, colores) se crea **por código** en `_build_style()`
con `StyleBoxFlat`. Si quieres cambiar la forma de los paneles, edita esa función.
Si quieres cambiar el tamaño o la posición, edita `PickPanel.tscn`.

### Cambiar los textos de ayuda

Se arman solas con las teclas actuales (`PickPanel._update_hint`, usa `Keybinds`).
Si cambias las teclas, cámbialas ahí también.

## HUD durante el combate (`PlayerPanel`)

- **Escena:** `scenes/ui/PlayerPanel.tscn`
- **Script:** `scripts/ui/PlayerPanel.gd`

Muestra el porcentaje (que se pone rojo al subir), las vidas (●●●) y la barra de recarga
del especial. La tecla que aparece junto a "ESPECIAL" se lee del **Input Map**, así que
si cambias la tecla, el HUD se actualiza solo.

## Cambiar el aspecto de todo a la vez

Los colores de los textos están en cada escena (`custom_colors/font_color`). Las fuentes
están en `resources/font_*.tres` (tamaños 20, 30 y 72): si cambias una fuente ahí, cambia
en todas las pantallas que la usen.

## Orden de los personajes en la selección

El orden lo decide el campo `order` de cada ficha (`characters/*.tres`):
menor número, más a la izquierda. Si dos personajes tienen el mismo número, se ordenan por id.
