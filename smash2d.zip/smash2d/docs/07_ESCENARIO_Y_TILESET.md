# 07 · Escenario y tileset

El escenario tiene **tres partes separadas**, y es importante no confundirlas:

| Parte | Qué es | Dónde está | Quién la hace |
|---|---|---|---|
| **Fondo** | Cielo, nubes, montañas. Solo se ve. | `assets/sprites/stage/bg.svg` | Se dibuja a mano (SVG) |
| **Dibujo del suelo y plataformas** | Lo que se ve de la tierra y el pasto. | `TileMap` en `scenes/stages/*.tscn` | Tileset generado |
| **Colisión** | Lo que realmente pisan los luchadores. | `StaticBody2D` en `scenes/stages/*.tscn` | Puntos fijos |

**La colisión y el dibujo son independientes.** El tileset solo cambia cómo se ve el
suelo. Si quieres cambiar dónde se puede pisar, mueve el `StaticBody2D`. Si quieres
cambiar cómo se ve, cambia el `TileMap` o el tileset.

## Escenarios disponibles

Cada escenario es **una escena aparte** en `scenes/stages/` (su nodo raíz se llama `Stage`).
`Arena.gd` instancia la que se eligió (`Game.current_stage()`), así que `Arena.tscn` ya no
tiene suelo ni fondo propios.

| Escenario | Escena | Fondo | Tileset | Forma |
|---|---|---|---|---|
| Pradera soleada | `Pradera.tscn` | `bg.svg` | `stage_tileset.tres` | suelo de 15 tiles + 2 plataformas |
| Desierto al atardecer | `Desierto.tscn` | `bg_desierto.svg` + `nubes_desierto.svg` (se desplaza) | `stage_tileset_desierto.tres` | suelo de 13 tiles + 2 plataformas + 1 alta al centro |
| Azotea nocturna | `Azotea.tscn` | `bg_azotea.svg` + `estrellas_azotea.svg` (titila) | `stage_tileset_azotea.tres` | suelo de 11 tiles + 2 plataformas + 1 alta al centro |

El jugador los elige en la pantalla **StageSelect** (después de elegir personajes), o
"Aleatorio". La lista está en `Game.STAGES` (`scripts/core/Game.gd`).

### Añadir un escenario nuevo

1. Duplica una escena de `scenes/stages/` (por ejemplo `Desierto.tscn`) y cámbiale el fondo, el
   tileset y la posición / tamaño de los nodos.
2. Regla de oro: **el `TileMap` y el `StaticBody2D` deben coincidir**. Para una plataforma de
   `cols` tiles con centro en `cx` y superficie en `y`: `StaticBody2D` en `(cx, y)` con
   `RectangleShape2D` de extents `(cols*24, 6)`, y su `TileMap` en `(cx - cols*24, y - 6)`.
   El suelo igual, con extents `(cols*24, 30)` y superficie en y = 480.
3. Mantén el suelo cubriendo los puntos de aparición (x = 500 y 780) y las plataformas a
   menos de ~230 px de salto entre sí.
4. Añádelo a `Game.STAGES` (id, nombre, escena, imagen de vista previa, descripción).
5. Corre `godot --path . -s tools/test_escenarios.gd`: comprueba todo lo anterior solo.

Capas animadas: un `Sprite` con `scripts/stage/Drift.gd` (`speed` = nubes que avanzan,
`twinkle` = brillo que titila).

## Piezas de un escenario

Abre por ejemplo `scenes/stages/Pradera.tscn`:

| Nodo | Tipo | Función |
|---|---|---|
| `Background` | Sprite | El fondo (z = -10) |
| `GroundTiles` | TileMap | Dibuja el suelo principal |
| `Ground` | StaticBody2D | Colisión del suelo principal (capa 1) |
| `PlatformLeftTiles` | TileMap | Dibuja la plataforma izquierda (4 × 2 tiles) |
| `PlatformLeft` | StaticBody2D | Colisión de la plataforma izquierda (capa 3, de un solo sentido) |
| `PlatformRightTiles` / `PlatformRight` | | Igual, a la derecha |

Medidas de la **Pradera** (píxeles, pantalla de 1280 × 720):

- Suelo principal: de x = 280 a 1000, con la superficie en **y = 480**.
- Plataformas: de x = 304 a 496 (izquierda) y de x = 784 a 976 (derecha), superficie en **y = 350**.
- Cada tile mide **48 × 48**.

## El tileset

`resources/stage_tileset.tres` apunta a `assets/sprites/stage/tileset_atlas.png`,
una imagen con 12 tiles en 4 columnas × 3 filas:

```
 fila 0 (césped):   top_left  top_mid  top_mid_b  top_right
 fila 1 (tierra):   mid_left  mid     mid_b      mid_right
 fila 2 (base):     bot_left  bot_mid  bot_right  top_mid_c
```

- **`top_*`**: la capa de pasto de arriba. Las esquinas (`top_left`, `top_right`) están redondeadas.
- **`mid_*`**: la tierra del medio.
- **`bot_*`**: la base de tierra oscura. `bot_left` y `bot_right` tienen las esquinas redondeadas,
  útil para las plataformas que flotan.
- `top_mid_c` es pasto con florecitas (blanca, amarilla y rosa). Sale menos que las otras.
- `top_mid` y `top_mid_b` (y `mid` y `mid_b`) son variantes: el script las alterna al azar
  para que el pasto no se vea repetido.

## Cómo se rellena un TileMap

Cada TileMap tiene el script `scripts/stage/StageTiles.gd`, que lo rellena al cargar la
escena. Se configura con tres campos en el Inspector:

| Campo | Qué hace |
|---|---|
| `cols` | Cuántos tiles de ancho |
| `rows` | Cuántos tiles de alto (la fila de arriba siempre es césped) |
| `floating` | `true` = la fila de abajo usa esquinas redondeadas (plataforma flotante) |

Para hacer una plataforma nueva:

1. Duplica `PlatformLeftTiles` y su `PlatformLeft` (el StaticBody2D).
2. Coloca el TileMap en la **esquina superior izquierda** de la colisión. Si el
   StaticBody2D está en `(x, y)` y su `extents` es `(mitad_ancho, 6)`, el TileMap va en
   `(x − mitad_ancho, y − 6)`. Así la capa de pasto queda justo sobre la línea de pisar.
   Por ejemplo, `PlatformLeft` está en (400, 356) con `extents` (96, 6), y su TileMap en (304, 350).
3. Ajusta `cols` y `rows` para que cubran el ancho y alto de la colisión
   (cada tile son 48 px: 4 tiles = 192 px = 2 × 96).
4. Cambia el `CollisionShape2D` para que el ancho coincida (`extents.x` = ancho/2).

Los números exactos de las plataformas están en `scenes/stages/*.tscn`, como referencia.

## Los tres tilesets

`python3 tools/make_tileset.py` genera los tres (pradera, desierto y azotea); los tiles se llaman igual en todos,
así que `StageTiles.gd` funciona con cualquiera. Para uno solo: `python3 tools/make_tileset.py desierto`.
Los fondos nuevos se generan con `python3 tools/make_stages.py`.

## Cómo regenerar el tileset

```bash
python3 tools/make_tileset.py
```

Necesita **Pillow** (`pip install pillow`). Genera de nuevo el PNG y el `.tres`.
El estilo es "pradera soleada": pasto con borde ondulado y brillo, tierra cálida con
estratos y piedritas. Los tiles de en medio **no llevan contorno** y sus detalles dan la
vuelta por los bordes, así que encajan sin costuras; solo los tiles del borde (esquinas,
lados y base) tienen contorno oscuro. Se dibuja al cuádruple y se reduce para suavizar.
Si cambias los colores de la sección `PALETA` del script (`GRASS_*`, `DIRT_*`, `PEBBLE*`), verás el cambio al
reimportar. Después de regenerar, cierra y abre el proyecto en Godot.

Los tiles tienen un **sangrado de 2 px** alrededor de cada uno, para que al escalar no
aparezcan líneas finas entre tiles. No lo quites.

## Límites de la arena (zona de KO)

El escenario no tiene paredes: los luchadores que salen de la pantalla pierden una vida.
Esa zona está en `scripts/core/Config.gd`:

```gdscript
const BLAST_LEFT := -260.0
const BLAST_RIGHT := 1540.0
const BLAST_TOP := -320.0
const BLAST_BOTTOM := 900.0
```

Si agrandas el mapa, agranda también estos valores, o los luchadores morirán al salir del nuevo escenario.

## Cámara

La cámara (`Camera2D` en `Arena.tscn`) no se mueve: es fija. Lo único que hace es temblar
(`shake`) cuando hay golpes fuertes. Ver [09 · Configuración global](09_CONFIGURACION_GLOBAL.md).
