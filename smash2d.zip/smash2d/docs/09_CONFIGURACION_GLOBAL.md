# 09 · Configuración global (Config.gd)

`scripts/core/Config.gd` es el **único lugar** para los números que valen para todo el
juego y no para un personaje concreto. Cualquier script puede leerlos como
`Config.NOMBRE`.

Para cambiar un valor, ábrelo en Godot, cámbialo y guarda. Como son constantes, cualquier
cambio se aplica al ejecutar el juego.

## Pantalla y capas de colisión

| Constante | Valor | Qué es |
|---|---|---|
| `SCREEN_SIZE` | 1280 × 720 | Tamaño de la pantalla. Debe coincidir con Proyecto > Ajustes > Display. |
| `BIT_GROUND` | 1 | Capa del suelo. |
| `BIT_FIGHTER` | 2 | Capa de los luchadores. |
| `BIT_PLATFORM` | 4 | Capa de las plataformas. |
| `MASK_FIGHTER_NORMAL` | 5 | Lo que pisa un luchador normal: suelo + plataformas. |
| `MASK_FIGHTER_DROP` | 1 | Lo que pisa al atravesar plataformas: solo suelo. |

Las capas corresponden a los nombres de Proyecto > Ajustes > Nombres de capas > 2D Physics.
Si cambias los nombres, recuerda que los números siguen siendo los mismos.

## Zona de KO

| Constante | Valor | Qué es |
|---|---|---|
| `BLAST_LEFT` | −260 | Límite izquierdo. Pasarlo = KO. |
| `BLAST_RIGHT` | 1540 | Límite derecho. |
| `BLAST_TOP` | −320 | Límite superior. |
| `BLAST_BOTTOM` | 900 | Límite inferior (caer al vacío). |

## Partida

| Constante | Valor | Qué es |
|---|---|---|
| `SPAWN_POINTS` | [(500, 440), (780, 440)] | Dónde empiezan P1 y P2. |
| `COUNTDOWN_SECONDS` | 3 | Cuenta atrás antes del "¡YA!". |
| `GO_MESSAGE_TIME` | 0.8 | Cuánto se ve el "¡YA!". |
| `PRACTICE_DUMMY_STOCKS` | 99 | Vidas del muñeco en práctica. |

## Reaparición

| Constante | Valor | Qué es |
|---|---|---|
| `RESPAWN_POSITION` | (640, 120) | Dónde reaparece (cae desde arriba, al centro). |
| `RESPAWN_DELAY` | 1.6 | Segundos fuera de juego tras un KO. |
| `RESPAWN_INVULNERABLE_TIME` | 2.0 | Segundos parpadeando sin poder ser golpeado. |

## Daño y empuje

La fórmula del empuje es:

```
velocidad_del_empuje = empuje_del_golpe × (1 + porcentaje / KNOCKBACK_GROWTH)
```

| Constante | Valor | Qué es |
|---|---|---|
| `KNOCKBACK_GROWTH` | 90 | Cuanto **menor**, más lejos vuela un rival con daño alto. |
| `HITSTUN_BASE` | 0.2 | Aturdimiento mínimo (s). |
| `HITSTUN_PER_PERCENT` | 0.002 | Aturdimiento extra por cada % de daño. |
| `HITSTUN_MAX` | 0.55 | Aturdimiento máximo (s). |

Ejemplo: con `KNOCKBACK_GROWTH = 90`, un rival al 90 % recibe el empuje multiplicado por 2.
Con el 180 %, por 3.

## Cuerpo del luchador

| Constante | Valor | Qué es |
|---|---|---|
| `FEET_OFFSET` | 40 | Distancia del centro del luchador a sus pies. |
| `HITBOX_OFFSET` | (38, −6) | Dónde está el área de golpe, delante del luchador. |
| `KO_SPARK_MARGIN` | 30 | Distancia del destello de KO al borde de la pantalla. |

## Sensación de juego

| Constante | Valor | Qué es |
|---|---|---|
| `AIR_JUMP_MULTIPLIER` | 0.9 | El doble salto sale al 90 % de la fuerza. |
| `AIR_BRAKE_FACTOR` | 0.5 | Cuánto frena en el aire al soltar la dirección. |
| `ATTACK_FRICTION` | 1800 | Cuánto frena al luchador mientras golpea. |
| `HURT_FRICTION_GROUND` | 900 | Frenado aturdido en el suelo. |
| `HURT_FRICTION_AIR` | 250 | Frenado aturdido en el aire (casi no frena: vuela lejos). |
| `DROP_THROUGH_TIME` | 0.25 | Segundos atravesando una plataforma al pulsar abajo. |
| `DROP_THROUGH_SPEED` | 120 | Empujón hacia abajo para empezar a atravesarla. |
| `LAND_SOUND_MIN_SPEED` | 350 | Velocidad de caída mínima para oír el golpe al aterrizar. |

## Cámara y música

| Constante | Valor | Qué es |
|---|---|---|
| `SHAKE_ON_HIT_BASE` | 4 | Temblor base al recibir un golpe. |
| `SHAKE_ON_HIT_MAX_EXTRA` | 8 | Temblor extra máximo según el daño. |
| `SHAKE_ON_HIT_PERCENT_DIV` | 25 | Cada 25 % de daño suma 1 de temblor. |
| `SHAKE_ON_KO` | 14 | Temblor al perder una vida. |
| `SHAKE_DECAY` | 45 | Cuánto baja el temblor por segundo. |
| `MUSIC_VOLUME_DB` | −9 | Volumen de la música. |

## Qué NO está en Config

- Estadísticas de un personaje (velocidad, salto, daño): van en `characters/*.tres`.
- Números atados a una animación (cuándo aparece la gaviota): están en el script del
  personaje, comentados, porque dependen del dibujo.
- Textos y colores de las pantallas: están en las escenas `.tscn`.
