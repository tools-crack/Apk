# 12 · Multijugador en red LAN (PC + Android) y controles táctiles

> **Estado: implementado.** Menú principal → **Jugar en red · LAN**.

## Cómo se juega (rápido)

1. Los dos dispositivos en la **misma WiFi** (o el PC por cable al mismo router).
2. En el PC (anfitrión): *Jugar en red · LAN → Crear partida*. Aparece su IP.
3. En el celular (cliente): *Jugar en red · LAN → Unirse*. La partida del PC sale sola en la
   lista (se descubre por broadcast UDP); si no sale, escribe la IP que muestra el PC.
4. El anfitrión elige personajes y escenario de los dos y empieza. El cliente salta solo a la arena.
5. **El anfitrión es P1 (teclado) y el cliente es P2.** Si el cliente es un celular usa los controles táctiles.
   Con revancha (Enter en el anfitrión) el cliente recarga solo.

**Cortafuegos de Windows:** permite el juego en redes privadas, o abre **UDP 7777** (partida) y
**UDP 47777** (descubrimiento). Si el PC no aparece en la lista, escribe la IP a mano: la partida igual funciona.

## Cómo funciona (para modificar)

Modelo **autoritativo del anfitrión**: solo el anfitrión simula. El cliente no tiene física ni IA:
dibuja lo que recibe. Por eso no hay "desincronizaciones" ni trampas posibles.

| Pieza | Archivo | Qué hace |
|---|---|---|
| Conexión y lobby | `scripts/core/Net.gd` (autoload `Net`) | ENet (UDP, 7777, compresión FastLZ), descubrimiento, `net_begin/net_rematch/net_client_ready`, desconexiones (diferidas con `call_deferred` para no caerse dentro de la señal) |
| Sincronización | `scripts/net/NetSync.gd` | Entradas cliente→anfitrión, estado anfitrión→cliente, interpolación, sonidos |
| Menú | `scripts/ui/LanMenu.gd`, `scenes/ui/Lan.tscn` | Pantallas por código; guarda la última IP en `user://lan.cfg` |
| Táctil | `scripts/ui/TouchControls.gd` | Stick flotante + GOLPE/ESPECIAL/SALTO + salir (doble toque) |
| Integración | `scripts/stage/Arena.gd` (`_setup_net`, `_add_touch`) | Crea NetSync y los controles |

### Por qué casi no hay lag

- **Entradas:** el cliente manda sus botones **cada paso de física** y cada paquete repite los últimos 4 pasos
  (por UDP no fiable: si se pierde uno, el siguiente trae lo que faltó). Un golpe nunca se pierde.
- **Estado:** el anfitrión manda un paquete por paso, **sin esperar confirmaciones** (no hay retransmisiones que atasquen).
  Solo viajan los datos que **cambian** (variables de cada nodo por diferencias; el estado completo se repite cada 30 pasos
  y al aparecer una entidad). Un paquete típico pesa ~1.3 KB, bajo el MTU de WiFi.
- **Dibujo:** el cliente dibuja ~2 pasos (33 ms) atrás e **interpola** posición/escala/rotación entre paquetes:
  se ve fluido aunque lleguen con jitter. Si el WiFi va a tirones sube `NetSync.INTERP_DELAY` (3–4); si es muy bueno, bájalo.
- **Sonidos:** el anfitrión manda eventos de sonido y el cliente los reproduce cuando le toca en la línea de tiempo.
- **Pantalla del anfitrión:** no espera nada del cliente (solo la cuenta atrás espera a que cargue).

Lo que se siente en el cliente: su propio personaje responde con el retraso del viaje de ida y vuelta (~ 10–30 ms en WiFi
normal) + 33 ms de interpolación. No hay predicción local, así que con WiFi malo (>80 ms) se nota: acerca el celular al router
o usa la banda de 5 GHz.

### Qué se replica

Todo lo de los luchadores y de los efectos (gaviotas, rocas, tallarines, humo, pinchos, anzuelo...) se copia **solo**:
propiedades de nodos (posición, animación, visible...) y **todas las variables de script** (`percent`, `state`, `vidas`...).
Si agregas un efecto nuevo en un `.tscn` y lo añades a `fighters_root` (`add_child`), ya se replica: no hay que tocar la red.
Excluidas: `net_remote`, `net_held`, `net_just`, `net_puppet`.
Reglas para que funcione bien:
- Los efectos deben ser **escenas** (`.tscn`): un nodo creado solo con `Node2D.new()` no se replica.
- Las variables que apunten a nodos replicados (p. ej. `shooter`) viajan como referencia; a recursos (fichas) viajan por ruta.
- En un cliente los luchadores y efectos son "fantasmas": `_physics_process`/`_process` están apagados y las áreas no detectan.
  Si necesitas dibujar algo en el cliente a partir de variables, hazlo en `_draw()` o `_tick_fx()`.

## Controles táctiles

- **Izquierda:** stick **flotante**: toca en cualquier parte de la mitad izquierda y ahí aparece; si arrastras más allá del borde,
  el stick **sigue al dedo**. ←/→ mover, ↓ bajar de plataforma, ↑ saltar. Con histéresis (no parpadea en el borde).
- **Derecha:** GOLPE (grande), ESPECIAL, SALTO. Se elige el botón más cercano al dedo (tolerante a dedos gordos).
- **Multitoque real:** cada dedo se sigue por índice; mover + saltar + golpear a la vez.
- **Vibración corta** al tocar un botón (Android).
- **Salir:** botón ⏸ arriba a la derecha, hay que tocarlo **dos veces** (no se sale por accidente). El botón "atrás" de Android hace lo mismo que Esc.
- Constantes de posición/tamaño al inicio de `TouchControls.gd` (`STICK_R`, `BUTTONS`...). La pantalla es de 1280x720 lógicos.
- Prueba en PC: abre el juego con `--touch` y usa el mouse como un dedo.
- Jugando en un celular sin red (modo local) también aparecen los controles para P1.

## Exportar

### Windows (PC anfitrión, incluso Windows 7 de 32 bits)
Ya hay un preset en `export_presets.cfg` ("Windows 32 bits (Win7)", exe único con el `.pck` embebido):
Godot 3.5.3 → *Proyecto → Exportar* (necesita las plantillas de exportación 3.5.3 instaladas) →
`build/Smash2D_win32.exe`. Funciona con OpenGL ES 2 (GLES2), que es lo que usa el proyecto.
Un exe 32 bits corre también en Windows de 64 bits.

### Android (Redmi 12C, etc.)
**Sin instalar nada (GitHub Actions, gratis):** sube la carpeta del proyecto a un repositorio de GitHub, ve a la pestaña *Actions → APK Android → Run workflow* y descarga el artefacto `Smash2D-apk`. El workflow está en `.github/workflows/android.yml` y el preset en `export_presets.cfg` (ya con Internet/Vibrate). No se pudo probar desde aquí.

O a mano:
No se puede exportar desde Windows 7 de 32 bits (el SDK de Android actual no corre ahí). Opciones:
1. Pedir prestado un PC con Windows 10/11 de 64 bits (o Linux/Mac) y hacerlo una vez:
   instalar **JDK 11**, **Android SDK** (Platform-Tools, Build-Tools 30+, Platform 30+), **plantillas de exportación 3.5.3**;
   en Godot: *Editor → Configuración del editor → Export → Android* (rutas del SDK y del debug.keystore);
   *Proyecto → Exportar → Añadir → Android*: activar **Use Custom Build = no**, arquitectura **armeabi-v7a y arm64-v8a**,
   permisos **Internet** (obligatorio para la red) y **Vibrate**, y exportar el `.apk`.
2. Copiar el `.apk` al celular, permitir "instalar de orígenes desconocidos" e instalar.
El proyecto ya trae pantalla **horizontal** y el botón "atrás" configurado.

El celular 20:9 mostrará barras negras a los lados (el juego mantiene 16:9 para que nada se corte).

## Límites conocidos

- Solo 2 jugadores (1 anfitrión + 1 cliente).
- El anfitrión elige los personajes de ambos.
- Sin predicción del lado del cliente: la latencia de ida y vuelta se nota si el WiFi es malo.
- No se probó en un celular real ni en WiFi real; sí en pruebas automáticas de dos procesos (`tools/probar_red.sh`).

## Probar

```bash
bash tools/probar_red.sh /ruta/a/godot      # anfitrión + cliente en una misma máquina, deben terminar "TODO OK"
godot --path . -s tools/test_tactil_lan.gd  # multitoque, stick y menú LAN
```
