# 10 · Sprites, sonido y música

Todo el material visual y sonoro se genera con scripts de `tools/`. Así puedes
regenerarlo o cambiarlo sin dibujar a mano. También puedes reemplazar cualquier archivo
por el tuyo.

## Sprites de los personajes (`tools/make_sprites.py`)

Dibuja a los stickman como **SVG**, cuadro por cuadro. Solo usa Python estándar.

```bash
python3 tools/make_sprites.py
```

Qué genera:

- `assets/sprites/<personaje>/<animación>_<n>.svg`: cada cuadro de cada animación.
- `assets/sprites/<personaje>/portrait.svg`: el retrato grande de la selección.
- `resources/<personaje>_frames.tres`: el `SpriteFrames` que usa Godot (lista de cuadros, velocidad y bucle).
- `assets/sprites/gull/`: los 3 cuadros de la gaviota (aleteo).
- `assets/sprites/stage/`: fondo y dibujos de plataformas (las del tileset van por `make_tileset.py`).
- `assets/sprites/fx/`: polvo, plumas, estrella del golpe y montículo.
- `icon.svg`: el icono del juego.

### Animaciones y velocidad

| Animación | Cuadros | Velocidad (fps) | Bucle |
|---|---|---|---|
| `idle` | 2 | 3 | sí |
| `run` | 6 | 12 | sí |
| `jump` | 1 | 1 | no |
| `fall` | 1 | 1 | no |
| `hurt` | 1 | 1 | no |
| `attack` | 3 | 12 | no |
| `special` (Gaviotero y personajes nuevos) | 3 | 8 | no |
| `dive` (Topo) | 5 | 12 | no |
| `emerge` (Topo) | 5 | 14 | no |

Las duraciones del código están calculadas sobre estos números. Por ejemplo, el
hundimiento del Topo dura `5 cuadros / 12 fps ≈ 0.42 s`, que es `DIVE_TIME`.
**Si cambias los cuadros o la velocidad, revisa esas constantes** en `Topo.gd` y `Gaviotero.gd`.

### Cómo se dibuja un personaje

El estilo es de muñeco de dibujos animados: extremidades gruesas con dos tonos (las de atrás más
oscuras), torso claro, manos de color piel, zapatos redondos, pelo de picos y anteojos. Se dibuja
en `draw_stickman()` de `tools/make_sprites.py`.

Cada pose define dónde están las caderas, los pies y las manos. El script calcula
las rodillas y los codos con **cinemática inversa** (así las articulaciones siempre
quedan en un lugar natural). Para una pose nueva, copia una de las existentes (`idle_pose()`, `run_pose()`,
las listas `ATTACK` y `SUMMON`, o `JUMP`, `FALL`, `HURT`) y cambia las coordenadas.

### Limitaciones importantes del SVG en Godot 3

Godot 3 importa los SVG con una librería que **no soporta** `clipPath`, filtros ni máscaras.
Por eso el "hundimiento en la tierra" se hace **recortando la geometría** en Python (`clip`),
no con máscaras. Si añades efectos SVG, usa solo formas básicas, colores sólidos y `opacity`.

### Aspecto de cada personaje

`CHARACTERS` (en `make_sprites.py`, para Gaviotero y Topo) y `tools/personajes_extra.json` (para
los creados con `nuevo_personaje.py`) guardan el aspecto de cada uno. Todos los campos son
opcionales salvo `color`; lo que falte usa el aspecto por defecto (pelo naranja de picos y anteojos):

| Campo | Qué es |
|---|---|
| `color` | color de acento (menús y HUD); si no hay `shirt`, también la camiseta |
| `shirt` / `pants` / `shoe` / `skin` | camiseta o abrigo, pantalón, zapatos, piel |
| `hair` / `hair_style` | color del pelo; estilo `"spiky"`, `"tuft"` (pelo ralo) o `"none"` |
| `glasses` | `"round"` (anteojos), `"goggles"` (antiparras negras) o `null` |
| `hat` | `sailor`, `miner`, `chef`, `rock`, `cap`, `spiky`, `fisher` o `null` |
| `claws` | `true` = garras en las manos |
| `build` | `"normal"` o `"stocky"` (más ancho y bajo) |

El **Topo** es el "Mole Man": bajo y ancho, antiparras negras, pelo ralo, abrigo raído y garras.
Tras editar un aspecto, ejecuta `python3 tools/make_sprites.py` y reabre el proyecto en Godot.

`nuevo_personaje.py` solo escribe `color` y `hat`; añade el resto a mano en el JSON si quieres.

## Sonidos (`tools/make_audio.py`)

Todos los efectos se **sintetizan** por código (no son grabaciones). Requiere **numpy**.

```bash
python3 tools/make_audio.py
```

Genera en `assets/sounds/` (formato .wav):

| Archivo | Cuándo suena |
|---|---|
| `jump.wav` | al saltar |
| `land.wav` | al aterrizar desde una caída fuerte |
| `swing.wav` | al empezar un golpe básico |
| `hit.wav` | al recibir un golpe |
| `gull.wav` | al invocar la gaviota |
| `dig.wav` | al empezar a hundirse el Topo |
| `rumble.wav` | mientras viaja bajo tierra |
| `emerge.wav` | al emerger |
| `ko.wav` | al perder una vida |
| `select.wav`, `confirm.wav`, `back.wav` | menús y selección |
| `count.wav`, `go.wav` | cuenta atrás y "¡YA!" |
| `nope.wav` | intentar un especial que no se puede usar |
| `win.wav` | fin de partida |

La semilla del generador es fija (`RNG = 7`), así que regenerar produce **exactamente
los mismos sonidos**.

## Música (`tools/make_audio.py`)

Dos temas en bucle, codificados a `.ogg` con **ffmpeg** (con soporte libvorbis):

| Archivo | Uso | Tempo |
|---|---|---|
| `assets/music/menu_theme.ogg` | menú y selección | 92 BPM |
| `assets/music/battle_theme.ogg` | combate | 152 BPM |

El bucle está en el código: `Game.play_music()` activa `loop` en el stream, así que
la música no se corta al repetirse. El volumen general está en `Config.MUSIC_VOLUME_DB`.

## Reemplazar un sonido o una música por el tuyo

La forma más simple, sin tocar código:

1. Pon tu archivo **con el mismo nombre** en `assets/sounds/` (o `assets/music/`).
   Para música, debe ser `.ogg`.
2. Abre Godot y deja que reimporte.
3. Escucha el resultado.

Si quieres que un sonido concreto sea distinto solo para un personaje, cambia su
`Stream` en la escena (`scenes/fighters/<Clase>.tscn`, nodo `SfxSpecial`).

## Tileset del escenario

Ver [07 · Escenario y tileset](07_ESCENARIO_Y_TILESET.md) y `tools/make_tileset.py`
(requiere Pillow).

## Dependencias

| Script | Necesita |
|---|---|
| `make_sprites.py` | solo Python 3 |
| `make_audio.py` | Python 3, numpy, ffmpeg (con libvorbis) |
| `make_tileset.py` | Python 3, Pillow (`pip install pillow`) |
| `nuevo_personaje.py` | solo Python 3 (llama a `make_sprites.py`) |


## Música (MIDI → OGG)

Las canciones son **originales** y están escritas en código, en `tools/make_music.py`.
El proceso es: componer → guardar como **MIDI** (`assets/music/midi/*.mid`, se pueden abrir en
cualquier editor/DAW/MuseScore) → sintetizar con FluidSynth y un SoundFont General MIDI → `ffmpeg`
a **OGG** (`assets/music/*.ogg`, lo que usa el juego).

| Canción | Dónde suena | Estilo |
|---|---|---|
| `menu_theme.ogg` | menú principal y controles | aventura: guitarra, flauta, cuerdas, vibráfono |
| `select_theme.ogg` | selección de personaje y de escenario | funk: piano eléctrico, bajo slap, saxo, metales |
| `battle_theme.ogg` | combate en la Pradera | rock heroico: guitarra saturada, trompeta |
| `battle_desierto.ogg` | combate en el Desierto | sitar, shehnai, percusión, bordón de chelo |
| `battle_azotea.ogg` | combate en la Azotea | synthwave: bajo pulsante, arpegios, lead cuadrado |
| `victory_theme.ogg` | al ganar (suena una vez) | fanfarria con timbales y glockenspiel |

Cada escenario de `Game.STAGES` tiene su campo `"music"`; `Arena.gd` toca esa canción.

**Cómo cambiar una canción:** edita su función `song_*()` en `make_music.py` (acordes por compás,
melodías escritas como texto como `"5:1 3:0.5 r:1"` = grado 5 un pulso, grado 3 medio pulso, silencio
un pulso; instrumentos con `s.chan(canal, programa_GM, volumen, pan)`), y corre:

    python3 tools/make_music.py            # todas
    python3 tools/make_music.py azotea     # solo las que contienen "azotea"

Después abre el proyecto en Godot para que importe el `.ogg` nuevo.

Requisitos: Python 3, numpy, scipy, `ffmpeg`, `libfluidsynth.so.3` y un SoundFont `.sf2`
(en Debian/Ubuntu: `sudo apt install fluid-soundfont-gm libfluidsynth3` o `timgm6mb-soundfont`).
El script avisa si alguna nota de melodia en tiempo fuerte queda fuera del acorde.

Los efectos de sonido siguen con `tools/make_audio.py`.


## Shaders (efectos visuales)

Los shaders están en `assets/shaders/` (en Godot 3.5 la extensión es `.shader`). Son **código que
corre en la tarjeta gráfica**, así que cambiar un número se ve al instante, sin volver a generar nada.

| Shader | Dónde se usa | Qué hace | Parámetros útiles |
|---|---|---|---|
| `fighter_fx.shader` | cada luchador (`Fighter.gd`) | **destello blanco** al recibir un golpe; **aparición disolviéndose** al reaparecer | `flash_color`, `edge_color`, `edge_width`, `noise_scale` (en `Fighter.gd`: `FLASH_TIME`, `DISSOLVE_TIME`) |
| `heat_haze.shader` | fondo del Desierto (`Background`) | la parte baja de la imagen **tiembla** como calor | `strength`, `speed`, `frequency`, `from_y` (en `Desierto.tscn`) |
| `neon_scanlines.shader` | Azotea (`Stage/Retro/Scan`, en una capa encima del HUD) | **líneas de TV** y **viñeta** en las esquinas, con un leve tinte rosa | `line_alpha`, `line_pitch`, `vignette`, `tint`, `tint_strength` (en `Azotea.tscn`) |

Para **ajustar** un efecto: abre la escena (`Desierto.tscn`, `Azotea.tscn`) y cambia el parámetro en el
Inspector bajo `Material > Shader Params`. Para el luchador, cambia las constantes en `Fighter.gd`.

Para **añadir** un shader a un Sprite: `Inspector > Material > Nuevo ShaderMaterial > Shader > Cargar`
(elige el `.shader`). Si el efecto va en un luchador, usa `fighter_fx.shader` a través de `Fighter.gd`
(ya tiene el material creado), no pongas otro encima.

**Límite de las pruebas:** el Godot headless no dibuja ni compila shaders (no tiene tarjeta gráfica).
`tools/test_shaders.gd` comprueba que los archivos carguen y que los efectos se activen en la lógica
(destello, disolución, material puesto en el escenario), pero **el aspecto hay que verlo en el
editor**. Si un shader tiene un error de GLSL, aparece en la pestaña Salida del editor al abrirlo.
