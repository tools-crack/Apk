# Smash Stick — documentación

Bienvenido. Este proyecto es un prototipo de juego de lucha 2D tipo *Smash Bros*
hecho en **Godot 3.5.3**, con dos personajes de prueba (stickman), habilidades
especiales, selección de personajes, dos jugadores en el mismo teclado y un modo
práctica contra un muñeco.

Esta carpeta explica **todo** el proyecto: cómo está organizado, qué hace cada
archivo, cómo cambiar cosas sin romper nada y cómo crear personajes nuevos.

## Por dónde empezar

| Si quieres... | Lee |
|---|---|
| Abrir el juego y jugar | [02 · Ejecutar y controles](02_EJECUTAR_Y_CONTROLES.md) |
| Entender las carpetas y archivos | [01 · Estructura del proyecto](01_ESTRUCTURA_DEL_PROYECTO.md) |
| Entender cómo funciona el código | [03 · Arquitectura del código](03_ARQUITECTURA_DEL_CODIGO.md) |
| Cambiar velocidad, salto, daño de un personaje | [04 · Personajes y fichas (.tres)](04_PERSONAJES_Y_FICHAS.md) |
| Cambiar o crear una habilidad especial | [05 · Habilidades especiales](05_HABILIDADES_ESPECIALES.md) |
| Crear un personaje nuevo paso a paso | [06 · Crear un personaje nuevo](06_CREAR_UN_PERSONAJE_NUEVO.md) |
| Cambiar el escenario (suelo, plataformas) | [07 · Escenario y tileset](07_ESCENARIO_Y_TILESET.md) |
| Cambiar menús y pantalla de selección | [08 · Menús y selección](08_MENUS_Y_SELECCION.md) |
| Cambiar números globales (KO, empuje, cámara) | [09 · Configuración global (Config.gd)](09_CONFIGURACION_GLOBAL.md) |
| Regenerar sprites, sonidos o música | [10 · Sprites, sonido y música](10_SPRITES_SONIDO_Y_MUSICA.md) |
| Probar que todo funciona | [11 · Pruebas y depuración](11_PRUEBAS_Y_DEPURACION.md) |
| Jugar en red LAN y controles táctiles | [12 · Multijugador LAN y táctil](12_MULTIJUGADOR_WIFI.md) |
| Dudas comunes | [13 · Preguntas frecuentes](13_PREGUNTAS_FRECUENTES.md) |
| Significado de palabras técnicas | [14 · Glosario](14_GLOSARIO.md) |
| Modificar el proyecto con otra IA | [15 · Guía para otras IA](15_GUIA_PARA_OTRAS_IA.md) |
| Guía completa de la ficha `.tres` (todos los campos) | [16 · Guía de la ficha .tres](16_PARAMETROS_DE_HABILIDADES.md) |

## La regla de oro

> **Los números se cambian en un solo lugar.**
>
> - Lo que es de **un personaje** (velocidad, salto, daño, recarga...) → su archivo
>   `characters/<personaje>.tres`, editado desde el Inspector de Godot.
> - Lo que es **global** (cuánto empuja un golpe, cuánto dura el KO, la cámara...) →
>   `scripts/core/Config.gd`.
> - Lo que es **visual o sonoro** → los generadores de `tools/` (o los archivos en `assets/`).

Si te encuentras copiando un número en dos archivos, algo está mal organizado:
avísate a ti mismo y muévelo a Config.gd o a una ficha.

## Estado del proyecto

- **Funciona:** menú, selección de personajes, combate 2 jugadores (mismo teclado),
  práctica contra muñeco, dos habilidades especiales esquivables, escenario con
  tileset, KO, reaparición, fin de partida y revancha.
- **No está hecho todavía:** el modo WiFi local (el botón del menú aparece deshabilitado).
  Ver [12 · Multijugador LAN y táctil](12_MULTIJUGADOR_WIFI.md).
- **Verificado con:** pruebas automáticas en Godot 3.5.3 sin ventana (headless).
  El sonido y el aspecto visual final conviene revisarlos jugando en tu equipo.
