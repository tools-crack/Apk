# 13 · Preguntas frecuentes

## Generales

**¿Funciona con Godot 4?**
No. El proyecto está hecho para **Godot 3.5.3**. La sintaxis y los nombres (`KinematicBody2D`,
`PoolRealArray`, `move_and_slide(velocity, Vector2.UP)`, `TileMap` de 3.x) no son compatibles con 4.x.

**¿Puedo jugar con 3 o 4 personas?**
Hoy no. El juego está pensado para 2 jugadores. Añadir más requiere nuevos prefijos de
teclas (`p3_*`, `p4_*`), más paneles en la selección y más puntos de aparición en `Config`.

**¿Por qué el modo WiFi no funciona?**
Todavía no está implementado. Ver [12 · Multijugador WiFi (plan)](12_MULTIJUGADOR_WIFI.md).

## Personajes

**Edité una ficha `.tres` y no noto el cambio.**
Cierra la escena que estés viendo y vuelve a ejecutar (F5). Los cambios aplican a la siguiente partida.
Revisa también que estés editando la ficha correcta (la de `id` que corresponda).

**Creé un personaje y no aparece en la selección.**
- Revisa que su archivo esté en `characters/` y que su nombre **no** empiece por `_`.
- Verifica que la ficha tenga `scene` y `portrait` asignados.
- Ejecuta `tools/test_personajes.gd`: te dirá qué falta.

**¿Cómo cambio el número de vidas?**
En la ficha, campo `max_stocks` (1 a 9).

**¿Cómo hago que un personaje sea más pesado o más ligero?**
Sube o baja `gravity`, `move_speed` y `jump_speed` en su ficha. Ver [04](04_PERSONAJES_Y_FICHAS.md).

**¿Cómo oculto un personaje sin borrarlo?**
Renombra su `.tres` a `_nombre.tres`. Deja de aparecer, pero no se pierde.

## Especiales

**El especial del Topo no se activa.**
Es por diseño: solo funciona desde el **suelo principal**. Si estás en una plataforma o en el aire, suena el sonido de "no se puede".

**La gaviota no me golpea.**
La gaviota daña desde que sale. El aviso es lo que tarda el Gaviotero en soltarla (`special_windup`,
0.35 s por defecto: lo ves preparar el lanzamiento). Si no te toca, probablemente la saltaste. Ver [05](05_HABILIDADES_ESPECIALES.md).

**Quiero que el Topo sí golpee a alguien en una plataforma.**
Hoy no lo hace, porque su zona de golpe (radio 42 px) sale en el suelo y el rival en la plataforma queda
a unos 130 px de altura. Para cambiarlo habría que agrandar mucho el radio de `SpecialArea/Shape` en
`scenes/fighters/Topo.tscn`, o añadir un golpe extra que mire hacia arriba en `Topo.gd`.

## Sonido, música y gráficos

**No suena nada.**
- Revisa el volumen del sistema y de Godot.
- Comprueba que los archivos `.wav` y `.ogg` existan en `assets/`.
- Si acabas de regenerar, reimporta el proyecto (cerrar y abrir Godot).

**Quiero otra música.**
Reemplaza `assets/music/menu_theme.ogg` o `battle_theme.ogg` por tu archivo con el mismo nombre.
Ver [10](10_SPRITES_SONIDO_Y_MUSICA.md).

**Regeneré los sprites y siguen igual.**
Godot tiene los archivos importados en caché. Cierra y vuelve a abrir el proyecto.

**Las plataformas no se ven bien alineadas con la colisión.**
Revisa la regla de posición en [07 · Escenario y tileset](07_ESCENARIO_Y_TILESET.md).

## Pruebas y errores

**Las pruebas fallan justo después de cambiar algo.**
Primero revisa el mensaje `[FAIL]` y la línea de error de Godot. Si el fallo es de tiempos
(por ejemplo, de un salto), puede que el `yield(wait(...))` de la prueba deba ajustarse.
Ver [11 · Pruebas y depuración](11_PRUEBAS_Y_DEPURACION.md).

**Aparece un error sobre `PoolFloatArray`.**
Estás editando un `.tscn` a mano. En Godot 3 el tipo correcto es `PoolRealArray`.

## Proyecto

**¿Puedo cambiar el nombre del juego?**
Sí: `config/name` en Proyecto > Ajustes > General (o en `project.godot`).

**¿Cómo exporto el juego a un ejecutable?**
Usa Proyecto > Exportar y añade la plataforma que necesites. Este proyecto no trae un preset de
exportación configurado, así que la primera vez tendrás que crearlo desde ese menú.
