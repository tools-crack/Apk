# 11 · Pruebas y depuración

El proyecto tiene pruebas automáticas que se ejecutan **sin ventana** (headless), así que
puedes comprobar que todo funciona en segundos, sin jugar.

## Cómo ejecutarlas

Desde la carpeta del proyecto:

```bash
godot --path . -s tools/test_headless.gd
godot --path . -s tools/test_dodge_bugs.gd
godot --path . -s tools/test_personajes.gd
godot --path . -s tools/test_especiales_nuevos.gd
godot --path . -s tools/test_nanco_winkul.gd
godot --path . -s tools/test_jorge.gd
godot --path . -s tools/test_ui_layout.gd
godot --path . -s tools/test_escenarios.gd
godot --path . -s tools/test_shaders.gd
```

(Sustituye `godot` por la ruta al ejecutable headless de Godot 3.5.3 si no está en el PATH.)

Antes de la primera ejecución, abre el proyecto una vez en Godot para que importe los
recursos, o las pruebas pueden fallar al cargar sprites y sonidos.

Cada prueba imprime una línea por comprobación:

```
[OK]   P2 esquiva la gaviota saltando percent=0
[FAIL] ...
RESULTADO: 0 fallos
```

**El código de salida es 0 si todo pasó** y 1 si algo falló. Sirve para scripts.

## Qué cubre cada prueba

### `test_headless.gd` (la general, unas 100 comprobaciones)

- Input Map: que existan las acciones `p1_*` y `p2_*`.
- Carga de todas las escenas y de las músicas.
- Menú, foco y música.
- Selección: cambiar personaje, confirmar, cancelar.
- Arena: cuenta atrás, movimiento, salto, golpe básico.
- Especial del Gaviotero: que aparezca la gaviota, que avance, que golpee y que desaparezca.
- Especial del Topo: hundimiento, viaje bajo tierra, emersión y golpe.
- Que el Topo no se active en el aire.
- KO, reaparición y fin de partida.
- Modo práctica (muñeco sin input y vidas infinitas).
- Config y autodetección de personajes.
- Tileset del escenario y estilo del panel de selección.

### `test_dodge_bugs.gd` (esquivar y bugs concretos)

- Se puede esquivar la gaviota saltando, y si no se salta sí hace daño.
- El Topo no se activa desde una plataforma.
- El Topo siempre emerge en el suelo principal.
- Se puede esquivar el golpe del Topo saltando a tiempo.

### `test_especiales_nuevos.gd` (Likan y Aukin)

- Likan: caen `rock_count` rocas, primero solo sombras (sin daño), una apunta al rival,
  atraviesan plataformas hasta el suelo, golpean a quien se queda y se esquivan apartándose.
- Aukin: los tallarines brotan bajo el rival, lo atrapan e inmovilizan, reparten el daño total,
  lo sueltan y lo lanzan; se esquivan saliendo de la zona o estando alto; sin rival no se activa.

### `test_nanco_winkul.gd` (Ñanco y Winkul)

- Ñanco: fuma (aviso, sin daño), sopla una nube que daña una vez y empuja hacia donde mira
  (también a la izquierda); se esquiva estando lejos o por encima de la nube.
- Winkul: aparecen las grietas de aviso, los pinchos dañan y lanzan hacia la orilla más cercana
  (derecha o izquierda según de qué lado del centro esté el rival); se esquivan desde una
  plataforma o fuera de la fila.

### `test_jorge.gd` (Jorge)

- Aviso sin daño; el anzuelo engancha (25 % del daño), recoge al rival delante de Jorge y lo
  lanza al lado contrario al que mira (derecha o izquierda) con el 75 % restante.
- Se esquiva saltando o quedando fuera de alcance; si falla, el anzuelo vuelve y Jorge recupera
  el control; si golpean a Jorge mientras el anzuelo está fuera, la especial sigue (solo pierde el control un momento).

### `test_ui_layout.gd` (menús y teclas)

- **Teclas (Keybinds):** cambiar una tecla, intercambio al chocar, Esc reservada, guardado en
  `user://controles.cfg`, restaurar, y que cada acción quede con exactamente una tecla.
- **Textos:** abre el menú, Controles, selección de escenario, selección de personajes (con CADA personaje en los dos
  paneles, que es el peor caso de descripción) y el HUD de la arena de cada escenario (con 999 % de daño).
  Mide cada `Label` y falla si el texto no cabe en su caja, si se monta sobre otro texto o si se sale de la pantalla.

### `test_escenarios.gd` (los escenarios)

Para cada escenario de `Game.STAGES`: carga bien, los dos luchadores aparecen y se quedan sobre el suelo, el suelo
cubre los puntos de aparición, el dibujo de tiles coincide con la colisión, se aterriza sobre **cada** plataforma,
está dentro de la zona de KO y es alcanzable con salto + doble salto.

### `test_shaders.gd` (efectos visuales)

- Los tres archivos de shader cargan.
- Al recibir un golpe el luchador destella y el destello se apaga; al reaparecer empieza disolviéndose.
- Desierto tiene el shader de calor en el fondo; Azotea tiene las scanlines; Pradera no tiene ninguno.
- **No** comprueba cómo se ve ni errores de GLSL: el headless no dibuja. Eso se ve en el editor.

### `test_personajes.gd` (el contrato de cada personaje)

Para **cada** personaje de `characters/`, sin configuración extra:

- Tiene escena, retrato, nombre y estadísticas válidas.
- Tiene las animaciones obligatorias.
- En la arena, su especial **se activa y termina**, jugando tanto como **P1 como P2**.
- Al terminar no queda invulnerable ni congelado.

Úsala después de crear o modificar un personaje.

## Cuándo ejecutar cada una

| Acabas de... | Ejecuta |
|---|---|
| Cambiar una ficha (`.tres`) | `test_personajes.gd` |
| Cambiar el especial de Likan o Aukin | `test_especiales_nuevos.gd` |
| Cambiar el especial de Ñanco o Winkul | `test_nanco_winkul.gd` |
| Cambiar el especial de Jorge | `test_jorge.gd` |
| Cambiar el tileset o `StageTiles.gd` | `test_headless.gd` |
| Cambiar Config.gd o un script de luchador | `test_headless.gd` y `test_dodge_bugs.gd` |
| Crear un personaje | `test_personajes.gd` |
| Cambiar un escenario | `test_escenarios.gd` y `test_headless.gd` |
| Cambiar un menú, un texto o las teclas | `test_ui_layout.gd` y `test_headless.gd` |

## Depuración: errores típicos y qué significan

| Mensaje | Qué pasó | Solución |
|---|---|---|
| `There is no animation with name 'idle'` | El `SpriteFrames` no tiene esa animación. | Revisa `resources/<personaje>_frames.tres` o regenera los sprites. |
| `Invalid type in built-in function 'load'. Cannot convert argument 1 from Nil` | Una ruta de escena está vacía o mal escrita (por ejemplo, la `scene` de una ficha sin asignar). | Revisa el campo `scene` de la ficha. |
| `Invalid get index '0' (on base: 'Array')` en la arena | Suele venir de un error anterior: la arena no llegó a crear a los luchadores. | Busca el primer error de la lista y arréglalo. |
| `Parse Error: Unexpected identifier: 'PoolFloatArray'` | En un `.tscn` escrito a mano. | En Godot 3 se escribe `PoolRealArray`. |
| `Nonexistent function 'setup' in base 'KinematicBody2D'` | Se llama a `setup()` sobre un nodo que no es un luchador. | Verifica el script asignado a la escena. |
| `Node not found: "X"` en una prueba | La ruta del nodo cambió al reorganizar la escena. | Actualiza la ruta en el test. |

## Cómo depurar un comportamiento raro

1. **Imprime el estado.** `print("state=", state, " phase=", phase)` en el punto sospechoso.
   En Godot 3 la salida aparece en la pestaña **Salida**.
2. **Mira el árbol en vivo.** Con el juego en marcha, pestaña **Remote** (a la izquierda):
   puedes ver y cambiar los valores de cada luchador.
3. **Pausa y mira.** Usa el depurador (Depurar > Activar punto de interrupción) en una línea de `_physics_process`.
4. **Escribe una prueba.** Si el fallo es reproducible, copia `test_dodge_bugs.gd`, simula
   las pulsaciones con `Input.action_press()` y comprueba el valor exacto. Así el bug queda
   cubierto para siempre.

## Lecciones aprendidas (para no repetirlas)

- **`call_group` en Godot 3 se ejecuta al final del frame.** Si pruebas un efecto que
  llega por grupo, espera un instante antes de comprobarlo.
- **`Input.is_action_just_pressed` no sirve en las pruebas** si la llamas dentro del mismo
  frame que la pulsación simulada. Usa `Input.action_press()`, espera unos milisegundos y
  luego `action_release()`, como hacen las pruebas del proyecto.
- **Las pruebas de salto y esquive dependen del tiempo.** Si cambias una velocidad,
  puede que tengas que ajustar los `yield(wait(...))` de la prueba.
- **La versión con ventana no se usa para las pruebas automáticas.** Son las headless las que
  se ejecutan en el proyecto.
