# 16 · Guía completa de la ficha `characters/*.tres`

Cada personaje tiene un archivo `characters/<id>.tres`. Ábrelo en el **Inspector** de Godot (doble
clic sobre el archivo) y cambia los valores. No hace falta tocar código.

Esta guía explica **todos** los campos. Los valores que aparecen son los **por defecto** del
editor (`scripts/core/CharacterData.gd`). Si un campo no está escrito en un `.tres`, usa ese valor.

Cómo leer las tablas:
- **Rango**: lo que deja poner el editor. Es un límite de seguridad, no una regla del juego.
- Los campos con prefijo de habilidad (`gull_`, `dig_`, `rock_`, `noodle_`, `smoke_`, `spike_`, `hook_`)
  solo los lee **esa** habilidad. Los demás personajes los ignoran.

Para cambios de equilibrio, empieza por los campos de daño, empuje, tiempo y velocidad. Los de
"animación" (marcados así abajo) desincronizan el dibujo si los cambias mucho.

---

## 1. Identidad

| Campo | Por defecto | Qué hace |
|---|---|---|
| `id` | `""` | Nombre interno (sin tildes ni espacios), p. ej. `"topo"`. Si está vacío se usa el nombre del archivo. |
| `order` | 100 | Posición en la selección de personajes. Menor = más a la izquierda. |
| `display_name` | `"Luchador"` | Nombre que se ve en menús y en el HUD. Puede tener tildes: "Ñanco". |
| `special_name` | `"Especial"` | Nombre de la habilidad especial en la pantalla de selección. |
| `description` | `""` | Texto explicativo en la pantalla de selección. Admite varias líneas. |
| `color` | blanco | Color de marcos, nombre y HUD de este personaje. |
| `portrait` | — | Imagen grande que se ve al elegir personaje (`assets/sprites/<id>/portrait.svg`). |
| `scene` | — | Escena del luchador (`scenes/fighters/*.tscn`). Define el cuerpo y la clase de script. |

## 2. Movimiento

| Campo | Por defecto | Rango | Qué hace |
|---|---|---|---|
| `move_speed` | 300 | 50–800 | Velocidad máxima al correr (px/s). |
| `accel` | 2600 | 200–6000 | Qué tan rápido llega a `move_speed` en el suelo. Más alto = arranque más brusco. |
| `air_accel` | 1500 | 200–6000 | Lo mismo, pero en el aire. Bajo = controlas poco al saltar. |
| `jump_speed` | 720 | 200–1400 | Fuerza del salto. Más alto = salta más alto. |
| `gravity` | 1800 | 400–4000 | Gravedad (px/s²). Más alto = cae más rápido y salta menos. |
| `max_fall_speed` | 1000 | 200–2000 | Velocidad máxima de caída. |
| `max_air_jumps` | 1 | 0–5 | Saltos extra en el aire. 1 = doble salto, 0 = sin doble salto. |

## 3. Golpe básico (botón de ataque)

| Campo | Por defecto | Rango | Qué hace |
|---|---|---|---|
| `attack_damage` | 6 | 0–40 | % de daño que suma el golpe al rival. |
| `attack_knockback` | (320, -260) | — | Empuje del golpe. La **x** se refleja según hacia dónde mira el luchador; la **y** negativa empuja hacia arriba. |
| `attack_startup` | 0.08 | 0–0.5 | Segundos desde que pulsas hasta que el golpe empieza a dañar. |
| `attack_active` | 0.10 | 0.02–0.5 | Segundos que el golpe puede dañar. |
| `attack_total` | 0.26 | 0.05–1 | Duración total del golpe. Hasta que pasa, no puedes moverte. |
| `max_stocks` | 3 | 1–9 | Vidas. Al quedarte sin ninguna pierdes la partida. |

## 4. Campos comunes de la habilidad especial

Estos cuatro los tienen **todas** las habilidades. Lo que significan exactamente depende de la
habilidad; cada una se explica en su sección.

| Campo | Por defecto | Rango | Qué hace |
|---|---|---|---|
| `special_cooldown` | 3.0 | 0.5–30 | Segundos de recarga antes de poder volver a usar la especial. |
| `special_damage` | 10 | 0–60 | % de daño **total** de la especial. El reparto exacto (por roca, por pincho, por apretón...) está en cada habilidad. |
| `special_knockback` | (400, -300) | — | Empuje base. Se multiplica por `1 + %del_rival / KNOCKBACK_GROWTH`: cuanto más % tiene, sale más lejos. La **x** se refleja según el lado del golpe. |
| `special_windup` | 0.35 | 0–3 | Segundos de **aviso** antes de que la especial haga efecto. Durante el aviso no hace daño: es tu tiempo para esquivar. |

---

## 5. Gaviotero · Gaviota veloz

Archivo: `scripts/effects/Gull.gd`, `scripts/fighters/Gaviotero.gd`.
Secuencia: aviso (`special_windup`) → aparece una gaviota delante de él y vuela recta en la dirección que mira.
Daña a todo lo que toque y desaparece al salir de la pantalla.

| Campo | Por defecto | Rango | Qué hace |
|---|---|---|---|
| `gull_speed` | 470 | 0–2000 | Velocidad de la gaviota (px/s). Más alto = llega antes y es más difícil de esquivar. |
| `gull_recover_time` | 0.24 | 0–2 | Segundos que tarda en recuperar el control tras soltar la gaviota. |
| `gull_spawn_ahead` | 90 | 0–400 | Distancia (px) delante de Gaviotero a la que aparece la gaviota. |
| `gull_left_limit` | -240 | -2000–0 | La gaviota desaparece al pasar este límite de x (izquierda). |
| `gull_right_limit` | 1520 | 0–4000 | La gaviota desaparece al pasar este límite de x (derecha). |
| `gull_bob` | 10 | 0–60 | Amplitud del vaivén vertical (px). Solo visual, pero cambia la altura real de la gaviota. |
| `gull_fade_in` | 0.12 | 0–1 | Segundos del fundido de aparición. Solo visual: ya hace daño desde el primer instante. |

Usa también: `special_windup` (aviso), `special_damage` (daño de la gaviota), `special_knockback` (empuje).

## 6. Topo · Excavación sorpresa

Archivo: `scripts/fighters/Topo.gd`. Solo puede usarla desde el suelo (no en el aire ni sobre plataformas).
Secuencia: se hunde (`special_windup` mínimo) → viaja bajo tierra hacia el rival (`dig_speed`) → emerge
y golpea tras `dig_emerge_delay`.

| Campo | Por defecto | Rango | Qué hace |
|---|---|---|---|
| `dig_speed` | 520 | 0–2000 | Velocidad del montículo bajo tierra (px/s). |
| `dig_emerge_delay` | 0.22 | 0–3 | Segundos entre que emerge y golpea. Más alto = más tiempo para saltar. |
| `dig_under_max` | 2.0 | 0.5–6 | Tope de seguridad (s) bajo tierra si el montículo no llega al rival. |
| `dig_dive_time` | 0.42 | 0.05–3 | **Animación.** Duración de la zambullida antes de viajar bajo tierra. |
| `dig_emerge_end` | 0.42 | 0.05–3 | **Animación.** Segundos hasta que el Topo recupera el control tras emerger. |
| `dig_fallback_floor_y` | 480 | 0–2000 | Altura (y) del suelo si no se encuentra suelo bajo el Topo. Úsalo solo si el escenario no tiene suelo bajo esa zona. |

Usa también: `special_windup` (tiempo mínimo bajo tierra), `special_damage`, `special_knockback`.

## 7. Likan · Lluvia de rocas

Archivos: `scripts/fighters/Likan.gd`, `scripts/effects/Rock.gd`.
Secuencia: sombras de aviso (`special_windup`) → caen `rock_count` rocas, una tras otra, en una franja
alrededor del rival → cada roca atraviesa las plataformas y daña una vez.

| Campo | Por defecto | Rango | Qué hace |
|---|---|---|---|
| `rock_speed` | 900 | 0–2000 | Velocidad de caída de cada roca (px/s). |
| `rock_count` | 5 | 1–20 | Cuántas rocas caen. |
| `rock_zone_width` | 540 | 0–1200 | Ancho (px) de la franja donde caen, centrada en el rival. |
| `rock_gap_time` | 0.2 | 0–3 | Segundos entre una roca y la siguiente. |
| `rock_jitter` | 8 | 0–60 | Variación aleatoria (px) en la x de cada roca. Hace la lluvia menos regular. |
| `rock_spawn_delay` | 0.18 | 0–3 | **Animación.** Segundos desde el inicio hasta que invoca las rocas. |
| `rock_total_time` | 0.42 | 0–3 | **Animación.** Segundos hasta que Likan recupera el control. Debe ser **mayor o igual** que `rock_spawn_delay`. |
| `rock_zone_min_x` | 300 | -2000–4000 | Límite izquierdo (x) donde pueden caer las rocas. Evita que caigan fuera del escenario. |
| `rock_zone_max_x` | 980 | -2000–4000 | Límite derecho (x) donde pueden caer las rocas. |
| `rock_sky_y` | -60 | -2000–0 | Altura (y) desde la que empiezan a caer las rocas. |
| `rock_no_floor_y` | 760 | 0–3000 | Si no hay suelo bajo una roca, cae hasta esta altura (y). |
| `rock_linger` | 0.8 | 0–3 | Segundos que la roca sigue viva tras romperse (deja sonar el sonido). |
| `rock_shake` | 5 | 0–30 | Temblor de cámara al caer. |

Usa también: `special_windup` (aviso), `special_damage` (daño **por roca**), `special_knockback` (empuje de cada roca).

## 8. Aukin · Tallarines enredadores

Archivos: `scripts/fighters/Aukin.gd`, `scripts/effects/Noodles.gd`.
Secuencia: puntas que asoman (`special_windup`) → suben (`noodle_rise_time`) → se quedan arriba
(`noodle_up_time`) y **atrapan a quien entre en la zona** → bajan (`noodle_retract_time`).
Quien ya fue atrapado y soltado no vuelve a quedar atrapado en ese mismo ataque.

| Campo | Por defecto | Rango | Qué hace |
|---|---|---|---|
| `noodle_zone_width` | 96 | 0–1200 | Ancho (px) de la zona de tallarines. |
| `noodle_height` | 130 | 30–400 | Altura (px) de los tallarines y de la zona de agarre. Saltar por encima de esta altura los esquiva. |
| `noodle_squeezes` | 3 | 1–20 | Número de apretones (golpes) mientras lo tienen atrapado. Reparten `special_damage`. |
| `noodle_hold_time` | 0.9 | 0–3 | Segundos que cada rival queda inmovilizado. |
| `noodle_rise_time` | 0.14 | 0.02–1 | Segundos que tardan en subir. |
| `noodle_up_time` | 0.6 | 0.1–5 | Segundos que se quedan arriba. **Mientras estén arriba atrapan a quien entre en la zona.** Bajan cuando pasa este tiempo y ya soltaron a todos. |
| `noodle_retract_time` | 0.3 | 0.05–2 | Segundos que tardan en bajar. |
| `noodle_spawn_delay` | 0.18 | 0–3 | **Animación.** Segundos desde el inicio hasta que brotan. |
| `noodle_total_time` | 0.42 | 0–3 | **Animación.** Segundos hasta que Aukin recupera el control. |

Usa también: `special_windup`, `special_damage` (total, repartido entre los apretones), `special_knockback` (empuje al soltar).

## 9. Ñanco · Humo de cigarro

Archivos: `scripts/fighters/Nanco.gd`, `scripts/effects/SmokeCloud.gd`.
Secuencia: fuma (`special_windup`) → sopla una nube delante de él que dura `smoke_duration` →
quien esté dentro recibe un empuje continuo.

| Campo | Por defecto | Rango | Qué hace |
|---|---|---|---|
| `smoke_length` | 280 | 0–1200 | Largo (px) de la nube. |
| `smoke_height` | 100 | 0–300 | Alto (px) de la nube. Saltar por encima la esquiva. |
| `smoke_duration` | 0.5 | 0–3 | Segundos que dura la nube. |
| `smoke_push_accel` | 2200 | 0–6000 | Fuerza del empujón continuo (px/s por segundo) a quien esté dentro. |
| `smoke_max_push` | 620 | 0–2000 | Tope de la velocidad horizontal que da el empujón (px/s). |
| `smoke_start_offset` | 34 | 0–400 | Dónde empieza la nube, delante de la cara de Ñanco (px). |
| `smoke_fade_time` | 0.35 | 0–2 | Segundos que tarda en disiparse tras acabar. |
| `smoke_recover_time` | 0.15 | 0–2 | Segundos que Ñanco tarda en recuperar el control tras soplar. |

Usa también: `special_windup`, `special_damage` (una sola vez), `special_knockback` (golpe inicial).

## 10. Winkul · Pinchos al borde

Archivos: `scripts/fighters/Winkul.gd`, `scripts/effects/Spike.gd`.
Secuencia: aparecen `spike_count` grietas rojas en el suelo (`spike_spawn_delay`), una cada
`spike_spacing` px → cada grieta parpadea (`special_windup`, más `spike_gap_time` por cada una anterior)
→ salen los pinchos (`spike_up_time`), se quedan (`spike_hold_time`) y se hunden (`spike_retract_time`).

| Campo | Por defecto | Rango | Qué hace |
|---|---|---|---|
| `spike_count` | 6 | 1–20 | Cuántos grupos de pinchos salen. |
| `spike_spacing` | 80 | 0–400 | Separación (px) entre grupos, hacia donde mira Winkul. |
| `spike_gap_time` | 0.09 | 0–3 | Segundos entre un grupo y el siguiente. |
| `spike_start_offset` | 90 | 0–400 | Distancia (px) del primer grupo a Winkul. |
| `spike_height` | 64 | 10–300 | Alto de los pinchos (px). Saltar por encima de esta altura los esquiva. |
| `spike_half_width` | 22 | 5–80 | Semiancho (px) de cada grupo. |
| `spike_up_time` | 0.07 | 0–2 | Segundos que tardan en salir. |
| `spike_hold_time` | 0.35 | 0–3 | Segundos que se quedan arriba. |
| `spike_retract_time` | 0.2 | 0–2 | Segundos que tardan en hundirse. |
| `spike_shake` | 3 | 0–20 | Temblor de cámara al salir. |
| `spike_spawn_delay` | 0.2 | 0–3 | **Animación.** Segundos desde el inicio hasta que aparecen las grietas. |
| `spike_total_time` | 0.42 | 0–3 | **Animación.** Segundos hasta que Winkul recupera el control. |

Usa también: `special_windup`, `special_damage` (**por pincho**), `special_knockback` (la x apunta a la orilla más cercana).

## 11. Jorge · Caña de pescar

Archivos: `scripts/fighters/Jorge.gd`, `scripts/effects/Hook.gd`.
Secuencia: lanza la caña (`special_windup`) → el anzuelo vuela `hook_range` px a `hook_speed` →
si engancha a alguien, lo **recoge** en `hook_reel_time` hasta delante de Jorge → con el tirón
(`hook_throw_delay`) lo lanza al otro lado. El anzuelo engancha tanto al **ir** como al **volver**.
Si te golpean durante la especial, no se anula: solo pierdes el control un momento.

| Campo | Por defecto | Rango | Qué hace |
|---|---|---|---|
| `hook_speed` | 760 | 0–2000 | Velocidad del anzuelo al volar (px/s). |
| `hook_range` | 420 | 0–1200 | Alcance máximo del anzuelo (px). Más allá, vuelve a la caña. |
| `hook_reel_time` | 0.25 | 0–3 | Segundos que tarda en recoger al rival hasta delante de Jorge. |
| `hook_return_speed` | 1500 | 100–5000 | Velocidad (px/s) con la que vuelve el anzuelo si falla. |
| `hook_grab_share` | 0.25 | 0–1 | Parte del daño (`special_damage`) que hace al enganchar. El resto lo hace al lanzar. |
| `hook_hold_buffer` | 1.0 | 0–5 | Segundos extra de inmovilización por seguridad, por si Jorge tarda en recogerlo. |
| `hook_front_distance` | 56 | 0–200 | Distancia (px) delante de Jorge donde queda el rival recogido. |
| `hook_throw_delay` | 0.12 | 0–1 | **Animación.** Segundos del tirón hasta que suelta al rival. |
| `hook_throw_total` | 0.32 | 0.05–2 | **Animación.** Duración total del tirón. |

Usa también: `special_windup`, `special_damage` (total), `special_knockback` (la x va al lado **contrario** al que mira Jorge).

---

## Ejemplos de cambios

- **Topo más fácil de esquivar:** `dig_emerge_delay` de 0.22 a 0.4.
- **Gaviota más rápida:** `gull_speed` de 470 a 600.
- **Likan con más rocas que cubren más terreno:** `rock_count` de 5 a 8 y `rock_zone_width` de 540 a 700.
- **Aukin con tallarines que atrapan más tiempo:** `noodle_up_time` de 0.6 a 1.2.
- **Ñanco con empuje más fuerte:** `smoke_push_accel` de 2200 a 3000 y `smoke_max_push` de 620 a 800.
- **Winkul con pinchos más juntos:** `spike_spacing` de 80 a 60.
- **Jorge con anzuelo que llega más lejos:** `hook_range` de 420 a 520.
- **Luchador pesado:** `gravity` más alto y `jump_speed` más bajo.
- **Triple salto:** `max_air_jumps` = 2.

## Cómo se aplican los cambios

- Los valores se copian al luchador **al empezar la partida** (`Fighter.apply_data()`). Si ya tienes
  una partida abierta, vuelve a empezarla para ver el cambio.
- `apply_data()` copia al luchador solo: `display_name`, los de movimiento (`move_speed`, `accel`,
  `air_accel`, `jump_speed`, `gravity`, `max_fall_speed`, `max_air_jumps`), los de golpe básico
  (`attack_*`), `special_cooldown` y `max_stocks`.
- Todo lo demás (incluidos `special_damage`, `special_knockback`, `special_windup` y los campos de cada
  habilidad) lo leen los scripts directamente desde `stats`. Cambiarlos en la ficha tiene efecto sin tocar código.

## Añadir un campo nuevo

1. Declara la variable `export` en `scripts/core/CharacterData.gd`, en la sección de su habilidad,
   con el prefijo de la habilidad (p. ej. `gull_`) y un comentario que diga qué hace.
2. Léela en el script de la habilidad como `stats.<nombre>`.
3. Ponle su valor en el `.tres` del personaje y añádela a esta guía.
4. Corre `godot --path . -s tools/test_personajes.gd`.

## Qué NO está en la ficha

Lo que queda en código son constantes de **dibujo** o de **geometría fija**, no de equilibrio:
`COLOR_*` y `STRANDS` (tallarines), `RADIUS` (roca), `ROD_TIP` (punta de la caña), y `Config.gd`
(valores globales del juego, como `RESPAWN_DELAY` o los límites de la zona de salida de pantalla).
Están documentados en la cabecera de cada script.
