# 01 · Estructura del proyecto

Este documento explica qué hay en cada carpeta y para qué sirve cada cosa.

```
smash2d/
├── project.godot          Configuración del proyecto (ventana, controles, autoloads)
├── icon.svg               Icono del juego
├── README.md              Resumen corto (apunta aquí)
│
├── characters/            FICHAS DE PERSONAJES (.tres). Un archivo por personaje.
│   ├── gaviotero.tres
│   └── topo.tres
│
├── scenes/                ESCENAS (.tscn): lo que se ve y cómo se organiza
│   ├── Arena.tscn         La pantalla de combate (carga el escenario elegido)
│   ├── stages/            Un escenario por escena: Pradera, Desierto, Azotea
│   ├── fighters/          Luchadores
│   │   ├── Fighter.tscn   Luchador base (plantilla común)
│   │   ├── Gaviotero.tscn Hereda de Fighter, añade sus sprites y sonidos
│   │   └── Topo.tscn      Hereda de Fighter, añade sus sprites y efectos
│   ├── effects/           Efectos que aparecen y desaparecen
│   │   ├── Gull.tscn      La gaviota del especial del Gaviotero
│   │   └── HitSpark.tscn  Destello al golpear o al caer
│   └── ui/                Pantallas y paneles
│       ├── MainMenu.tscn      Menú principal
│       ├── CharSelect.tscn    Selección de personajes
│       ├── PickPanel.tscn     Panel de selección de UN jugador
│       └── PlayerPanel.tscn   Marcador (%, vidas, especial) durante el combate
│
├── scripts/               CÓDIGO (.gd), agrupado por tema
│   ├── core/              Lo global: Config, Game, Keybinds (teclas), CharacterData
│   ├── fighters/          Luchadores: Fighter (base), Gaviotero, Topo, Likan, Aukin, Nanco, Winkul, Jorge
│   ├── effects/           Gull, Rock, Noodles, SmokeCloud, Spike, Hook, Spark
│   ├── stage/             Arena, StageTiles (dibujo del suelo), Drift (nubes / estrellas)
│   └── ui/                MainMenu, Controls, CharSelect, PickPanel, StageSelect, PlayerPanel, AnimButton
│
├── resources/             Recursos reutilizables
│   ├── font_tiny / font_small / font_med / font_pct / font_big .tres   Fuentes (16, 20, 30, 54 y 72 px)
│   ├── ui_theme.tres      Tema de la interfaz (botones con textura)
│   ├── stage_tileset*.tres Tilesets de los escenarios (pradera, _desierto, _azotea)
│   ├── gaviotero_frames.tres, topo_frames.tres, gull_frames.tres
│   │                      Animaciones (SpriteFrames) de cada personaje y la gaviota
│
├── assets/                MATERIAL (archivos que no son código)
│   ├── fonts/             DejaVuSans-Bold.ttf (licencia libre)
│   ├── sprites/           Imágenes SVG de cada cuadro de animación
│   │   ├── gaviotero/ topo/ gull/ fx/ stage/
│   ├── sounds/            Efectos de sonido (.wav)
│   ├── music/             Músicas (.ogg) y sus partituras MIDI en music/midi/
│   └── shaders/           Shaders (efectos visuales): fighter_fx, heat_haze, neon_scanlines
│
├── tools/                 GENERADORES Y PRUEBAS (Python y GDScript)
│   ├── make_sprites.py    Crea todos los SVG y las animaciones
│   ├── make_audio.py      Crea todos los efectos de sonido
│   ├── make_music.py      Compone las músicas en MIDI y las convierte a OGG
│   ├── make_tileset.py    Crea los tilesets de los escenarios
│   ├── make_stages.py     Crea los fondos del desierto y la azotea
│   ├── make_ui.py         Crea las texturas de los botones y el tema
│   ├── editor_personajes.html  Editor de personajes (un solo HTML, funciona en el celular)
│   ├── test_ui_layout.gd  Textos sin solapes + teclas (Keybinds)
│   ├── test_escenarios.gd Cada escenario: suelo, plataformas alcanzables, música
│   ├── test_shaders.gd    Shaders: carga y efectos del luchador (no dibuja)
│   ├── nuevo_personaje.py Crea un personaje completo con un comando
│   ├── plantillas/        Plantillas de texto usadas por nuevo_personaje.py
│   ├── personajes_extra.json  Color y sombrero de los personajes creados con el generador
│   ├── test_headless.gd   Prueba general del juego
│   ├── test_dodge_bugs.gd Pruebas de esquivar especiales y del Topo en plataformas
│   ├── test_personajes.gd Contrato que debe cumplir cada personaje
│   ├── test_especiales_nuevos.gd  Especiales de Likan (rocas) y Aukin (tallarines)
│   ├── test_nanco_winkul.gd       Especiales de Ñanco (humo) y Winkul (pinchos)
│   └── test_jorge.gd              Especial de Jorge (caña de pescar)
│
└── docs/                  Esta documentación
```

## Qué carpetas NO se tocan a mano

- **`.import/`** (si aparece): la genera Godot automáticamente. Puedes borrarla sin problema.
- **`*.import`**: idem, los genera Godot al importar un recurso.
- **`tools/plantillas/`**: son plantillas. Si las cambias, cambian los personajes nuevos,
  pero no los que ya existen.

## Qué archivo tocar según lo que quieras

| Quiero... | Archivo |
|---|---|
| Cambiar velocidad, salto, daño, vidas de un personaje | `characters/<id>.tres` |
| Cambiar el nombre o color que aparece en pantalla | `characters/<id>.tres` |
| Cambiar cómo se comporta el especial del Gaviotero | `scripts/fighters/Gaviotero.gd` y `scripts/effects/Gull.gd` |
| Cambiar cómo se comporta el especial del Topo | `scripts/fighters/Topo.gd` |
| Cambiar el especial de Likan (rocas) | `scripts/fighters/Likan.gd` y `scripts/effects/Rock.gd` |
| Cambiar el especial de Aukin (tallarines) | `scripts/fighters/Aukin.gd` y `scripts/effects/Noodles.gd` |
| Cambiar el especial de Ñanco (humo) | `scripts/fighters/Nanco.gd` y `scripts/effects/SmokeCloud.gd` |
| Cambiar el especial de Winkul (pinchos) | `scripts/fighters/Winkul.gd` y `scripts/effects/Spike.gd` |
| Cambiar el especial de Jorge (caña) | `scripts/fighters/Jorge.gd` y `scripts/effects/Hook.gd` |
| Cambiar cuánto empuja un golpe, la cámara, el KO | `scripts/core/Config.gd` |
| Cambiar teclas | Proyecto > Ajustes > Mapa de entrada (ver [02](02_EJECUTAR_Y_CONTROLES.md)) |
| Cambiar el suelo o las plataformas | `scenes/stages/*.tscn` y [07](07_ESCENARIO_Y_TILESET.md) |
| Cambiar textos de los menús | las escenas en `scenes/ui/` |
| Crear un personaje nuevo | `python3 tools/nuevo_personaje.py` ([06](06_CREAR_UN_PERSONAJE_NUEVO.md)) |
