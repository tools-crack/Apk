# 06 · Crear un personaje nuevo

Hay dos caminos. El **rápido** usa el generador y te deja un personaje jugable en un
minuto. El **manual** es para entender cada pieza o para hacer algo muy distinto.

## Camino rápido: el generador

Desde la carpeta del proyecto (la que contiene `project.godot`):

```bash
python3 tools/nuevo_personaje.py rayo "Rayo" --color "#e0b000" --sombrero minero \
    --especial "Puño relámpago" --descripcion "Lanza un puñetazo eléctrico al frente."
```

Parámetros:

| Parámetro | Obligatorio | Qué es |
|---|---|---|
| `id` | sí | Nombre interno: minúsculas, números y `_`. Empieza con letra. Ej.: `rayo`, `mi_heroe`. |
| `nombre` | sí | Nombre visible. Ej.: `"Rayo"`. |
| `--color` | no | Color en hexadecimal, `#rrggbb`. Por defecto `#8a4fd6`. |
| `--sombrero` | no | `marinero`, `minero`, `cocinero`, `piedra`, `gorra`, `pinchos`, `pescador` o `ninguno`. Solo cambia el dibujo del stickman. |
| `--especial` | no | Nombre de la habilidad. |
| `--descripcion` | no | Texto para la pantalla de selección. |

El generador crea:

1. **`characters/rayo.tres`**: la ficha, con estadísticas por defecto que ya funcionan.
2. **`scenes/fighters/Rayo.tscn`**: la escena del luchador (hereda de `Fighter.tscn`).
3. **`scripts/fighters/Rayo.gd`**: el script con un especial de ejemplo (un golpe con aviso).
4. **Sprites SVG** de sus animaciones, en `assets/sprites/rayo/`, y su `resources/rayo_frames.tres`.
5. Una entrada en **`tools/personajes_extra.json`** (color y sombrero; el resto del aspecto —pelo, ropa, anteojos— se añade a mano, ver [10](10_SPRITES_SONIDO_Y_MUSICA.md)).

Después:

1. Abre el proyecto en Godot para que importe los sprites nuevos.
2. Pulsa F5. El personaje aparece automáticamente en la selección, en el lugar que
   indique `order` (al final por defecto).
3. Verifica que cumple el contrato:

   ```bash
   godot --path . -s tools/test_personajes.gd
   ```

   Comprueba que tenga retrato, estadísticas válidas, las animaciones obligatorias y
   que su especial **se active y termine**. Funciona para cualquier personaje de `characters/`.

> Si el generador falla con "Ya existe", ese id ya se usó. Elige otro id o borra
> `characters/<id>.tres` a mano si fue un intento anterior.

## Lo que tienes que personalizar después

El generador deja un personaje **funcional pero genérico**. Lo que casi siempre querrás cambiar:

1. **Su especial**, en `scripts/fighters/Rayo.gd`. Edita `_start_special()` y `_state_special()`.
   Ver la sección "Crear una habilidad nueva" en [05](05_HABILIDADES_ESPECIALES.md).
2. **Sus números**, en `characters/rayo.tres`: velocidad, salto, daño, recarga.
3. **Sus sprites**: el dibujo es un stickman genérico. Si quieres otro diseño, edita
   `tools/make_sprites.py` (función `build_frames` y `CHARACTERS`) y vuelve a generar.
4. **Su sonido de especial**: en `scenes/fighters/Rayo.tscn`, el nodo `SfxSpecial`
   usa por defecto `emerge.wav`. Cámbialo arrastrando otro `.wav` al campo `Stream`.

## Camino manual (para entender cada pieza)

Si prefieres hacerlo a mano, estas son las cuatro piezas que necesita un personaje:

### 1. Ficha `characters/<id>.tres`

Duplica `characters/topo.tres`, cámbiale el nombre del archivo y los campos
`id`, `display_name`, `special_name`, `color` y `order`. Las escenas y el retrato
se asignan arrastrando. Campo por campo en [04](04_PERSONAJES_Y_FICHAS.md).

### 2. Escena `scenes/fighters/<Clase>.tscn`

1. Clic derecho en `scenes/fighters/Fighter.tscn` > **Nueva escena heredada**.
2. Asigna el script `scripts/fighters/<Clase>.gd` al nodo raíz.
3. En el nodo `Sprite`, asigna el `frames` (SpriteFrames) de tu personaje.
4. Pon `animation = "idle"` y `playing = true`.
5. Asigna sonidos a los nodos `Sfx*` si quieres.

### 3. Script `scripts/fighters/<Clase>.gd`

```gdscript
extends "res://scripts/fighters/Fighter.gd"

func _can_special() -> bool:
    return true                    # ¿cuándo puede usarse?

func _start_special() -> void:
    state = State.SPECIAL          # obligatorio
    state_time = 0.0               # obligatorio
    special_timer = special_cooldown
    _play("special", true)         # animación

func _state_special(delta: float) -> void:
    if state_time >= 0.3:          # cuando termine...
        state = State.NORMAL       # ...vuelve a jugar. Obligatorio.
```

**Reglas que no se pueden romper:**

- `_start_special()` debe poner `state = State.SPECIAL`, o el especial nunca termina.
- `_state_special()` debe volver a `State.NORMAL` en algún momento, o el luchador queda bloqueado.
- Para dañar a alguien, llama a `body.take_hit(daño, empuje, self)`. No restes vida a mano.

### 4. Frames de animación (SpriteFrames)

El personaje necesita, como mínimo, estas animaciones en su `SpriteFrames`:

| Animación | Cuándo se usa |
|---|---|
| `idle` | quieto |
| `run` | corriendo |
| `jump` | subiendo |
| `fall` | cayendo |
| `hurt` | aturdido |
| `attack` | golpe básico |
| `special` (o `dive`) | su habilidad |

`test_personajes.gd` verifica que existan. Si falta una, el juego no se rompe
(simplemente no se reproduce), pero la prueba te lo avisará.

### 5. Registro

Ya no hay que registrar nada a mano: `Game.gd` lee todos los `.tres` de `characters/`
que no empiecen por `_`. Si quieres **ocultar** un personaje sin borrarlo, renombra su
archivo a `_nombre.tres`.

## Errores típicos

| Síntoma | Causa probable |
|---|---|
| El personaje no aparece en la selección | El archivo no está en `characters/` o empieza por `_`. |
| Al entrar a la arena el juego se cierra con error | La ficha no tiene `scene` o `portrait` asignados. |
| El especial se activa pero el luchador se queda quieto | `_state_special()` nunca vuelve a `State.NORMAL`. |
| El luchador no se mueve nunca | Su `scene` no tiene el script heredado de `Fighter.gd`. |
| Los sprites no cambian tras regenerar | Abre el proyecto de nuevo en Godot para que reimporte. |
