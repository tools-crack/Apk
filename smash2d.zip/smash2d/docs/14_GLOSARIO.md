# 14 · Glosario

**Autoload.** Script o escena que Godot carga al iniciar y que existe durante todo el juego.
Aquí: `Config` y `Game`.

**Blast zone (zona de KO).** El rectángulo fuera de la pantalla. Un luchador que sale de él pierde una vida.
Ver `BLAST_*` en Config.

**Cooldown (recarga).** Segundos que debe esperar el especial antes de poder usarse otra vez.

**Escena (`.tscn`).** Archivo que describe un árbol de nodos: lo que se ve y cómo se organiza.

**Ficha (`.tres`).** Recurso con los datos de un personaje. Se edita en el Inspector.

**Grupo.** Etiqueta que puede tener un nodo para encontrarlo fácilmente. Aquí: `fighters` y `arena`.

**Headless.** Ejecutar Godot **sin ventana**. Lo usan las pruebas automáticas.

**Hitbox.** Área invisible que detecta golpes. El Fighter tiene una delante para el golpe básico.

**Hitstun (aturdimiento).** Tiempo en el que un luchador no puede controlarse tras un golpe.

**Input Map (mapa de entrada).** Lista de acciones (`p1_left`, `p2_special`...) y las teclas asignadas a cada una.

**Knockback (empuje).** Velocidad con la que un golpe lanza al rival.

**KinematicBody2D.** Tipo de nodo para personajes que se mueven y chocan con paredes y suelo.

**Máscara y capa (layer/mask).** Sistema de colisiones: una capa es "en qué grupo estoy";
una máscara es "con qué grupos choco". Ver `Config.gd`.

**Porcentaje (%).** Daño acumulado de un luchador. Sube con cada golpe y determina cuánto vuela.

**SpriteFrames.** Recurso que agrupa los cuadros de una animación (`idle`, `run`, etc.).

**Special windup (aviso).** Tiempo en que un especial parpadea antes de hacer daño.

**Stock (vida).** Cada oportunidad de seguir en la partida. Se pierde al salir de la pantalla.

**TileMap / TileSet.** Un TileMap dibuja una grilla de piezas (tiles) tomadas de un TileSet.

**Invulnerable.** Estado en que un luchador no recibe daño (al reaparecer o mientras se hunde el Topo).

**Stickman.** Personaje dibujado con líneas y círculos, sin rasgos detallados. Es el estilo de los personajes de prueba.
