extends CPUParticles2D
# ============================================================================
#  Spark.gd  —  destello de golpe / KO (escena HitSpark.tscn)
# ----------------------------------------------------------------------------
#  Se emite una sola vez (estrellitas) y se elimina solo a los "life" segundos.
#  Lo crea Fighter._spawn_spark(). Para cambiar su aspecto edita HitSpark.tscn.
# ============================================================================

var life := 0.9


func _ready() -> void:
	restart()
	emitting = true


func _process(delta: float) -> void:
	life -= delta
	if life <= 0.0:
		queue_free()
