extends Area2D
# ============================================================================
#  SmokeCloud.gd  —  la nube de humo del especial de Ñanco
# ----------------------------------------------------------------------------
#  Nanco.gd la crea delante de Ñanco cuando termina de fumar (setup()). Dura
#  smoke_duration segundos y tiene dos efectos sobre quien esté DENTRO:
#     1) un golpe inicial, UNA sola vez por luchador (special_damage y
#        special_knockback, con la x apuntando hacia donde sopla Ñanco)
#     2) un EMPUJÓN continuo mientras siga en la nube: se le suma velocidad
#        horizontal (smoke_push_accel px/s por segundo) hasta un tope (MAX_PUSH).
#        Se puede resistir caminando en sentido contrario, pero cuesta.
#
#  ESQUIVABLE: antes de soplar, Ñanco fuma special_windup segundos (se ve la
#  brasa). Saltando por encima (la nube tiene HEIGHT px de alto) o alejándose
#  más que smoke_length px, no te alcanza.
# ============================================================================


var shooter = null
var stats = null
var dir := 1
var t := 0.0
var hit_list := []
var active := true

onready var shape = $Shape
onready var puff = $Puff


# La llama Nanco.gd ANTES de add_child(). from = Ñanco, d = hacia dónde sopla (1 o -1).
func setup(from, d: int) -> void:
	shooter = from
	stats = from.stats
	dir = d
	position = from.position + Vector2(d * stats.smoke_start_offset, -14)


func _ready() -> void:
	var length = max(stats.smoke_length, 40.0)
	var r = RectangleShape2D.new()
	r.extents = Vector2(length * 0.5, stats.smoke_height * 0.5)
	shape.shape = r
	shape.position = Vector2(dir * length * 0.5, 0)
	puff.direction = Vector2(dir, -0.05)
	puff.initial_velocity = length / 0.55            # llega al final de la nube en ~0.55 s
	puff.emitting = true


func _physics_process(delta: float) -> void:
	t += delta
	if active and t >= stats.smoke_duration:
		active = false
		puff.emitting = false
		shape.set_deferred("disabled", true)
	if not active:
		if t >= stats.smoke_duration + stats.smoke_fade_time:
			queue_free()
		return
	for body in get_overlapping_bodies():
		if body == shooter or not body.has_method("take_hit") or body.is_dead():
			continue
		if not hit_list.has(body):
			hit_list.append(body)
			var k = stats.special_knockback
			body.take_hit(stats.special_damage, Vector2(dir * k.x, k.y), shooter)
		# empujón continuo
		body.velocity.x = clamp(body.velocity.x + dir * stats.smoke_push_accel * delta, -stats.smoke_max_push, stats.smoke_max_push)
