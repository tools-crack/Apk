extends Area2D
# ============================================================================
#  Noodles.gd  —  los tallarines del especial del Aukin
# ----------------------------------------------------------------------------
#  Aukin.gd crea este nodo en el suelo (o plataforma) bajo el rival. Los
#  tallarines se DIBUJAN por código (_draw) como tiras onduladas que suben.
#
#  FASES
#     WARN    (special_windup)   asoman unas puntas que se retuercen + polvo.
#                                 No hace daño: es el aviso, hay tiempo de salir.
#     RISE    (noodle_rise_time) suben. Atrapan a quien esté DENTRO de la zona.
#     HOLD    (noodle_up_time)   siguen arriba y SIGUEN atrapando a quien entre
#                                 en la zona mientras estén en pie. A cada atrapado
#                                 lo inmovilizan (noodle_hold_time) y le dan
#                                 noodle_squeezes apretones que suman special_damage.
#                                 Quien ya fue atrapado y soltado no vuelve a serlo.
#     RETRACT (noodle_retract_time) se encogen. Solo baja cuando ya pasó
#                                 noodle_up_time Y ya soltaron a todos los atrapados.
#
#  ESQUIVABLE: salir de la zona durante WARN, o estar más alto que noodle_height (salto doble).
#
#  El rival queda atrapado con Fighter.entangle() (ver Fighter.gd). Los números
#  salen de characters/aukin.tres (via from.stats).
# ============================================================================

enum Phase { WARN, RISE, HOLD, RETRACT }

const STRANDS := 6
const COLOR_LINE := Color(0.106, 0.106, 0.184)       # contorno (el OUTLINE del resto de sprites)
const COLOR_FILL := Color(0.949, 0.788, 0.298)       # amarillo tallarín
const COLOR_LIGHT := Color(1.0, 0.929, 0.627)        # brillo

var phase = Phase.WARN
var shooter = null
var stats = null
var t := 0.0                     # tiempo total desde que se creó
var phase_time := 0.0            # tiempo en la fase actual
var victims := []                # [{ "body": luchador, "elapsed": s, "ticks": n }]
var height := 0.0                # altura visible actual
var width := 96.0

onready var shape = $Shape
onready var dust = $Dust
onready var burst = $Burst
onready var sfx_rise = $SfxRise


# La llama Aukin.gd ANTES de add_child(). base = punto del suelo donde brotan.
func setup(from, base: Vector2) -> void:
	shooter = from
	stats = from.stats
	position = base


func _ready() -> void:
	if stats != null and stats.noodle_zone_width > 0.0:
		width = stats.noodle_zone_width
	var r = RectangleShape2D.new()
	r.extents = Vector2(width * 0.5, stats.noodle_height * 0.5)
	shape.shape = r
	shape.position = Vector2(0, -stats.noodle_height * 0.5)
	dust.emitting = true


func _physics_process(delta: float) -> void:
	t += delta
	phase_time += delta
	match phase:
		Phase.WARN:
			height = 14.0 + 6.0 * sin(t * 18.0)                   # puntas que se retuercen
			if phase_time >= stats.special_windup:
				_enter(Phase.RISE)
				dust.emitting = false
				burst.emitting = true
				sfx_rise.play()
				get_tree().call_group("arena", "shake", 3.0)
		Phase.RISE:
			height = lerp(14.0, stats.noodle_height, clamp(phase_time / stats.noodle_rise_time, 0.0, 1.0))
			_grab_overlapping()
			if phase_time >= stats.noodle_rise_time:
				_enter(Phase.HOLD)
				height = stats.noodle_height
		Phase.HOLD:
			height = stats.noodle_height
			_grab_overlapping()                                   # quien entre en la zona mientras estén arriba
			_update_victims(delta)
			if phase_time >= stats.noodle_up_time and _all_released():
				_enter(Phase.RETRACT)
		Phase.RETRACT:
			height = lerp(stats.noodle_height, 0.0, clamp(phase_time / stats.noodle_retract_time, 0.0, 1.0))
			if phase_time >= stats.noodle_retract_time:
				queue_free()
	update()                                                      # vuelve a llamar a _draw()


func _enter(p) -> void:
	phase = p
	phase_time = 0.0


# ---- Atrapar: primer apretón + inmovilizar
func _grab_overlapping() -> void:
	for body in get_overlapping_bodies():
		if body == shooter or not body.has_method("take_hit") or _has_victim(body):
			continue
		var tick = stats.special_damage / float(max(1, stats.noodle_squeezes))
		if body.take_hit(tick, Vector2.ZERO, shooter):            # false = invulnerable: se libra
			body.entangle(stats.noodle_hold_time)
			victims.append({"body": body, "elapsed": 0.0, "ticks": 1})


func _has_victim(body) -> bool:
	for v in victims:
		if v.body == body:
			return true
	return false


# ---- Apretar: cada noodle_hold_time/noodle_squeezes segundos otro golpe; al final, soltar y lanzar
func _update_victims(delta: float) -> void:
	var dur = stats.noodle_hold_time
	var n = int(max(1, stats.noodle_squeezes))
	for v in victims:
		if v.has("done"):
			continue
		var b = v.body
		if not is_instance_valid(b) or b.is_dead():
			v["done"] = true
			continue
		v.elapsed += delta
		if v.elapsed >= dur:
			v["done"] = true
			b.release_entangle()
			var dir = sign(b.global_position.x - (shooter.global_position.x if is_instance_valid(shooter) else global_position.x))
			if dir == 0:
				dir = 1
			var k = stats.special_knockback
			b.take_hit(0.0, Vector2(dir * k.x, k.y), shooter)      # lanzamiento final (el daño ya se repartió en los apretones)
		elif v.ticks < n and v.elapsed >= dur * float(v.ticks) / float(n):
			v.ticks += 1
			if b.take_hit(stats.special_damage / float(n), Vector2.ZERO, shooter):
				b.entangle(dur - v.elapsed)                        # el golpe lo soltó: lo vuelve a atrapar


func _all_released() -> bool:
	for v in victims:
		if not v.has("done"):
			return false
	return true


# ---- Dibujo: tiras onduladas + vueltas alrededor de cada atrapado
func _draw() -> void:
	if height <= 1.0:
		return
	var strands = []
	for i in STRANDS:
		var ox = lerp(-width * 0.5 + 10.0, width * 0.5 - 10.0, float(i) / float(STRANDS - 1))
		var pts = PoolVector2Array()
		var segs = 10
		for j in segs + 1:
			var f = float(j) / float(segs)
			var amp = (5.0 + 11.0 * f) * min(1.0, height / 40.0)
			pts.append(Vector2(ox + sin(t * 5.0 + float(i) * 1.7 + f * 4.0) * amp, -height * f))
		strands.append(pts)
	for pts in strands:
		draw_polyline(pts, COLOR_LINE, 11.0, true)
		draw_circle(pts[pts.size() - 1], 5.5, COLOR_LINE)
	for pts in strands:
		draw_polyline(pts, COLOR_FILL, 7.0, true)
		draw_circle(pts[pts.size() - 1], 3.5, COLOR_FILL)
	for pts in strands:
		var hi = PoolVector2Array()
		for p in pts:
			hi.append(p + Vector2(-1.5, 0))
		draw_polyline(hi, COLOR_LIGHT, 1.8, true)
	# vueltas alrededor de los atrapados
	for v in victims:
		if v.has("done") or not is_instance_valid(v.body):
			continue
		var c = v.body.global_position - global_position
		for k in 3:
			var ring = PoolVector2Array()
			var cy = c.y - 26.0 + float(k) * 22.0
			for a in 25:
				var ang = float(a) / 24.0 * TAU
				ring.append(Vector2(c.x + cos(ang) * (22.0 + 2.0 * sin(t * 9.0 + k)), cy + sin(ang) * 6.0))
			draw_polyline(ring, COLOR_LINE, 11.0, true)
			draw_polyline(ring, COLOR_FILL, 7.0, true)
