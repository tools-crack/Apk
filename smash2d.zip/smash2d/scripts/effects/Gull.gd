extends Area2D
# ============================================================================
#  Gull.gd  —  la gaviota del especial del Gaviotero
# ----------------------------------------------------------------------------
#  Vuela en línea recta hacia donde miraba el jugador (con un pequeño vaivén
#  vertical) y desaparece al salir del mapa.
#
#  ESQUIVABLE: el aviso es el tiempo que Gaviotero tarda en soltarla
#  (special_windup, ver Gaviotero.gd). Una vez suelta daña a cada rival una sola
#  vez. Su hitbox está a la altura del cuerpo, así que saltando por encima se esquiva.
#
#  Gaviotero.gd la crea y le pasa los datos con setup() ANTES de add_child().
#  Velocidad, daño y empuje salen de characters/gaviotero.tres.
# ============================================================================


var dir := 1
var shooter = null                # quién la lanzó (no se daña a sí mismo)
var speed := 470.0
var damage := 9.0
var knockback := Vector2(420, -300)
var hit_list := []
var t := 0.0
var base_y := 0.0


var cfg = null                    # la ficha del personaje que lo creó (parámetros de la habilidad)


func setup(from, d: int) -> void:
	shooter = from
	dir = d
	var s = from.stats
	cfg = s
	speed = s.gull_speed
	damage = s.special_damage
	knockback = s.special_knockback
	position = from.position + Vector2(d * cfg.gull_spawn_ahead, -10)


func _ready() -> void:
	base_y = position.y
	$Sprite.flip_h = dir < 0
	$Sprite.play("fly")
	$Feathers.direction = Vector2(-dir, 0)


func _physics_process(delta: float) -> void:
	t += delta
	position.x += dir * speed * delta
	position.y = base_y + sin(t * 7.0) * cfg.gull_bob
	modulate.a = min(1.0, 0.35 + 0.65 * t / cfg.gull_fade_in)
	for body in get_overlapping_bodies():
		if body != shooter and not hit_list.has(body) and body.has_method("take_hit"):
			hit_list.append(body)
			body.take_hit(damage, Vector2(dir * knockback.x, knockback.y), shooter)
	if position.x < cfg.gull_left_limit or position.x > cfg.gull_right_limit:
		queue_free()
