extends Area2D
# ============================================================================
#  Hook.gd  —  el anzuelo del especial de Jorge
# ----------------------------------------------------------------------------
#  Jorge.gd lo crea en la punta de la caña cuando termina de lanzar (setup()).
#  El anzuelo y la línea se DIBUJAN por código (_draw).
#
#  FASES
#     FLY     vuela recto hacia donde mira Jorge a hook_speed px/s, hasta
#             hook_range px. Engancha al primer rival que toque.
#     RETURN  vuelve a la caña y desaparece. Mientras vuelve TAMBIÉN engancha al rival
#             que toque (así el anzuelo que falló puede recoger a alguien al regresar).
#     REEL    (si enganchó) el rival queda inmovilizado y el anzuelo lo recoge
#             hasta quedar delante de Jorge, en hook_reel_time segundos.
#     HELD    el rival está delante de Jorge esperando el lanzamiento.
#  Cuando Jorge termina su animación de tirón llama a throw(): suelta al rival
#  y lo LANZA HACIA EL OTRO LADO (detrás de Jorge, por encima de su cabeza).
#
#  ESQUIVABLE: el anzuelo vuela a la altura del pecho y tiene alcance limitado:
#  saltar por encima o quedarse más lejos que hook_range. Si golpean a Jorge
#  mientras el anzuelo está fuera, NO se cancela: Jorge solo pierde el control un momento.
#
#  Daño: special_damage se reparte 25 % al engancharlo y 75 % al lanzarlo.
# ============================================================================

enum Phase { FLY, RETURN, REEL, HELD, DONE }

const ROD_TIP := Vector2(58, -24)    # punta de la caña respecto al centro de Jorge (mirando a la derecha)
const COLOR_LINE := Color(0.106, 0.106, 0.184)
const COLOR_STEEL := Color(0.85, 0.88, 0.93)

var shooter = null
var stats = null
var dir := 1
var phase = Phase.FLY
var travelled := 0.0
var victim = null
var victim_start := Vector2.ZERO
var reel_t := 0.0

onready var sfx_reel = $SfxReel


# La llama Jorge.gd ANTES de add_child(). d = hacia dónde mira Jorge (1 o -1).
func setup(from, d: int) -> void:
	shooter = from
	stats = from.stats
	dir = d
	position = _tip()


func _tip() -> Vector2:
	return shooter.global_position + Vector2(dir * ROD_TIP.x, ROD_TIP.y)


func _front_point() -> Vector2:
	return shooter.global_position + Vector2(dir * stats.hook_front_distance, 0)


func _physics_process(delta: float) -> void:
	if shooter == null or not is_instance_valid(shooter) or shooter.is_dead():
		_abort()                                       # Jorge murió: se cancela todo
		return
	match phase:
		Phase.FLY:
			var step = stats.hook_speed * delta
			position.x += dir * step
			position.y = _tip().y
			travelled += step
			for body in get_overlapping_bodies():
				if _can_hook(body) and _grab(body):
					break
			if phase == Phase.FLY and travelled >= stats.hook_range:
				phase = Phase.RETURN
		Phase.RETURN:
			for body in get_overlapping_bodies():          # al volver también se puede enganchar
				if _can_hook(body) and _grab(body):
					break
			if phase == Phase.RETURN:
				var to_tip = _tip() - position
				if to_tip.length() <= stats.hook_return_speed * delta + 6.0:
					_finish()
					return
				position += to_tip.normalized() * stats.hook_return_speed * delta
		Phase.REEL:
			if not _victim_ok():
				_abort()
				return
			reel_t += delta
			var f = clamp(reel_t / max(stats.hook_reel_time, 0.01), 0.0, 1.0)
			victim.global_position = victim_start.linear_interpolate(_front_point(), f)
			position = victim.global_position
			if f >= 1.0:
				phase = Phase.HELD
		Phase.HELD:
			if not _victim_ok():
				_abort()
				return
			victim.global_position = _front_point()
			position = victim.global_position
	update()                                           # vuelve a llamar a _draw()


func _can_hook(body) -> bool:
	return body != shooter and body.has_method("take_hit") and not body.is_dead() and not body.is_invulnerable()


func _victim_ok() -> bool:
	return victim != null and is_instance_valid(victim) and not victim.is_dead()


# Engancha: primer daño + inmovilizar. Devuelve false si el rival se libró (invulnerable).
func _grab(body) -> bool:
	if not body.take_hit(stats.special_damage * stats.hook_grab_share, Vector2.ZERO, shooter):
		return false
	victim = body
	victim_start = body.global_position
	victim.entangle(stats.hook_reel_time + stats.hook_hold_buffer)
	reel_t = 0.0
	phase = Phase.REEL
	sfx_reel.play()
	return true


# La llama Jorge.gd en el momento del tirón: suelta al rival y lo lanza al otro lado.
func throw() -> void:
	if _victim_ok():
		victim.release_entangle()
		var k = stats.special_knockback
		victim.take_hit(stats.special_damage * (1.0 - stats.hook_grab_share), Vector2(-dir * k.x, k.y), shooter)
	_finish()


func _abort() -> void:
	if _victim_ok():
		victim.release_entangle()
	_finish()


func _finish() -> void:
	phase = Phase.DONE
	queue_free()


func _draw() -> void:
	var tip = to_local(_tip()) if shooter != null and is_instance_valid(shooter) else Vector2.ZERO
	# línea de pescar: de la punta de la caña al anzuelo
	draw_line(tip, Vector2.ZERO, COLOR_LINE, 3.4, true)
	draw_line(tip, Vector2.ZERO, Color(0.93, 0.95, 1.0), 1.4, true)
	# anzuelo: argolla + curva en forma de J
	draw_circle(Vector2.ZERO, 5.0, COLOR_LINE)
	draw_circle(Vector2.ZERO, 3.0, COLOR_STEEL)
	var j = PoolVector2Array()
	for i in range(0, 9):
		var a = lerp(-PI * 0.5, PI * 0.9, float(i) / 8.0)
		j.append(Vector2(dir * (-1.0) * (cos(a) * 7.0 - 1.0), 6.0 + sin(a) * 7.0))
	draw_polyline(j, COLOR_LINE, 4.4, true)
	draw_polyline(j, COLOR_STEEL, 2.2, true)
