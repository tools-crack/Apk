extends Area2D
# ============================================================================
#  Rock.gd  —  una roca de la "Lluvia de rocas" de Likan
# ----------------------------------------------------------------------------
#  Likan.gd crea varias rocas y a cada una le dice en qué x caerá (setup()).
#  El nodo se coloca en el PUNTO DE IMPACTO (la superficie donde aterriza) y la
#  roca baja desde el cielo hasta él.
#
#  FASES
#     WARN    (special_windup + turno)  solo se ve una SOMBRA ROJA que parpadea
#                                       en el punto de impacto. No hace daño.
#     FALL    la roca cae a rock_speed px/s, atraviesa las plataformas y
#             daña a quien toque por el camino (una vez).
#     LANDED  se rompe: chispas de piedra, sonido y temblor de cámara. Se borra sola.
#
#  ESQUIVABLE: la sombra avisa dónde va a caer; basta con apartarse de esa x.
#  Daño, empuje y velocidad salen de characters/likan.tres (via from.stats).
# ============================================================================

enum Phase { WARN, FALL, LANDED }

const RADIUS := 20.0         # radio de la roca (mitad de rock.svg, 44 px)

var phase = Phase.WARN
var shooter = null           # Likan (no se daña a sí mismo)
var speed := 900.0
var damage := 6.0
var knockback := Vector2(240, -430)
var delay := 0.7             # segundos de aviso antes de empezar a caer
var land_y := 0.0            # y de la superficie donde aterriza
var height := 0.0            # altura actual de la roca sobre el punto de impacto
var total_height := 1.0
var t := 0.0
var hit_list := []

onready var rock = $Rock
onready var shadow = $Shadow
onready var shape = $Shape
onready var debris = $Debris
onready var sfx = $SfxImpact


# La llama Likan.gd ANTES de add_child(). x = dónde cae, wait = segundos hasta que empieza a caer.
var cfg = null                    # la ficha del personaje que lo creó (parámetros de la habilidad)


func setup(from, x: float, wait: float) -> void:
	shooter = from
	var s = from.stats
	cfg = s
	speed = s.rock_speed
	damage = s.special_damage
	knockback = s.special_knockback
	delay = wait
	# superficie (suelo o plataforma) que hay bajo esa x, mirando desde arriba
	# Solo el SUELO PRINCIPAL la detiene: atraviesa las plataformas, así golpea a quien esté
	# en cualquier altura de su columna (también a quien esté sobre una plataforma).
	var hit = from.get_world_2d().direct_space_state.intersect_ray(
		Vector2(x, -300.0), Vector2(x, 1400.0), [from], Config.BIT_GROUND)
	land_y = cfg.rock_no_floor_y if hit.empty() else hit.position.y
	position = Vector2(x, land_y)
	height = land_y - cfg.rock_sky_y
	total_height = max(height, 1.0)


func _ready() -> void:
	rock.visible = false
	shadow.position = Vector2(0, -2)
	shape.position.y = -height


func _physics_process(delta: float) -> void:
	t += delta
	match phase:
		Phase.WARN:
			shadow.modulate.a = 0.45 if int(t * 14.0) % 2 == 0 else 1.0     # parpadea
			if t >= delay:
				phase = Phase.FALL
				rock.visible = true
				shadow.modulate.a = 1.0
		Phase.FALL:
			height -= speed * delta
			var cy = -max(height, RADIUS)
			rock.position.y = cy
			shape.position.y = cy
			rock.rotation += delta * 2.5
			shadow.scale = Vector2.ONE * (0.8 + 0.4 * (1.0 - clamp(height / total_height, 0.0, 1.0)))
			_hit_overlaps()
			if height <= RADIUS:
				_land()


func _hit_overlaps() -> void:
	for body in get_overlapping_bodies():
		if body == shooter or hit_list.has(body) or not body.has_method("take_hit"):
			continue
		hit_list.append(body)
		var dir = sign(body.global_position.x - global_position.x)
		if dir == 0:
			dir = shooter.facing if shooter != null and is_instance_valid(shooter) else 1
		body.take_hit(damage, Vector2(dir * knockback.x, knockback.y), shooter)


func _land() -> void:
	phase = Phase.LANDED
	rock.visible = false
	shadow.visible = false
	debris.emitting = true
	sfx.pitch_scale = rand_range(0.92, 1.08)
	sfx.play()
	get_tree().call_group("arena", "shake", cfg.rock_shake)
	yield(get_tree().create_timer(cfg.rock_linger), "timeout")
	queue_free()
