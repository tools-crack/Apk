extends Area2D
# ============================================================================
#  Spike.gd  —  un grupo de pinchos del especial de Winkul
# ----------------------------------------------------------------------------
#  Winkul.gd crea una fila de estos (uno cada spike_spacing px hacia donde
#  mira). Cada uno aparece en el SUELO PRINCIPAL y se dibuja por código (_draw).
#
#  FASES
#     WARN     (special_windup + turno)  solo se ve una GRIETA roja parpadeando.
#                                         No hace daño: es el aviso.
#     UP       (UP_TIME)                  los pinchos salen de golpe. Daña.
#     HOLD     (HOLD_TIME)                se quedan arriba. Siguen dañando.
#     RETRACT  (RETRACT_TIME)             se hunden y el nodo se borra.
#
#  Quien toca un pincho recibe special_damage una sola vez y sale lanzado HACIA
#  LA ORILLA: hacia el borde del escenario más cercano a su posición (a la
#  izquierda si está en la mitad izquierda, a la derecha si está en la derecha).
#
#  ESQUIVABLE: saltar por encima (los pinchos miden HEIGHT px), subirse a una
#  plataforma, o quedarse fuera de la fila.
# ============================================================================

enum Phase { WARN, UP, HOLD, RETRACT }

const COLOR_STEEL := Color(0.81, 0.85, 0.89)
const COLOR_LIGHT := Color(0.96, 0.98, 1.0)
const COLOR_LINE := Color(0.106, 0.106, 0.184)
const COLOR_CRACK := Color(1.0, 0.35, 0.3)

var shooter = null
var stats = null
var delay := 0.45                # segundos de aviso hasta que salen
var has_floor := false           # false si bajo esa x no hay suelo (Winkul.gd lo descarta)
var phase = Phase.WARN
var t := 0.0
var phase_time := 0.0
var height := 0.0
var hit_list := []

onready var shape = $Shape
onready var sfx_pop = $SfxPop


# La llama Winkul.gd ANTES de add_child(). x = dónde sale, wait = segundos hasta que sale.
func setup(from, x: float, wait: float) -> void:
	shooter = from
	stats = from.stats
	delay = wait
	var hit = from.get_world_2d().direct_space_state.intersect_ray(
		Vector2(x, -300.0), Vector2(x, 1400.0), [from], Config.BIT_GROUND)
	has_floor = not hit.empty()
	position = Vector2(x, hit.position.y if has_floor else 0.0)


func _ready() -> void:
	var r = RectangleShape2D.new()
	r.extents = Vector2(stats.spike_half_width, stats.spike_height * 0.5)
	shape.shape = r
	shape.position = Vector2(0, -stats.spike_height * 0.5)


func _physics_process(delta: float) -> void:
	t += delta
	phase_time += delta
	match phase:
		Phase.WARN:
			if t >= delay:
				_enter(Phase.UP)
				sfx_pop.pitch_scale = rand_range(0.95, 1.08)
				sfx_pop.play()
				get_tree().call_group("arena", "shake", stats.spike_shake)
		Phase.UP:
			height = lerp(0.0, stats.spike_height, clamp(phase_time / stats.spike_up_time, 0.0, 1.0))
			_hit_overlaps()
			if phase_time >= stats.spike_up_time:
				_enter(Phase.HOLD)
		Phase.HOLD:
			height = stats.spike_height
			_hit_overlaps()
			if phase_time >= stats.spike_hold_time:
				_enter(Phase.RETRACT)
		Phase.RETRACT:
			height = lerp(stats.spike_height, 0.0, clamp(phase_time / stats.spike_retract_time, 0.0, 1.0))
			if phase_time >= stats.spike_retract_time:
				queue_free()
	update()                                                      # vuelve a llamar a _draw()


func _enter(p) -> void:
	phase = p
	phase_time = 0.0


# Daña una vez a cada luchador y lo lanza hacia la orilla más cercana.
func _hit_overlaps() -> void:
	for body in get_overlapping_bodies():
		if body == shooter or hit_list.has(body) or not body.has_method("take_hit"):
			continue
		hit_list.append(body)
		var dir = sign(body.global_position.x - Config.SCREEN_SIZE.x * 0.5)    # + derecha, - izquierda
		if dir == 0:
			dir = shooter.facing if is_instance_valid(shooter) else 1
		var k = stats.special_knockback
		body.take_hit(stats.special_damage, Vector2(dir * k.x, k.y), shooter)


func _draw() -> void:
	if phase == Phase.WARN:
		# grieta roja parpadeante sobre el suelo
		var a = 0.45 if int(t * 14.0) % 2 == 0 else 1.0
		var c = Color(COLOR_CRACK.r, COLOR_CRACK.g, COLOR_CRACK.b, a)
		var pts = PoolVector2Array([Vector2(-stats.spike_half_width, -1), Vector2(-10, -5), Vector2(-3, 0),
			Vector2(4, -6), Vector2(12, -1), Vector2(stats.spike_half_width, -4)])
		draw_polyline(pts, COLOR_LINE, 6.0, true)
		draw_polyline(pts, c, 3.0, true)
		return
	if height <= 1.0:
		return
	# tres pinchos: el central alto y dos laterales más bajos
	for spec in [[-13.0, 0.62, 9.0], [13.0, 0.62, 9.0], [0.0, 1.0, 11.0]]:
		var x = spec[0]
		var h = height * spec[1]
		var w = spec[2]
		var tri = PoolVector2Array([Vector2(x - w, 0), Vector2(x, -h), Vector2(x + w, 0)])
		draw_colored_polygon(tri, COLOR_STEEL)
		draw_colored_polygon(PoolVector2Array([Vector2(x - w * 0.1, -h * 0.9), Vector2(x, -h), Vector2(x + w, 0), Vector2(x + w * 0.2, 0)]), Color(0.62, 0.68, 0.76))
		draw_polyline(PoolVector2Array([Vector2(x - w, 0), Vector2(x, -h), Vector2(x + w, 0)]), COLOR_LINE, 2.4, true)
		draw_line(Vector2(x - w * 0.35, -h * 0.25), Vector2(x - w * 0.05, -h * 0.75), COLOR_LIGHT, 1.8, true)
