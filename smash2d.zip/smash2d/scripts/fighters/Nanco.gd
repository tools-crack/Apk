extends "res://scripts/fighters/Fighter.gd"
# ============================================================================
#  Nanco.gd  —  Ñanco, especial "Humo de cigarro"
# ----------------------------------------------------------------------------
#  (El id es "nanco" sin la Ñ porque los nombres de archivo van sin tildes;
#   el nombre que se ve en el juego, "Ñanco", está en characters/nanco.tres.)
#
#  Al pulsar el botón Ñanco se lleva el cigarro a la boca y fuma durante
#  special_windup segundos (animación "special": se ve la brasa). Después sopla
#  y crea una nube de humo (SmokeCloud.tscn) delante de él que daña una vez y
#  EMPUJA a quien esté dentro. Todo el efecto de la nube está en
#  scripts/effects/SmokeCloud.gd.
#
#  ESQUIVABLE: la brasa avisa. Salta por encima de la nube o aléjate más que
#  smoke_length px. Si golpean a Ñanco mientras fuma, no se corta: sale volando y la nube sopla igual.
#
#  Números que puedes tocar en characters/nanco.tres:
#     special_cooldown     recarga
#     special_damage       % de daño (una vez por luchador)
#     special_knockback    empuje del golpe inicial
#     smoke_push_accel        fuerza del empujón continuo (px/s por segundo)
#     special_windup       segundos que fuma antes de soplar (el aviso)
#     smoke_duration  segundos que dura la nube
#     smoke_length        largo de la nube (px)
#
#  Números de este archivo:
#     smoke_recover_time  segundos que tarda en recuperar el control tras soplar
# ============================================================================

const SMOKE_SCENE := preload("res://scenes/effects/SmokeCloud.tscn")

var blown := false


func _start_special() -> void:
	state = State.SPECIAL
	state_time = 0.0
	blown = false
	special_timer = special_cooldown
	velocity.x *= 0.3
	_play("special", true)
	_sfx($SfxSpecial)                      # el sonido de fumar (aspirar)


func _state_special(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 1500.0 * delta)
	if not blown and state_time >= stats.special_windup:
		blown = true
		var cloud = SMOKE_SCENE.instance()
		cloud.setup(self, facing)           # ANTES de add_child: quién sopla y hacia dónde
		get_parent().add_child(cloud)
		$SfxBlow.play()
	if state_time >= stats.special_windup + stats.smoke_recover_time:
		state = State.NORMAL
