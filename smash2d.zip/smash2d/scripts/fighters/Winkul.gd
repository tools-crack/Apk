extends "res://scripts/fighters/Fighter.gd"
# ============================================================================
#  Winkul.gd  —  especial "Pinchos al borde"
# ----------------------------------------------------------------------------
#  Winkul alza las manos y las clava en el suelo (animación "special"). A los
#  spike_spawn_delay segundos aparecen spike_count grietas rojas en el suelo, una
#  cada spike_spacing px hacia donde mira. Cada una avisa special_windup
#  segundos y luego brota un grupo de pinchos (Spike.tscn), uno tras otro
#  (cada spike_gap_time segundos). Quien los toca recibe daño y sale
#  lanzado hacia la ORILLA del escenario. Los detalles están en
#  scripts/effects/Spike.gd.
#
#  ESQUIVABLE: salta por encima de los pinchos, súbete a una plataforma o
#  quédate fuera de la fila.
#
#  Números que puedes tocar en characters/winkul.tres:
#     special_cooldown     recarga               special_damage     % de daño por pincho
#     special_knockback    empuje (la x se dirige hacia la orilla más cercana)
#     special_windup       aviso (grieta) antes de que salga el primer pincho
#     spike_gap_time  segundos entre un pincho y el siguiente
#     spike_count        cuántos grupos de pinchos      spike_spacing   separación (px)
#
#  Números de este archivo (atados a la animación "special": 3 cuadros a 8 fps):
#     spike_spawn_delay  cuándo aparecen las grietas   spike_total_time  cuándo recupera el control
#     START_OFFSET distancia del primer pincho a Winkul (px)
# ============================================================================

const SPIKE_SCENE := preload("res://scenes/effects/Spike.tscn")

var spikes_spawned := false


func _start_special() -> void:
	state = State.SPECIAL
	state_time = 0.0
	spikes_spawned = false
	special_timer = special_cooldown
	velocity.x *= 0.3
	_play("special", true)
	_sfx($SfxSpecial)


func _state_special(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 1500.0 * delta)
	if not spikes_spawned and state_time >= stats.spike_spawn_delay:
		spikes_spawned = true
		_spawn_spikes()
	if state_time >= stats.spike_total_time:
		state = State.NORMAL


func _spawn_spikes() -> void:
	for i in int(stats.spike_count):
		var x = global_position.x + facing * (stats.spike_start_offset + i * stats.spike_spacing)
		var spike = SPIKE_SCENE.instance()
		spike.setup(self, x, stats.special_windup + i * stats.spike_gap_time)    # ANTES de add_child
		if spike.has_floor:
			get_parent().add_child(spike)
		else:
			spike.free()                       # fuera del suelo: no sale pincho
