extends "res://scripts/fighters/Fighter.gd"
# ============================================================================
#  Gaviotero.gd  —  especial "Gaviota veloz"
# ----------------------------------------------------------------------------
#  Al pulsar el botón: reproduce la animación "special" y, pasados special_windup
#  segundos (el AVISO: se ve cómo prepara el lanzamiento), suelta una gaviota
#  (Gull.tscn) delante del jugador. La gaviota vuela recta hacia donde mira hasta
#  salir del mapa (ver scripts/effects/Gull.gd) y daña desde que sale.
#
#  Números que puedes tocar en characters/gaviotero.tres:
#     special_cooldown  recarga           special_damage      % de daño
#     special_knockback empuje            gull_speed       velocidad de la gaviota
#     special_windup    segundos de preparación ANTES de soltar la gaviota (el aviso)
#
#  Número de este archivo:
#     gull_recover_time  segundos que tarda en recuperar el control después de soltar la gaviota
# ============================================================================

const GULL_SCENE := preload("res://scenes/effects/Gull.tscn")

var gull_spawned := false


func _start_special() -> void:
	state = State.SPECIAL
	state_time = 0.0
	gull_spawned = false
	special_timer = special_cooldown
	velocity.x *= 0.3
	_play("special", true)
	_sfx($SfxSpecial)


func _state_special(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 1500.0 * delta)
	if not gull_spawned and state_time >= stats.special_windup:
		gull_spawned = true
		var gull = GULL_SCENE.instance()
		gull.setup(self, facing)           # ANTES de add_child: le pasa quién la lanza y hacia dónde
		get_parent().add_child(gull)
	if gull_spawned and state_time >= stats.special_windup + stats.gull_recover_time:
		state = State.NORMAL
