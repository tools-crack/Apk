extends "res://scripts/fighters/Fighter.gd"
# ============================================================================
#  Likan.gd  —  especial "Lluvia de rocas"
# ----------------------------------------------------------------------------
#  Al pulsar el botón Likan alza los brazos (animación "special") y, a los
#  rock_spawn_delay segundos, invoca rock_count rocas que caen del cielo en una
#  franja centrada en el rival (si no hay rival, delante de Likan).
#
#  ESQUIVABLE: cada roca marca su punto de impacto con una sombra roja
#  parpadeante special_windup segundos ANTES de empezar a caer (y las rocas van
#  cayendo una tras otra, cada rock_gap_time segundos). Mira
#  scripts/effects/Rock.gd para el comportamiento de cada roca.
#
#  Números que puedes tocar en characters/likan.tres:
#     special_cooldown     recarga                special_damage    % de daño POR ROCA
#     special_knockback    empuje de cada roca    rock_speed     velocidad de caída (px/s)
#     special_windup       aviso (sombra) antes de que caiga la primera roca
#     rock_gap_time  segundos entre una roca y la siguiente
#     rock_count        cuántas rocas caen     rock_zone_width     ancho de la franja (px)
#
#  Números de este archivo (atados a la animación "special": 3 cuadros a 8 fps):
#     rock_spawn_delay  cuándo invoca las rocas        rock_total_time  cuándo recupera el control
#     rock_zone_min_x / rock_zone_max_x  límites horizontales donde pueden caer (el suelo del escenario)
# ============================================================================

const ROCK_SCENE := preload("res://scenes/effects/Rock.tscn")

var rocks_spawned := false


func _start_special() -> void:
	state = State.SPECIAL
	state_time = 0.0
	rocks_spawned = false
	special_timer = special_cooldown
	velocity.x *= 0.3
	_play("special", true)
	_sfx($SfxSpecial)


func _state_special(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 1500.0 * delta)
	if not rocks_spawned and state_time >= stats.rock_spawn_delay:
		rocks_spawned = true
		_rain()
	if state_time >= stats.rock_total_time:
		state = State.NORMAL


# Crea las rocas: una cae justo sobre el rival y las demás se reparten a sus lados
# (la franja se mantiene dentro del escenario). El orden de caída es aleatorio.
func _rain() -> void:
	var n = int(stats.rock_count)
	var width = stats.rock_zone_width
	var rival = _find_target()
	var aim = rival.global_position.x if rival != null else global_position.x + facing * 250.0
	aim = clamp(aim, stats.rock_zone_min_x, stats.rock_zone_max_x)
	var spacing = width / float(max(1, n - 1))
	var order = []
	for i in n:
		order.append(i)
	order.shuffle()
	for k in n:
		var i = order[k]
		var x = aim + (float(i) - (n - 1) * 0.5) * spacing + rand_range(-stats.rock_jitter, stats.rock_jitter)
		x = clamp(x, stats.rock_zone_min_x, stats.rock_zone_max_x)
		var rock = ROCK_SCENE.instance()
		rock.setup(self, x, stats.special_windup + k * stats.rock_gap_time)   # ANTES de add_child
		get_parent().add_child(rock)
