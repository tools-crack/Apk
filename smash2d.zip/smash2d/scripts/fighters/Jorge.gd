extends "res://scripts/fighters/Fighter.gd"
# ============================================================================
#  Jorge.gd  —  especial "Caña de pescar"
# ----------------------------------------------------------------------------
#  Jorge echa hacia atrás la caña (animación "special") y, tras special_windup
#  segundos, lanza el anzuelo (Hook.tscn) hacia donde mira. Si engancha a un
#  rival, lo recoge hasta quedar delante de él y, con un tirón (animación
#  "throw"), lo lanza POR ENCIMA DE SU CABEZA hacia el OTRO LADO. Si el anzuelo
#  no engancha a nadie, vuelve a la caña y Jorge queda un momento indefenso.
#  Todo lo del anzuelo está en scripts/effects/Hook.gd.
#
#  FASES  (variable "phase")
#     CAST   lanza la caña (aviso) .............. hasta special_windup
#     FLY    el anzuelo vuela / recoge al rival .. hasta que enganche y llegue, o falle
#     THROW  tirón con la caña y lanzamiento ..... hook_throw_total segundos
#
#  Números que puedes tocar en characters/jorge.tres:
#     special_cooldown     recarga
#     special_damage       % de daño TOTAL (25 % al enganchar, 75 % al lanzar)
#     special_knockback    empuje del lanzamiento (la x apunta al lado CONTRARIO al que mira Jorge)
#     hook_speed        velocidad del anzuelo (px/s)
#     special_windup       segundos de aviso antes de lanzar el anzuelo
#     hook_reel_time  segundos que tarda en recoger al rival
#     hook_range        alcance máximo del anzuelo (px)
#
#  Números de este archivo (atados a la animación "throw": 2 cuadros a 12 fps):
#     hook_throw_delay  cuándo suelta al rival dentro del tirón     hook_throw_total  duración del tirón
# ============================================================================

enum Phase { CAST, FLY, THROW }

const HOOK_SCENE := preload("res://scenes/effects/Hook.tscn")

var phase = Phase.CAST
var phase_time := 0.0
var hook = null
var thrown := false


func _start_special() -> void:
	state = State.SPECIAL
	state_time = 0.0
	phase = Phase.CAST
	phase_time = 0.0
	hook = null
	thrown = false
	special_timer = special_cooldown
	velocity.x *= 0.3
	_play("special", true)
	_sfx($SfxSpecial)


func _state_special(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 1500.0 * delta)
	phase_time += delta
	match phase:
		Phase.CAST:
			if state_time >= stats.special_windup:
				hook = HOOK_SCENE.instance()
				hook.setup(self, facing)           # ANTES de add_child: quién lo lanza y hacia dónde
				get_parent().add_child(hook)
				phase = Phase.FLY
				phase_time = 0.0
		Phase.FLY:
			if hook == null or not is_instance_valid(hook):
				state = State.NORMAL               # falló: el anzuelo ya volvió
			elif hook.phase == hook.Phase.HELD:
				phase = Phase.THROW                # rival recogido delante de Jorge: tirón
				phase_time = 0.0
				thrown = false
				_play("throw", true)
		Phase.THROW:
			if not thrown and phase_time >= stats.hook_throw_delay:
				thrown = true
				if hook != null and is_instance_valid(hook):
					hook.throw()
			if phase_time >= stats.hook_throw_total:
				state = State.NORMAL
