extends KinematicBody2D
# ============================================================================
#  Fighter.gd  —  el luchador base (lo que tienen en común TODOS los personajes)
# ----------------------------------------------------------------------------
#  Maneja: movimiento, salto, golpe básico, recibir daño, KO y reaparición.
#  Cada personaje tiene su propio script que HEREDA de este (Gaviotero.gd,
#  Topo.gd) y solo añade su habilidad especial sobrescribiendo 3 funciones:
#
#       _can_special()        ¿puede usarse ahora?     (ver sección 8)
#       _start_special()      qué pasa al pulsar el botón
#       _state_special(delta) qué pasa mientras dura
#
#  Las estadísticas (velocidad, salto, daño...) NO están aquí: vienen del
#  archivo characters/<personaje>.tres y se copian en apply_data().
#  Los números globales (KO, reaparición, empuje...) están en Config.gd.
#
#  MÁQUINA DE ESTADOS (variable "state"):
#       NORMAL  -> controlas al personaje (correr, saltar, iniciar golpe/especial)
#       ATTACK  -> está dando el golpe básico
#       SPECIAL -> está ejecutando su habilidad especial
#       HURT    -> aturdido, volando tras un golpe
#       DEAD    -> fuera del mapa esperando reaparecer
#
#  Capas de colisión: 1 = suelo, 2 = luchadores, 3 = plataformas (ver Config.gd).
# ============================================================================

signal hit_taken(fighter, amount)
signal knocked_out(fighter)

enum State { NORMAL, ATTACK, SPECIAL, HURT, DEAD }

const SPARK_SCENE := preload("res://scenes/effects/HitSpark.tscn")

export var player_id := 1          # 1 o 2: lo pone Arena.gd con setup()

# ============================================================================
# 1. ESTADÍSTICAS  (valores por defecto; apply_data() los reemplaza con el .tres)
# ============================================================================
var stats = null                   # el CharacterData completo (lo usan los especiales)
var display_name := "Luchador"
var move_speed := 300.0
var accel := 2600.0
var air_accel := 1500.0
var jump_speed := 720.0
var gravity := 1800.0
var max_fall_speed := 1000.0
var max_air_jumps := 1
var attack_damage := 6.0
var attack_knockback := Vector2(320, -260)
var attack_startup := 0.08
var attack_active := 0.10
var attack_total := 0.26
var special_cooldown := 3.0
var max_stocks := 3

# ============================================================================
# 2. ESTADO EN TIEMPO DE EJECUCIÓN  (cambia durante la partida)
# ============================================================================
var state = State.NORMAL
var velocity := Vector2.ZERO
var facing := 1                    # 1 = mira a la derecha, -1 = a la izquierda
var percent := 0.0                 # daño acumulado (%)
var stocks := 3                    # vidas que le quedan
var input_enabled := true          # false durante la cuenta atrás, al terminar, o si es muñeco
var invulnerable := false          # lo activan las habilidades especiales
var invuln_timer := 0.0            # invulnerabilidad al reaparecer (parpadea)
var frozen := false                # true = sin gravedad ni movimiento (lo usa el Topo)
var wrapped_time := 0.0            # > 0 mientras está atrapado por los tallarines del Aukin
var special_timer := 0.0           # > 0 mientras el especial recarga
var special_stun := 0.0               # segundos sin control tras un golpe DURANTE el especial (el especial sigue)
var state_time := 0.0              # segundos desde que entró al estado actual
var hitstun_time := 0.0            # cuánto durará el aturdimiento actual
var respawn_time := 0.0
var drop_time := 0.0               # > 0 mientras atraviesa una plataforma
var air_jumps_left := 0
var spawn_position := Vector2.ZERO
var prefix := "p1_"                # prefijo de las acciones del Input Map ("p1_" o "p2_")
var attack_hit := []               # a quién ya golpeó este ataque (para no golpear dos veces)
var was_on_floor := false
var prev_vy := 0.0

# --- red (ver NetSync.gd) ---
const NET_ACTIONS := ["left", "right", "jump", "down", "attack", "special"]   # orden de los bits que viajan por la red
var net_remote := false            # true = lo maneja otro jugador por la red (lee net_held/net_just en vez del teclado)
var net_held := 0                  # botones mantenidos (máscara de bits, NET_ACTIONS)
var net_just := 0                  # botones recién pulsados en este paso de física
var net_puppet := false            # true = copia pasiva en el cliente

onready var sprite = $Sprite

# Efectos visuales (assets/shaders/fighter_fx.shader): destello al golpear y disolución al reaparecer.
const FX_SHADER := preload("res://assets/shaders/fighter_fx.shader")
const FLASH_TIME := 0.14          # cuánto dura el destello blanco al recibir un golpe
const DISSOLVE_TIME := 0.5        # cuánto dura la aparición disolviéndose al reaparecer
var _fx_mat: ShaderMaterial
var _fx_flash := 0.0
var _fx_dissolve := 0.0
onready var hitbox = $Hitbox
onready var tag = $Tag


# ============================================================================
# 3. CONFIGURACIÓN INICIAL  (la llama Arena.gd justo después de crear al luchador)
# ============================================================================
func apply_data(d) -> void:
	stats = d
	display_name = d.display_name
	move_speed = d.move_speed
	accel = d.accel
	air_accel = d.air_accel
	jump_speed = d.jump_speed
	gravity = d.gravity
	max_fall_speed = d.max_fall_speed
	max_air_jumps = d.max_air_jumps
	attack_damage = d.attack_damage
	attack_knockback = d.attack_knockback
	attack_startup = d.attack_startup
	attack_active = d.attack_active
	attack_total = d.attack_total
	special_cooldown = d.special_cooldown
	max_stocks = d.max_stocks


func setup(id: int, pos: Vector2, face: int) -> void:
	player_id = id
	prefix = "p%d_" % id
	position = pos
	spawn_position = pos
	facing = face
	stocks = max_stocks
	tag.text = "P%d" % id
	tag.add_color_override("font_color", Color(0.95, 0.3, 0.3) if id == 1 else Color(0.25, 0.55, 1.0))
	_apply_facing()


# ============================================================================
# 4. ENTRADA  (lee el Input Map con el prefijo del jugador: p1_left, p2_jump...)
# ============================================================================
func _pressed(action: String) -> bool:
	if not input_enabled:
		return false
	if net_remote:                                   # jugador en red: sus botones llegan por NetSync.gd
		return _net_bit(net_held, action)
	return Input.is_action_pressed(prefix + action)


func _just(action: String) -> bool:
	if not input_enabled:
		return false
	if net_remote:
		return _net_bit(net_just, action)
	return Input.is_action_just_pressed(prefix + action)


func _net_bit(mask: int, action: String) -> bool:
	var i = NET_ACTIONS.find(action)
	return i >= 0 and ((mask >> i) & 1) == 1


# Modo "fantasma" (cliente de red): no simula nada; NetSync.gd le pone la posición, el sprite y las variables
# que manda el anfitrión. Aquí solo se apaga lo que podría hacer daño o cambiar cosas por su cuenta.
func net_make_puppet() -> void:
	net_puppet = true
	set_physics_process(false)
	set_process(false)
	hitbox.monitoring = false
	hitbox.monitorable = false
	sprite.playing = false


func _axis() -> int:
	return int(_pressed("right")) - int(_pressed("left"))


# ============================================================================
# 5. BUCLE PRINCIPAL  (se ejecuta 60 veces por segundo)
# ============================================================================
func _physics_process(delta: float) -> void:
	_tick_timers(delta)

	if state != State.SPECIAL:
		special_stun = 0.0
	if state == State.SPECIAL and special_stun > 0.0:
		# Golpeado durante una especial: sale volando sin control, pero la especial sigue
		# (sus anzuelos, rocas, nubes... siguen en pie). Su lógica espera a que pase el golpe.
		special_stun = max(0.0, special_stun - delta)
		var fr = Config.HURT_FRICTION_GROUND if is_on_floor() else Config.HURT_FRICTION_AIR
		velocity.x = move_toward(velocity.x, 0.0, fr * delta)
	else:
		match state:
			State.NORMAL:
				_state_normal(delta)
			State.ATTACK:
				_state_attack(delta)
			State.SPECIAL:
				_state_special(delta)
			State.HURT:
				_state_hurt(delta)
			State.DEAD:
				_state_dead(delta)
				return

	if not frozen:
		prev_vy = velocity.y
		velocity.y = min(velocity.y + gravity * delta, max_fall_speed)
		velocity = move_and_slide(velocity, Vector2.UP)
		_after_move()


func _tick_timers(delta: float) -> void:
	if wrapped_time > 0.0:
		wrapped_time -= delta
		if wrapped_time <= 0.0 and state != State.DEAD:
			frozen = false                       # se acabó el enredo: vuelve la gravedad
	if special_timer > 0.0:
		special_timer = max(0.0, special_timer - delta)
	if invuln_timer > 0.0:
		invuln_timer -= delta
		sprite.modulate.a = 0.35 if int(invuln_timer * 14.0) % 2 == 0 else 1.0   # parpadeo
		if invuln_timer <= 0.0:
			sprite.modulate.a = 1.0
	if drop_time > 0.0:
		drop_time -= delta
		if drop_time <= 0.0:
			collision_mask = Config.MASK_FIGHTER_NORMAL    # vuelve a pisar plataformas
	_tick_fx(delta)
	state_time += delta


# Destello y disolución del Sprite (ver fighter_fx.shader).
func _tick_fx(delta: float) -> void:
	_fx_flash = max(0.0, _fx_flash - delta / FLASH_TIME)
	_fx_dissolve = max(0.0, _fx_dissolve - delta / DISSOLVE_TIME)
	if _fx_flash <= 0.0 and _fx_dissolve <= 0.0 and _fx_mat == null:
		return                                   # nada que dibujar: no creamos el material
	if _fx_mat == null:
		_fx_mat = ShaderMaterial.new()
		_fx_mat.shader = FX_SHADER
		sprite.material = _fx_mat
	_fx_mat.set_shader_param("flash", _fx_flash)
	_fx_mat.set_shader_param("dissolve", _fx_dissolve)


func _after_move() -> void:
	var on_floor = is_on_floor()
	if on_floor and not was_on_floor and prev_vy > Config.LAND_SOUND_MIN_SPEED and state != State.SPECIAL:
		_sfx($SfxLand)
	was_on_floor = on_floor
	if (state != State.SPECIAL or special_stun > 0.0) and _outside_blast_zone():
		_die()


func _outside_blast_zone() -> bool:
	return position.x < Config.BLAST_LEFT or position.x > Config.BLAST_RIGHT \
		or position.y < Config.BLAST_TOP or position.y > Config.BLAST_BOTTOM


# ============================================================================
# 6. ESTADOS
# ============================================================================

# ---- NORMAL: correr, saltar, atravesar plataformas, iniciar golpe o especial
func _state_normal(delta: float) -> void:
	var dir = _axis()
	var on_floor = is_on_floor()
	if on_floor:
		air_jumps_left = max_air_jumps
	var a = accel if on_floor else air_accel
	if dir != 0:
		velocity.x = move_toward(velocity.x, dir * move_speed, a * delta)
		facing = dir
	else:
		velocity.x = move_toward(velocity.x, 0.0, (a if on_floor else air_accel * Config.AIR_BRAKE_FACTOR) * delta)

	if _just("jump"):
		if on_floor:
			velocity.y = -jump_speed
			_sfx($SfxJump)
		elif air_jumps_left > 0:
			air_jumps_left -= 1
			velocity.y = -jump_speed * Config.AIR_JUMP_MULTIPLIER
			_sfx($SfxJump)

	if on_floor and _just("down"):      # atravesar plataformas finas: ignora la capa 3 un momento
		collision_mask = Config.MASK_FIGHTER_DROP
		drop_time = Config.DROP_THROUGH_TIME
		velocity.y = Config.DROP_THROUGH_SPEED

	if _just("attack"):
		_start_attack()
		return
	if _just("special") and special_timer <= 0.0:
		if _can_special():
			_start_special()
			return
		_sfx($SfxNope)                   # sonido de "no se puede"
	_update_animation()


# ---- ATTACK: golpe básico. Daña solo entre attack_startup y attack_startup + attack_active
func _start_attack() -> void:
	state = State.ATTACK
	state_time = 0.0
	attack_hit.clear()
	_play("attack", true)
	_sfx($SfxSwing)


func _state_attack(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, Config.ATTACK_FRICTION * delta)
	if state_time >= attack_startup and state_time <= attack_startup + attack_active:
		for body in hitbox.get_overlapping_bodies():
			if body != self and not attack_hit.has(body) and body.has_method("take_hit"):
				attack_hit.append(body)
				body.take_hit(attack_damage, Vector2(facing * attack_knockback.x, attack_knockback.y), self)
	if state_time >= attack_total:
		state = State.NORMAL


# ---- HURT: aturdido tras un golpe (sale volando, sin control)
func _state_hurt(delta: float) -> void:
	var friction = Config.HURT_FRICTION_GROUND if is_on_floor() else Config.HURT_FRICTION_AIR
	velocity.x = move_toward(velocity.x, 0.0, friction * delta)
	if state_time >= hitstun_time:
		state = State.NORMAL


# ---- DEAD: fuera de juego hasta reaparecer
func _state_dead(delta: float) -> void:
	respawn_time -= delta
	if respawn_time <= 0.0 and stocks > 0:
		_respawn()


# ============================================================================
# 7. GANCHOS PARA LAS HABILIDADES ESPECIALES  (los sobrescribe cada personaje)
# ============================================================================
# ¿Se puede usar el especial ahora?  (el Topo, por ejemplo, solo desde el suelo)
func _can_special() -> bool:
	return true


# Se llama una vez al pulsar el botón. Debe poner state = State.SPECIAL,
# reiniciar state_time, empezar la animación/sonido y activar special_timer.
func _start_special() -> void:
	pass


# Se llama cada frame mientras state == SPECIAL. Cuando termine debe volver a
# state = State.NORMAL.
func _state_special(_delta: float) -> void:
	state = State.NORMAL


# ============================================================================
# 8. DAÑO, KO Y REAPARICIÓN
# ============================================================================

# Altura y del suelo PRINCIPAL (capa 1, sin plataformas finas) justo debajo de
# (x, y). Devuelve -1 si no hay suelo. Lo usa el Topo para saber dónde emerger.
func floor_y_below(x: float, y: float) -> float:
	var hit = get_world_2d().direct_space_state.intersect_ray(
		Vector2(x, y), Vector2(x, y + 1400.0), [self], Config.BIT_GROUND)
	if hit.empty():
		return -1.0
	return hit.position.y


# El rival vivo más cercano (o null). Lo usan los especiales que apuntan al rival (Topo, Likan, Aukin).
func _find_target():
	var best = null
	var best_d = INF
	for f in get_tree().get_nodes_in_group("fighters"):
		if f == self or f.is_dead():
			continue
		var d = global_position.distance_to(f.global_position)
		if d < best_d:
			best_d = d
			best = f
	return best


func is_dead() -> bool:
	return state == State.DEAD


func is_invulnerable() -> bool:
	return invulnerable or invuln_timer > 0.0 or state == State.DEAD


# Atrapa al luchador en el sitio durante "duration" segundos (sin control, sin gravedad).
# Lo usan los tallarines del Aukin (scripts/effects/Noodles.gd), SIEMPRE justo después de un
# take_hit() que devolvió true (si es invulnerable no hay enredo). Se suelta solo al acabar el
# tiempo, o antes con release_entangle().
func entangle(duration: float) -> void:
	wrapped_time = duration
	hitstun_time = duration + 0.05
	if state == State.SPECIAL:
		special_stun = max(special_stun, duration)   # si ya está en una especial, la especial sigue
	else:
		state = State.HURT
		state_time = 0.0
	velocity = Vector2.ZERO
	frozen = true


func release_entangle() -> void:
	wrapped_time = 0.0
	frozen = false


# Lo llaman los golpes, la gaviota, el Topo... para dañar a este luchador.
#   damage    : % que se suma
#   knockback : empuje base (ya con el signo de x según la dirección del golpe)
# Devuelve false si no le hizo nada (invulnerable).
func take_hit(damage: float, knockback: Vector2, attacker = null) -> bool:
	if is_invulnerable():
		return false
	percent += damage
	velocity = knockback * (1.0 + percent / Config.KNOCKBACK_GROWTH)      # más daño = sale más lejos
	hitstun_time = clamp(Config.HITSTUN_BASE + percent * Config.HITSTUN_PER_PERCENT, Config.HITSTUN_BASE, Config.HITSTUN_MAX)
	if state == State.SPECIAL:
		special_stun = hitstun_time              # NO cancela la especial: solo pierde el control un rato
	else:
		state = State.HURT
		state_time = 0.0
		if velocity.x != 0.0:
			facing = -int(sign(velocity.x))      # mira hacia quien lo golpeó
		_play("hurt", true)
	_fx_flash = 1.0
	_sfx($SfxHit)
	_spawn_spark(global_position)
	_shake(Config.SHAKE_ON_HIT_BASE + min(percent / Config.SHAKE_ON_HIT_PERCENT_DIV, Config.SHAKE_ON_HIT_MAX_EXTRA))
	emit_signal("hit_taken", self, damage)
	return true


func _die() -> void:
	if state == State.DEAD:
		return
	state = State.DEAD
	stocks -= 1
	respawn_time = Config.RESPAWN_DELAY
	velocity = Vector2.ZERO
	invulnerable = false
	frozen = false
	wrapped_time = 0.0
	special_stun = 0.0
	collision_layer = 0                  # nadie lo golpea mientras está fuera
	sprite.visible = false
	tag.visible = false
	_sfx($SfxKo)
	# destello en el borde de la pantalla por donde salió
	var m = Config.KO_SPARK_MARGIN
	_spawn_spark(Vector2(clamp(position.x, m, Config.SCREEN_SIZE.x - m), clamp(position.y, m, Config.SCREEN_SIZE.y - m)))
	_shake(Config.SHAKE_ON_KO)
	emit_signal("knocked_out", self)


func _respawn() -> void:
	position = Config.RESPAWN_POSITION
	velocity = Vector2.ZERO
	percent = 0.0
	state = State.NORMAL
	state_time = 0.0
	collision_layer = Config.BIT_FIGHTER
	collision_mask = Config.MASK_FIGHTER_NORMAL
	sprite.visible = true
	tag.visible = true
	invuln_timer = Config.RESPAWN_INVULNERABLE_TIME
	_fx_dissolve = 1.0                       # aparece disolviéndose desde el aire
	facing = 1 if position.x < Config.SCREEN_SIZE.x / 2.0 else -1
	_play("fall", true)


func _spawn_spark(pos: Vector2) -> void:
	var spark = SPARK_SCENE.instance()
	get_parent().add_child(spark)
	spark.global_position = pos


# Avisa a la arena (grupo "arena") para que tiemble la pantalla.
func _shake(amount: float) -> void:
	get_tree().call_group("arena", "shake", amount)


# ============================================================================
# 9. ANIMACIÓN Y SONIDO
# ============================================================================
# El SpriteFrames del personaje debe tener estas animaciones:
#   idle, run, jump, fall, hurt, attack   (+ las de su especial)
func _update_animation() -> void:
	var anim = "idle"
	if not is_on_floor():
		anim = "jump" if velocity.y < 0.0 else "fall"
	elif abs(velocity.x) > 30.0:
		anim = "run"
	_play(anim)


# Refleja el sprite y el área de golpe según hacia dónde mira.
func _apply_facing() -> void:
	sprite.flip_h = facing < 0
	hitbox.position = Vector2(Config.HITBOX_OFFSET.x * facing, Config.HITBOX_OFFSET.y)


func _play(anim: String, restart := false) -> void:
	_apply_facing()
	if not sprite.frames.has_animation(anim):
		return
	if sprite.animation != anim or restart:
		sprite.animation = anim
		sprite.frame = 0
		sprite.play(anim)


func _sfx(player) -> void:
	if player != null and player.stream != null:
		player.pitch_scale = rand_range(0.96, 1.05)      # variación leve para que no suene siempre igual
		player.play()
