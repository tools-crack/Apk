extends "res://scripts/fighters/Fighter.gd"
# ============================================================================
#  Aukin.gd  —  especial "Tallarines enredadores"
# ----------------------------------------------------------------------------
#  Al pulsar el botón Aukin vierte tallarines hacia el suelo (animación
#  "special") y, a los noodle_spawn_delay segundos, hace brotar una columna de
#  tallarines (Noodles.tscn) en el suelo o plataforma que hay BAJO EL RIVAL
#  en ese momento. Los tallarines envuelven al rival, lo aprietan varias veces
#  y lo lanzan. Todo el comportamiento de los tallarines está en
#  scripts/effects/Noodles.gd.
#
#  REGLAS
#   - Necesita un rival vivo (si no lo hay, suena "no se puede").
#   - Si el rival está en el aire, los tallarines brotan del suelo bajo él; solo
#     lo agarran si está lo bastante bajo (alcanzan noodle_height px de altura).
#   - Mientras los tallarines estén arriba (noodle_up_time) atrapan a quien entre en
#     su zona, no solo a quien estaba al brotar. Cada rival se atrapa una vez por ataque.
#   - ESQUIVABLE: los tallarines asoman special_windup segundos antes de subir.
#
#  Números que puedes tocar en characters/aukin.tres:
#     special_cooldown     recarga
#     special_damage       % de daño TOTAL (se reparte entre los apretones)
#     special_knockback    empuje del lanzamiento final
#     special_windup       aviso (puntas asomando) antes de que suban
#     noodle_zone_width    ancho de la zona de tallarines (px)
#     noodle_squeezes      número de apretones (golpes de daño)
#     noodle_hold_time     segundos que mantiene atrapado a cada rival
#     noodle_height        altura de los tallarines y de la zona de agarre (px)
#     noodle_rise_time     segundos que tardan en subir
#     noodle_up_time       segundos que se quedan arriba atrapando
#     noodle_retract_time  segundos que tardan en bajar
#
#  Números de este archivo (atados a la animación "special": 3 cuadros a 8 fps):
#     noodle_spawn_delay  cuándo brotan los tallarines       noodle_total_time  cuándo recupera el control
# ============================================================================

const NOODLES_SCENE := preload("res://scenes/effects/Noodles.tscn")

var noodles_spawned := false
var target = null


# Necesita un rival al que apuntar.
func _can_special() -> bool:
	return _find_target() != null


func _start_special() -> void:
	state = State.SPECIAL
	state_time = 0.0
	noodles_spawned = false
	special_timer = special_cooldown
	target = _find_target()
	velocity.x *= 0.3
	_play("special", true)
	_sfx($SfxSpecial)


func _state_special(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 1500.0 * delta)
	if not noodles_spawned and state_time >= stats.noodle_spawn_delay:
		noodles_spawned = true
		_spawn_noodles()
	if state_time >= stats.noodle_total_time:
		state = State.NORMAL


# Hace brotar los tallarines en la superficie bajo el rival.
func _spawn_noodles() -> void:
	if target == null or not is_instance_valid(target) or target.is_dead():
		return
	var x = target.global_position.x
	var y = _surface_y_below(target, x)
	if y < 0.0:
		return                                           # no hay nada bajo el rival (está fuera del mapa)
	var n = NOODLES_SCENE.instance()
	n.setup(self, Vector2(x, y))                         # ANTES de add_child
	get_parent().add_child(n)


# y de la superficie (suelo o plataforma) justo debajo del rival; -1 si no hay.
func _surface_y_below(rival, x: float) -> float:
	var hit = get_world_2d().direct_space_state.intersect_ray(
		Vector2(x, rival.global_position.y), Vector2(x, rival.global_position.y + 1400.0),
		[self, rival], Config.BIT_GROUND | Config.BIT_PLATFORM)
	if hit.empty():
		return -1.0
	return hit.position.y
