extends "res://scripts/fighters/Fighter.gd"
# ============================================================================
#  Topo.gd  —  especial "Excavación sorpresa"
# ----------------------------------------------------------------------------
#  Se hunde en la tierra, viaja bajo tierra como un montículo y sale junto al
#  rival golpeándolo hacia arriba.
#
#  REGLAS
#   - Solo se usa desde el SUELO PRINCIPAL: no desde plataformas ni en el aire.
#   - Siempre sale sobre el suelo principal, nunca en el aire (aunque el rival
#     esté en una plataforma).
#   - El montículo avisa dónde va a salir y el golpe llega un instante después
#     de emerger (dig_emerge_delay), así el rival puede saltar o alejarse.
#
#  FASES  (variable "phase")
#     DIVE   se hunde (animación "dive")        -> invulnerable
#     UNDER  viaja bajo tierra como montículo   -> invulnerable, sin colisión
#     EMERGE sale (animación "emerge") y golpea
#
#  Números que puedes tocar en characters/topo.tres:
#     special_cooldown, special_damage, special_knockback,
#     dig_speed        velocidad del montículo
#     special_windup       tiempo MÍNIMO bajo tierra (aviso para el rival)
#     dig_emerge_delay  segundos entre emerger y golpear
#
#  Números de este archivo (atados a las animaciones):
#     dig_dive_time 0.42 = 5 cuadros de "dive" a 12 fps      dig_emerge_end 0.42
# ============================================================================

enum Phase { DIVE, UNDER, EMERGE }


var phase = Phase.DIVE
var phase_time := 0.0
var target = null                # el rival al que persigue
var start_x := 0.0
var under_floor_y := 0.0
var emerge_hit_done := false

onready var mound = $Mound                 # el montículo de tierra que viaja
onready var mound_trail = $Mound/Trail
onready var dirt_burst = $DirtBurst        # chorro de tierra al hundirse/emerger
onready var special_area = $SpecialArea    # zona donde golpea al emerger


func _ready() -> void:
	mound.visible = false


# Solo desde el suelo principal (no desde plataformas ni en el aire).
func _can_special() -> bool:
	return _on_main_floor()


func _on_main_floor() -> bool:
	if not is_on_floor():
		return false
	var fy = floor_y_below(global_position.x, global_position.y)
	return fy > 0.0 and abs(fy - (global_position.y + Config.FEET_OFFSET)) < 8.0


func _start_special() -> void:
	state = State.SPECIAL
	state_time = 0.0
	phase = Phase.DIVE
	phase_time = 0.0
	special_timer = special_cooldown
	invulnerable = true
	frozen = true
	velocity = Vector2.ZERO
	target = _find_target()
	start_x = position.x
	_play("dive", true)
	_sfx($SfxSpecial)
	_burst_at_feet()


func _state_special(delta: float) -> void:
	phase_time += delta
	match phase:
		Phase.DIVE:
			if phase_time >= stats.dig_dive_time:
				_enter_under()
		Phase.UNDER:
			_process_under(delta)
		Phase.EMERGE:
			_process_emerge()


# ---- UNDER: el luchador desaparece y un montículo viaja por el suelo
func _enter_under() -> void:
	phase = Phase.UNDER
	phase_time = 0.0
	under_floor_y = floor_y_below(global_position.x, global_position.y)
	if under_floor_y < 0.0:
		under_floor_y = stats.dig_fallback_floor_y
	sprite.visible = false
	tag.visible = false
	collision_layer = 0              # nadie puede golpearlo bajo tierra
	mound.visible = true
	mound.global_position = Vector2(global_position.x, under_floor_y)
	mound_trail.emitting = true
	_sfx($SfxRumble)


func _process_under(delta: float) -> void:
	var tx = _target_x()
	var mx = move_toward(mound.global_position.x, tx, stats.dig_speed * delta)
	mound.global_position.x = mx
	var arrived = abs(mx - tx) < 6.0 and phase_time >= stats.special_windup
	if arrived or phase_time >= stats.dig_under_max:
		_enter_emerge()


# ---- EMERGE: reaparece sobre el SUELO (nunca en el aire) y golpea tras dig_emerge_delay
func _enter_emerge() -> void:
	phase = Phase.EMERGE
	phase_time = 0.0
	emerge_hit_done = false
	var ex = mound.global_position.x
	var fy = floor_y_below(ex, 0.0)  # rayo desde arriba: siempre cae sobre el suelo principal
	if fy < 0.0:
		fy = stats.dig_fallback_floor_y
	if ex != start_x:
		facing = 1 if ex > start_x else -1
	global_position = Vector2(ex, fy - Config.FEET_OFFSET)
	velocity = Vector2.ZERO
	mound.visible = false
	mound_trail.emitting = false
	sprite.visible = true
	tag.visible = true
	collision_layer = Config.BIT_FIGHTER
	z_index = 2                      # se dibuja por encima del rival al emerger
	_play("emerge", true)
	_sfx($SfxEmerge)
	_burst_at_feet()
	_shake(7.0)


func _process_emerge() -> void:
	if not emerge_hit_done and phase_time >= stats.dig_emerge_delay:
		emerge_hit_done = true
		for body in special_area.get_overlapping_bodies():
			if body != self and body.has_method("take_hit"):
				var k = stats.special_knockback
				body.take_hit(stats.special_damage, Vector2(facing * k.x, k.y), self)
	if phase_time >= stats.dig_emerge_end:
		z_index = 0
		invulnerable = false
		frozen = false
		state = State.NORMAL


# ------------------------------------------------------------------ ayudas
# El rival vivo más cercano.


func _target_valid() -> bool:
	return target != null and is_instance_valid(target) and not target.is_dead()


func _target_x() -> float:
	if _target_valid():
		return target.global_position.x
	return start_x + facing * 260.0      # sin rival: avanza hacia donde mira


func _burst_at_feet() -> void:
	dirt_burst.position = Vector2(0, Config.FEET_OFFSET - 2)
	dirt_burst.restart()
	dirt_burst.emitting = true
