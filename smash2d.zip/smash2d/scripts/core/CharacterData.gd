class_name CharacterData
extends Resource
# ============================================================================
#  CharacterData.gd  —  la "ficha" de un personaje
# ----------------------------------------------------------------------------
#  Cada personaje tiene un archivo characters/<id>.tres de este tipo. Ábrelo en
#  el Inspector de Godot (doble clic sobre el .tres): ahí cambias nombre, color,
#  retrato, velocidad, salto, daño, vidas y parámetros del especial SIN tocar
#  código.
#
#  Game.gd detecta solo todos los .tres de la carpeta characters/ (excepto los
#  que empiezan con "_"), así que para añadir un personaje basta con crear su
#  .tres (ver docs/06_CREAR_UN_PERSONAJE_NUEVO.md).
#
#  Los valores de aquí se copian al luchador en Fighter.apply_data().
# ============================================================================

# ------------------------------------------------------------------ Identidad
export var id := ""                        # nombre interno, p. ej. "topo". Si lo dejas vacío se usa el nombre del archivo.
export var order := 100                    # posición en la selección de personajes (menor = más a la izquierda)
export var display_name := "Luchador"      # nombre que se ve en menús y en el HUD
export var special_name := "Especial"      # nombre de la habilidad especial
export(String, MULTILINE) var description := ""   # texto explicativo en la pantalla de selección
export var color := Color.white            # color de marcos, nombre y HUD
export(Texture) var portrait               # imagen grande de la selección
export(PackedScene) var scene              # escena del luchador (scenes/fighters/*.tscn)

# ----------------------------------------------------------------- Movimiento
export(float, 50, 800, 5) var move_speed := 300.0          # velocidad máxima al correr (px/s)
export(float, 200, 6000, 50) var accel := 2600.0           # aceleración en el suelo
export(float, 200, 6000, 50) var air_accel := 1500.0       # aceleración en el aire
export(float, 200, 1400, 10) var jump_speed := 720.0       # fuerza del salto
export(float, 400, 4000, 50) var gravity := 1800.0         # gravedad
export(float, 200, 2000, 50) var max_fall_speed := 1000.0  # velocidad máxima de caída
export(int, 0, 5) var max_air_jumps := 1                   # saltos extra en el aire (1 = doble salto)

# ------------------------------------------------------------ Golpe básico
export(float, 0, 40, 0.5) var attack_damage := 6.0         # % de daño que causa
export var attack_knockback := Vector2(320, -260)          # empuje: x se refleja según hacia dónde mira, y negativo = hacia arriba
export(float, 0, 0.5, 0.01) var attack_startup := 0.08     # segundos desde que pulsas hasta que el golpe empieza a dañar
export(float, 0.02, 0.5, 0.01) var attack_active := 0.10   # segundos que el golpe daña
export(float, 0.05, 1, 0.01) var attack_total := 0.26      # duración total de la animación (hasta poder moverte)
export(int, 1, 9) var max_stocks := 3                      # vidas

# ----------------------------------------------------------- Habilidad especial
# Cada personaje tiene UNA especial. Los campos "comunes" son para todas. Los demás llevan el
# nombre de su habilidad (gull_, dig_, rock_, noodle_, smoke_, spike_, hook_) y SOLO los lee esa
# habilidad. Qué hace cada número: docs/16_PARAMETROS_DE_HABILIDADES.md
export(float, 0.5, 30, 0.5) var special_cooldown := 3.0    # COMÚN: segundos de recarga
export(float, 0, 60, 0.5) var special_damage := 10.0       # COMÚN: % de daño TOTAL que hace la especial
export var special_knockback := Vector2(400, -300)         # COMÚN: empuje base (se multiplica por el % del rival; x se refleja según el lado)
export(float, 0, 3, 0.05) var special_windup := 0.35       # COMÚN: aviso antes de que la especial haga efecto

# --- Gaviotero: Gaviota veloz
export(float, 0, 2000, 10) var gull_speed := 470.0         # velocidad de la gaviota (px/s)

# --- Topo: Excavación sorpresa
export(float, 0, 2000, 10) var dig_speed := 520.0          # velocidad del montículo bajo tierra (px/s)
export(float, 0, 3, 0.01) var dig_emerge_delay := 0.22     # segundos entre que emerge y golpea (tiempo para reaccionar)

# --- Likan: Lluvia de rocas
export(float, 0, 2000, 10) var rock_speed := 900.0         # velocidad de caída de cada roca (px/s)
export(int, 1, 20) var rock_count := 5                     # cuántas rocas caen
export(float, 0, 1200, 10) var rock_zone_width := 540.0    # ancho (px) de la franja donde caen, centrada en el rival
export(float, 0, 3, 0.01) var rock_gap_time := 0.2         # segundos entre una roca y la siguiente
export(float, 0, 3, 0.01) var rock_spawn_delay := 0.18     # segundos desde el inicio hasta que invoca las rocas (animación)
export(float, 0, 3, 0.01) var rock_total_time := 0.42      # segundos hasta que Likan recupera el control (debe ser >= rock_spawn_delay)
export(float, -2000, 4000, 10) var rock_zone_min_x := 300.0  # límite izquierdo (x) donde pueden caer las rocas
export(float, -2000, 4000, 10) var rock_zone_max_x := 980.0  # límite derecho (x) donde pueden caer las rocas
export(float, -2000, 0, 10) var rock_sky_y := -60.0        # altura (y) desde la que empiezan a caer las rocas
export(float, 0, 3000, 10) var rock_no_floor_y := 760.0    # si no hay suelo bajo una roca, cae hasta esta altura (y)

# --- Aukin: Tallarines enredadores
export(float, 0, 1200, 10) var noodle_zone_width := 96.0   # ancho (px) de la zona de tallarines
export(int, 1, 20) var noodle_squeezes := 3                # apretones (golpes) mientras lo tienen atrapado; reparten special_damage
export(float, 0, 3, 0.01) var noodle_hold_time := 0.9      # segundos que el rival queda atrapado

# --- Ñanco: Humo de cigarro
export(float, 0, 1200, 10) var smoke_length := 280.0       # largo (px) de la nube
export(float, 0, 3, 0.01) var smoke_duration := 0.5        # segundos que dura la nube
export(float, 0, 6000, 50) var smoke_push_accel := 2200.0  # empuje continuo (px/s por segundo) a quien esté dentro

# --- Winkul: Pinchos al borde
export(int, 1, 20) var spike_count := 6                    # cuántos grupos de pinchos salen
export(float, 0, 400, 5) var spike_spacing := 80.0         # separación (px) entre grupos
export(float, 0, 3, 0.01) var spike_gap_time := 0.09       # segundos entre un grupo y el siguiente

# --- Jorge: Caña de pescar
export(float, 0, 2000, 10) var hook_speed := 760.0         # velocidad del anzuelo al volar (px/s)
export(float, 0, 1200, 10) var hook_range := 420.0         # alcance máximo del anzuelo (px)
export(float, 0, 3, 0.01) var hook_reel_time := 0.25       # segundos que tarda en recoger al rival

# --- Gaviotero (extra): posición y aspecto de la gaviota
export(float, 0, 2, 0.01) var gull_recover_time := 0.24    # segundos que Gaviotero tarda en recuperar el control tras soltar la gaviota
export(float, -2000, 0, 10) var gull_left_limit := -240.0  # la gaviota desaparece al pasar este límite (x)
export(float, 0, 4000, 10) var gull_right_limit := 1520.0  # la gaviota desaparece al pasar este límite (x)
export(float, 0, 400, 5) var gull_spawn_ahead := 90.0      # distancia (px) delante de Gaviotero a la que aparece
export(float, 0, 60, 1) var gull_bob := 10.0               # amplitud del vaivén vertical (px)
export(float, 0, 1, 0.01) var gull_fade_in := 0.12         # segundos del fundido de aparición (solo visual)

# --- Topo (extra)
export(float, 0.05, 3, 0.01) var dig_dive_time := 0.42     # segundos de la animación de zambullida (bajo tierra, antes de emerger)
export(float, 0.05, 3, 0.01) var dig_emerge_end := 0.42    # segundos hasta que el Topo recupera el control tras emerger
export(float, 0, 2000, 10) var dig_fallback_floor_y := 480.0  # altura (y) del suelo si no se encuentra suelo bajo el Topo
export(float, 0.5, 6, 0.1) var dig_under_max := 2.0        # tope de seguridad (s) si el montículo no llega al rival

# --- Likan (extra): rocas
export(float, 0, 3, 0.05) var rock_linger := 0.8           # segundos que la roca sigue viva tras romperse (deja sonar)
export(float, 0, 30, 0.5) var rock_shake := 5.0            # temblor de cámara al caer
export(float, 0, 60, 1) var rock_jitter := 8.0             # variación aleatoria (px) en la x de cada roca

# --- Aukin (extra): tallarines
export(float, 30, 400, 5) var noodle_height := 130.0       # altura (px) de los tallarines y de la zona de agarre
export(float, 0.02, 1, 0.01) var noodle_rise_time := 0.14  # segundos que tardan en subir
export(float, 0.1, 5, 0.05) var noodle_up_time := 0.6      # segundos que se quedan arriba (siguen atrapando a quien entre)
export(float, 0, 3, 0.01) var noodle_spawn_delay := 0.18   # segundos desde el inicio hasta que brotan (animación)
export(float, 0, 3, 0.01) var noodle_total_time := 0.42    # segundos hasta que Aukin recupera el control
export(float, 0.05, 2, 0.01) var noodle_retract_time := 0.3  # segundos que tardan en bajar

# --- Ñanco (extra): nube
export(float, 0, 400, 5) var smoke_start_offset := 34.0    # dónde empieza la nube, delante de Ñanco (px)
export(float, 0, 300, 5) var smoke_height := 100.0         # alto de la nube (px)
export(float, 0, 2000, 10) var smoke_max_push := 620.0     # velocidad horizontal máxima que da el empujón
export(float, 0, 2, 0.01) var smoke_recover_time := 0.15   # segundos que Ñanco tarda en recuperar el control tras soplar
export(float, 0, 2, 0.05) var smoke_fade_time := 0.35      # segundos que tarda en disiparse

# --- Winkul (extra): pinchos
export(float, 0, 400, 5) var spike_start_offset := 90.0    # distancia (px) del primer grupo a Winkul
export(float, 10, 300, 2) var spike_height := 64.0         # alto de los pinchos (px)
export(float, 5, 80, 1) var spike_half_width := 22.0       # semiancho (px) de cada grupo
export(float, 0, 3, 0.01) var spike_spawn_delay := 0.2     # segundos desde el inicio hasta que aparecen las grietas
export(float, 0, 3, 0.01) var spike_total_time := 0.42     # segundos hasta que Winkul recupera el control
export(float, 0, 2, 0.01) var spike_up_time := 0.07        # segundos que tardan en salir
export(float, 0, 3, 0.01) var spike_hold_time := 0.35      # segundos que se quedan arriba
export(float, 0, 2, 0.01) var spike_retract_time := 0.2    # segundos que tardan en hundirse
export(float, 0, 20, 0.5) var spike_shake := 3.0           # temblor de cámara al salir

# --- Jorge (extra): anzuelo
export(float, 100, 5000, 50) var hook_return_speed := 1500.0  # velocidad (px/s) con la que vuelve si falla
export(float, 0, 1, 0.01) var hook_throw_delay := 0.12     # segundos del tirón hasta que suelta al rival (animación)
export(float, 0.05, 2, 0.01) var hook_throw_total := 0.32  # duración total del tirón (animación)
export(float, 0, 200, 2) var hook_front_distance := 56.0   # distancia (px) delante de Jorge donde queda el rival recogido
export(float, 0, 1, 0.05) var hook_grab_share := 0.25         # parte del daño que hace al enganchar (el resto, al lanzar)
export(float, 0, 5, 0.1) var hook_hold_buffer := 1.0          # segundos extra de inmovilización por seguridad
