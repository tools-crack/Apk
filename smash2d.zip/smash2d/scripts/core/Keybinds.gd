extends Node
# ============================================================================
#  Keybinds.gd  —  autoload "Keybinds"  (teclas de los dos jugadores)
# ----------------------------------------------------------------------------
#  Las teclas "de fábrica" siguen estando en Proyecto > Ajustes > Mapa de
#  entrada (acciones p1_left ... p2_special). Este script:
#    1. guarda esas teclas de fábrica (para poder "Restaurar"),
#    2. lee las teclas que el jugador cambió (user://controles.cfg) y las aplica
#       al InputMap al arrancar,
#    3. ofrece set_key() / reset() / key_name() para el menú "Controles".
#
#  Nada más del juego necesita saber de esto: los luchadores siguen leyendo las
#  acciones del InputMap (p1_left, p2_attack...).
#  Teclas reservadas (no se pueden asignar): Esc.
#  Si dos acciones quedan con la misma tecla, se INTERCAMBIAN (nunca se pierde
#  una acción sin tecla).
# ============================================================================

signal changed

const SAVE_PATH := "user://controles.cfg"
const ACTIONS := ["left", "right", "jump", "down", "attack", "special"]
const LABELS := {
	"left": "Izquierda", "right": "Derecha", "jump": "Saltar",
	"down": "Bajar / atravesar", "attack": "Golpe", "special": "Especial",
}
const RESERVED := [KEY_ESCAPE]

var defaults := {}        # "p1_left" -> scancode de fábrica


func _ready() -> void:
	_capture_defaults()
	load_from_disk()


# --------------------------------------------------------------- consulta
func action_name(player: int, a: String) -> String:
	return "p%d_%s" % [player, a]


func all_actions() -> Array:
	var out := []
	for p in [1, 2]:
		for a in ACTIONS:
			out.append(action_name(p, a))
	return out


func get_scancode(action: String) -> int:
	for ev in InputMap.get_action_list(action):
		if ev is InputEventKey:
			return ev.scancode
	return 0


func key_name(action: String) -> String:
	var code := get_scancode(action)
	if code == 0:
		return "?"
	var s := OS.get_scancode_string(code)
	return s if s != "" else "?"


func is_reserved(code: int) -> bool:
	return RESERVED.has(code)


# -------------------------------------------------------------- cambiar
# Asigna la tecla `code` a `action`. Si otra acción ya la usaba, esa recibe la
# tecla anterior de `action` (intercambio). Devuelve el nombre de la acción con
# la que se intercambió, o "" si no hubo choque.
func set_key(action: String, code: int) -> String:
	if is_reserved(code) or code == 0:
		return ""
	var old := get_scancode(action)
	var swapped := ""
	for other in all_actions():
		if other != action and get_scancode(other) == code:
			_apply(other, old)
			swapped = other
	_apply(action, code)
	save()
	emit_signal("changed")
	return swapped


# player: 1 o 2 restaura solo ese jugador; 0 restaura a los dos.
func reset(player := 0) -> void:
	for p in [1, 2]:
		if player != 0 and player != p:
			continue
		for a in ACTIONS:
			var act := action_name(p, a)
			_apply(act, defaults[act])
	save()
	emit_signal("changed")


# ------------------------------------------------------------ interno
func _apply(action: String, code: int) -> void:
	InputMap.action_erase_events(action)
	var ev := InputEventKey.new()
	ev.scancode = code
	InputMap.action_add_event(action, ev)


func _capture_defaults() -> void:
	defaults.clear()
	for act in all_actions():
		defaults[act] = get_scancode(act)


func save() -> void:
	var cfg := ConfigFile.new()
	for act in all_actions():
		cfg.set_value("teclas", act, get_scancode(act))
	var err := cfg.save(SAVE_PATH)
	if err != OK:
		push_warning("Keybinds: no se pudo guardar %s (error %d)" % [SAVE_PATH, err])


func load_from_disk() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	var seen := {}
	var wanted := {}
	for act in all_actions():
		var code: int = int(cfg.get_value("teclas", act, defaults[act]))
		if code == 0 or is_reserved(code) or seen.has(code):
			wanted.clear()            # archivo dañado o con choques: se ignora entero
			return
		seen[code] = true
		wanted[act] = code
	for act in wanted:
		_apply(act, wanted[act])
