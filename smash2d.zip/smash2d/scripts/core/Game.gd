extends Node
# ============================================================================
#  Game.gd  —  autoload "Game"
# ----------------------------------------------------------------------------
#  Datos que viven toda la sesión y se comparten entre escenas:
#    - CHARACTERS : todas las fichas de personaje (id -> CharacterData)
#    - ORDER      : los ids en el orden de la pantalla de selección
#    - selected   : qué personaje eligió cada jugador  [id_P1, id_P2]
#    - practice   : true si P2 es un muñeco de práctica
#    - STAGES / stage_index : los escenarios y cuál se eligió (ver STAGES abajo)
#    - música     : play_music() / stop_music()
#    - cambio de escena: goto() / goto_menu()
#
#  Los personajes NO se registran a mano: _load_characters() lee todos los
#  .tres de la carpeta characters/ (menos los que empiezan con "_").
# ============================================================================

# Música (OGG generados desde MIDI por tools/make_music.py; los .mid están en assets/music/midi/)
const MENU_MUSIC := "res://assets/music/menu_theme.ogg"          # menú principal y controles
const SELECT_MUSIC := "res://assets/music/select_theme.ogg"      # selección de personaje y de escenario
const BATTLE_MUSIC := "res://assets/music/battle_theme.ogg"      # combate en la Pradera (y por defecto)
const VICTORY_MUSIC := "res://assets/music/victory_theme.ogg"    # fanfarria al ganar (suena una vez)
const CHARACTERS_DIR := "res://characters"

# Escenarios. Para añadir uno: crea su escena en scenes/stages/ (la raíz se llama
# "Stage" y contiene Background, suelo y plataformas; copia una existente) y
# agrégalo a esta lista. "preview" es la imagen de la selección y "music" su música de combate.
const STAGES := [
	{"id": "pradera", "name": "Pradera soleada", "scene": "res://scenes/stages/Pradera.tscn",
		"preview": "res://assets/sprites/stage/bg.svg", "music": "res://assets/music/battle_theme.ogg",
		"desc": "Una isla grande de pasto con dos plataformas. El escenario clásico."},
	{"id": "desierto", "name": "Desierto al atardecer", "scene": "res://scenes/stages/Desierto.tscn",
		"preview": "res://assets/sprites/stage/bg_desierto.svg", "music": "res://assets/music/battle_desierto.ogg",
		"desc": "Suelo más angosto y una plataforma alta al centro. Cuidado con los bordes."},
	{"id": "azotea", "name": "Azotea nocturna", "scene": "res://scenes/stages/Azotea.tscn",
		"preview": "res://assets/sprites/stage/bg_azotea.svg", "music": "res://assets/music/battle_azotea.ogg",
		"desc": "Poco suelo y plataformas por todos lados: peleas en tres niveles."},
]

var CHARACTERS := {}      # id -> CharacterData
var ORDER := []           # ids ordenados por CharacterData.order (y luego por id)
var selected := []        # [id del P1, id del P2]
var practice := false     # true = P2 es un muñeco de práctica
var stage_index := 0      # escenario elegido (índice en STAGES)
var stage_random := false # true si lo eligió el azar (solo para mostrarlo)

var music_player: AudioStreamPlayer
var current_music := ""


func _ready() -> void:
	_load_characters()
	_default_selection()
	music_player = AudioStreamPlayer.new()
	music_player.volume_db = Config.MUSIC_VOLUME_DB
	add_child(music_player)


# ------------------------------------------------------------- personajes
func _load_characters() -> void:
	CHARACTERS.clear()
	ORDER.clear()
	for path in _character_files():
		var data = load(path)
		if data == null or not (data is CharacterData):
			push_warning("Game: %s no es un CharacterData, se ignora." % path)
			continue
		var id: String = data.id if data.id != "" else path.get_file().get_basename()
		CHARACTERS[id] = data
		ORDER.append(id)
	ORDER.sort_custom(self, "_sort_by_order")
	if ORDER.empty():
		push_error("Game: no hay personajes en %s" % CHARACTERS_DIR)


func _character_files() -> Array:
	var files := []
	var dir := Directory.new()
	if dir.open(CHARACTERS_DIR) != OK:
		return files
	dir.list_dir_begin(true, true)           # sin "." ni "..", sin ocultos
	var name = dir.get_next()
	while name != "":
		if not dir.current_is_dir():
			var n: String = name.trim_suffix(".remap")   # al exportar, Godot añade ".remap"
			if n.ends_with(".tres") and not n.begins_with("_"):
				files.append(CHARACTERS_DIR + "/" + n)
		name = dir.get_next()
	dir.list_dir_end()
	files.sort()
	return files


func _sort_by_order(a: String, b: String) -> bool:
	var oa: int = CHARACTERS[a].order
	var ob: int = CHARACTERS[b].order
	if oa != ob:
		return oa < ob
	return a < b


# Si todavía no se eligió nada (o el id ya no existe), P1 y P2 empiezan con
# el primer y el segundo personaje de la lista.
func _default_selection() -> void:
	if ORDER.empty():
		return
	var ok := selected.size() == 2
	for id in selected:
		if not CHARACTERS.has(id):
			ok = false
	if not ok:
		selected = [ORDER[0], ORDER[1] if ORDER.size() > 1 else ORDER[0]]


# -------------------------------------------------------------- escenarios
func current_stage() -> Dictionary:
	return STAGES[clamp(stage_index, 0, STAGES.size() - 1)]


func stage_index_of(id: String) -> int:
	for i in range(STAGES.size()):
		if STAGES[i]["id"] == id:
			return i
	return 0


# ------------------------------------------------------------------- música
# loop = false para jingles que suenan una sola vez (la fanfarria de victoria).
func play_music(path: String, loop := true) -> void:
	if current_music == path and music_player.playing:
		return
	var stream = load(path)
	if stream == null:
		return
	stream.loop = loop            # AudioStreamOGGVorbis: repetir en bucle (o no)
	music_player.stream = stream
	music_player.play()
	current_music = path


func stop_music() -> void:
	music_player.stop()
	current_music = ""


# ------------------------------------------------------- cambio de escena
func goto(scene_path: String) -> void:
	get_tree().change_scene(scene_path)


func goto_menu() -> void:
	if Net.is_active():
		Net.stop()                                  # salir al menú también cierra la conexión de red
	goto("res://scenes/ui/MainMenu.tscn")


# Botón "atrás" de Android: en el menú principal sale del juego, en cualquier otra pantalla vuelve al menú.
func _notification(what: int) -> void:
	if what == MainLoop.NOTIFICATION_WM_GO_BACK_REQUEST:
		var scene = get_tree().current_scene
		if scene != null and scene.filename.ends_with("MainMenu.tscn"):
			get_tree().quit()
		else:
			goto_menu()
