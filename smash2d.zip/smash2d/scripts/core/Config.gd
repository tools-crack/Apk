extends Node
# ============================================================================
#  Config.gd  —  autoload "Config"
# ----------------------------------------------------------------------------
#  Aquí están TODOS los números "globales" del juego: los que valen para
#  cualquier personaje o para la partida entera. Si quieres que el juego se
#  sienta distinto (más empuje, más tiempo de reaparición, otro mapa...), casi
#  siempre se cambia aquí y no hay que tocar nada más.
#
#  Lo que es de UN personaje (velocidad, salto, daño, vidas...) NO está aquí:
#  está en su archivo characters/<personaje>.tres (ver CharacterData.gd).
#
#  Se usa desde cualquier script como:  Config.BLAST_LEFT,  Config.SPAWN_POINTS ...
# ============================================================================

# ------------------------------------------------------------------ Pantalla
const SCREEN_SIZE := Vector2(1280, 720)     # debe coincidir con Proyecto > Ajustes > Display

# ------------------------------------------------------- Capas de colisión
# Son valores de máscara de bits (1, 2, 4...), los mismos de
# Proyecto > Ajustes > Nombres de capas > 2D Physics:
#   capa 1 "suelo"  = 1      capa 2 "luchadores" = 2      capa 3 "plataformas" = 4
const BIT_GROUND := 1
const BIT_FIGHTER := 2
const BIT_PLATFORM := 4
const MASK_FIGHTER_NORMAL := 5   # un luchador pisa suelo (1) + plataformas (4)
const MASK_FIGHTER_DROP := 1     # solo suelo (1): así atraviesa las plataformas finas

# ------------------------------------------------- Zona de KO (fin del mapa)
# Un luchador que sale de este rectángulo pierde una vida.
const BLAST_LEFT := -260.0
const BLAST_RIGHT := 1540.0
const BLAST_TOP := -320.0
const BLAST_BOTTOM := 900.0

# ------------------------------------------------------------------ Partida
const SPAWN_POINTS := [Vector2(500, 440), Vector2(780, 440)]   # [P1, P2]
const COUNTDOWN_SECONDS := 3          # cuenta atrás "3, 2, 1, ¡YA!"
const GO_MESSAGE_TIME := 0.8          # cuánto se ve el "¡YA!"
const PRACTICE_DUMMY_STOCKS := 99     # vidas del muñeco en modo práctica

# -------------------------------------------------------------- Reaparición
const RESPAWN_POSITION := Vector2(640, 120)   # cae desde arriba, al centro
const RESPAWN_DELAY := 1.6                    # segundos fuera de juego tras un KO
const RESPAWN_INVULNERABLE_TIME := 2.0        # segundos parpadeando sin poder ser golpeado

# --------------------------------------------------------- Daño y empuje
# Al recibir un golpe:
#   velocidad = empuje_del_golpe * (1 + porcentaje / KNOCKBACK_GROWTH)
# Cuanto MENOR es KNOCKBACK_GROWTH, más rápido vuelan los luchadores con daño alto.
const KNOCKBACK_GROWTH := 90.0
# Tiempo aturdido = HITSTUN_BASE + porcentaje * HITSTUN_PER_PERCENT  (con tope HITSTUN_MAX)
const HITSTUN_BASE := 0.2
const HITSTUN_PER_PERCENT := 0.002
const HITSTUN_MAX := 0.55

# ----------------------------------------------------- Cuerpo del luchador
const FEET_OFFSET := 40.0                # distancia del centro del luchador a sus pies
const HITBOX_OFFSET := Vector2(38, -6)   # posición del área de golpe (se refleja al mirar a la izquierda)
const KO_SPARK_MARGIN := 30.0            # el destello del KO aparece a esta distancia del borde

# ------------------------------------------------------ "Sensación" de juego
const AIR_JUMP_MULTIPLIER := 0.9         # el doble salto es un 90 % de potente
const AIR_BRAKE_FACTOR := 0.5            # frenado en el aire al soltar la dirección (x air_accel)
const ATTACK_FRICTION := 1800.0          # lo que frena al luchador mientras golpea
const HURT_FRICTION_GROUND := 900.0      # frenado mientras está aturdido en el suelo
const HURT_FRICTION_AIR := 250.0         # ...y en el aire (casi no frena: vuela lejos)
const DROP_THROUGH_TIME := 0.25          # segundos atravesando una plataforma al pulsar "abajo"
const DROP_THROUGH_SPEED := 120.0        # empujón hacia abajo para empezar a atravesarla
const LAND_SOUND_MIN_SPEED := 350.0      # velocidad de caída mínima para oír el golpe al aterrizar

# --------------------------------------------------------- Cámara y música
const SHAKE_ON_HIT_BASE := 4.0           # temblor de pantalla al recibir un golpe...
const SHAKE_ON_HIT_MAX_EXTRA := 8.0      # ...más hasta esto extra según el daño acumulado
const SHAKE_ON_HIT_PERCENT_DIV := 25.0   # (cada 25 % de daño suma 1 de temblor)
const SHAKE_ON_KO := 14.0
const SHAKE_DECAY := 45.0                # cuánto baja el temblor por segundo
const MUSIC_VOLUME_DB := -9.0
