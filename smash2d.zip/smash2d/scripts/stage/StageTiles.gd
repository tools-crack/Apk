tool
extends TileMap
# ============================================================================
#  StageTiles.gd  —  rellena un TileMap con el tileset del escenario
# ----------------------------------------------------------------------------
#  Se pone en un nodo TileMap con tile_set = resources/stage_tileset.tres. Al
#  entrar en el árbol dibuja una grilla de "cols" x "rows" tiles:
#    - fila de arriba = césped (esquinas superiores redondeadas)
#    - filas de abajo = tierra
#    - floating = true: la última fila tiene esquinas redondeadas (isla flotante)
#  Se cambia el tamaño desde el Inspector (cols, rows, floating).
#  OJO: solo dibuja. Las colisiones son los StaticBody2D de Arena.tscn.
# ============================================================================

export var cols := 10
export var rows := 3
export var floating := false


func _ready() -> void:
	_build()


func _build() -> void:
	clear()
	if tile_set == null:
		return
	# variantes de pasto; top_mid_c lleva florecitas y sale menos (1 de cada 5)
	var top_mid = []
	for n in ["top_mid", "top_mid_b", "top_mid", "top_mid_b", "top_mid_c"]:
		var id_n = tile_set.find_tile_by_name(n)
		if id_n != -1:                                   # por si un tileset propio no tiene alguna variante
			top_mid.append(id_n)
	var mid_fill = [tile_set.find_tile_by_name("mid"), tile_set.find_tile_by_name("mid_b")]
	var rng = RandomNumberGenerator.new()
	rng.seed = cols * 97 + rows * 13 + (1 if floating else 0)
	for x in range(cols):
		var left = x == 0
		var right = x == cols - 1
		for y in range(rows):
			var top = y == 0
			var bottom = y == rows - 1
			var id: int
			if floating and bottom:
				if left:
					id = tile_set.find_tile_by_name("bot_left")
				elif right:
					id = tile_set.find_tile_by_name("bot_right")
				else:
					id = tile_set.find_tile_by_name("bot_mid")
			elif top:
				if left:
					id = tile_set.find_tile_by_name("top_left")
				elif right:
					id = tile_set.find_tile_by_name("top_right")
				else:
					id = top_mid[rng.randi_range(0, top_mid.size() - 1)]
			else:
				if left:
					id = tile_set.find_tile_by_name("mid_left")
				elif right:
					id = tile_set.find_tile_by_name("mid_right")
				else:
					id = mid_fill[rng.randi_range(0, mid_fill.size() - 1)]
			set_cell(x, y, id)
