extends Sprite
# ============================================================================
#  Drift.gd  —  capa de fondo animada (nubes que avanzan, estrellas que titilan)
# ----------------------------------------------------------------------------
#  Se pone como script de un Sprite del fondo de un escenario.
#    speed   : px/s con que se desplaza (negativo = hacia la izquierda, 0 = quieta).
#              La imagen se repite sola, así que debe "encajar" consigo misma
#              por los lados (las tiras de make_stages.py ya lo hacen).
#    twinkle : cuánto titila su brillo (0 = nada, 0.5 = mucho)
# ============================================================================

export var speed := 6.0
export var twinkle := 0.0
export var twinkle_speed := 1.0

var _twin: Sprite
var _base_x := 0.0
var _off := 0.0
var _t := 0.0


func _ready() -> void:
	centered = false
	_base_x = position.x
	if speed != 0.0 and texture != null:
		_twin = Sprite.new()
		_twin.texture = texture
		_twin.centered = false
		_twin.position = Vector2(-texture.get_width() if speed > 0.0 else texture.get_width(), 0)
		add_child(_twin)


func _process(delta: float) -> void:
	_t += delta
	if _twin != null:
		_off = fmod(_off + speed * delta, float(texture.get_width()))
		position.x = _base_x + _off
	if twinkle > 0.0:
		modulate.a = 1.0 - twinkle * (0.5 + 0.5 * sin(_t * twinkle_speed * 2.0))
