extends Node2D
# ============================================================================
#  Arena.gd  —  la escena de combate (scenes/Arena.tscn)
# ----------------------------------------------------------------------------
#  Qué hace:
#    0. Instancia el escenario elegido (Game.current_stage(): scenes/stages/*.tscn).
#    1. Crea a los dos luchadores según Game.selected, les aplica su .tres
#       (apply_data) y los coloca en Config.SPAWN_POINTS.
#    2. Hace la cuenta atrás "3, 2, 1, ¡YA!" y luego les da el control.
#    3. Mueve la cámara para el temblor de pantalla (shake) cuando se lo piden.
#    4. Detecta el fin de partida (un luchador sin vidas) y la revancha.
#
#  Se mete en el grupo "arena" para que cualquier luchador pueda hacerla temblar
#  con:  get_tree().call_group("arena", "shake", fuerza)
#  Los luchadores se añaden al grupo "fighters" (así el Topo busca a su rival).
# ============================================================================

const NETSYNC := preload("res://scripts/net/NetSync.gd")
const TOUCH := preload("res://scripts/ui/TouchControls.gd")

onready var fighters_root = $Fighters
onready var camera = $Camera2D
onready var message = $HUD/Message

var fighters := []
var shake_amount := 0.0
var clock := 0.0
var last_step := -1
var started := false
var over := false
var go_hide_time := 0.0
var net_sync = null            # NetSync.gd (solo en partidas en red)
var _over_played := false


func _ready() -> void:
	add_to_group("arena")
	var stage = load(Game.current_stage()["scene"]).instance()   # nodo "Stage": fondo, suelo y plataformas
	add_child(stage)
	move_child(stage, 1)                                         # detrás de los luchadores (después de la cámara)
	_update_hints()
	Game.play_music(Game.current_stage().get("music", Game.BATTLE_MUSIC))   # cada escenario tiene su música
	for i in range(2):
		var data = Game.CHARACTERS[Game.selected[i]]
		var f = data.scene.instance()
		fighters_root.add_child(f)
		f.apply_data(data)                                   # estadísticas del .tres
		f.setup(i + 1, Config.SPAWN_POINTS[i], 1 if i == 0 else -1)
		f.add_to_group("fighters")
		f.input_enabled = false                              # sin control hasta el "¡YA!"
		fighters.append(f)
	if Game.practice:
		fighters[1].stocks = Config.PRACTICE_DUMMY_STOCKS    # muñeco de práctica: vidas "infinitas"
	$HUD/P1Panel.bind(fighters[0], Game.CHARACTERS[Game.selected[0]].color)
	$HUD/P2Panel.bind(fighters[1], Game.CHARACTERS[Game.selected[1]].color)
	message.text = ""
	if Net.is_active():
		_setup_net()
	elif Net.touch_enabled():
		_add_touch(1)                                          # móvil sin red: controles táctiles del P1


# Partida en red: el anfitrión simula, el cliente dibuja (ver scripts/net/NetSync.gd).
func _setup_net() -> void:
	net_sync = Node.new()
	net_sync.set_script(NETSYNC)
	net_sync.name = "NetSync"
	add_child(net_sync)
	move_child(net_sync, 0)                                    # el primero: corre antes que los luchadores
	net_sync.setup(self, fighters_root, fighters)
	Net.connect("peer_left", self, "_on_net_peer_left")
	if Net.touch_enabled():
		_add_touch(Net.local_player())
	if Net.is_host():
		Net.host_arena_started()                               # avisa al cliente para que cargue su arena
	else:
		Net.client_arena_loaded()


func _add_touch(player: int) -> void:
	var layer = CanvasLayer.new()
	layer.layer = 20
	add_child(layer)
	var tc = Control.new()
	tc.set_script(TOUCH)
	tc.player = player
	layer.add_child(tc)


func _on_net_peer_left() -> void:
	Game.goto_menu()                                           # el otro se fue: de vuelta al menú (Net.notice dice por qué)


# Textos de teclas de arriba: salen de Keybinds, así que siguen bien si se cambian.
func _update_hints() -> void:
	$HUD/Hints/HintP1.text = _hint(1)
	$HUD/Hints/HintP2.text = _hint(2)
	if Net.is_host():
		$HUD/Hints/HintP2.text = "P2: jugador en red"
	elif Net.is_client():
		$HUD/Hints/HintP1.text = "P1: anfitrión"
	if Net.touch_enabled():
		$HUD/Hints/HintP1.text = "" if Net.local_player() == 2 else "P1: controles táctiles"
		if Net.is_client():
			$HUD/Hints/HintP2.text = "P2: controles táctiles"
		$HUD/Hints/HintEsc.text = ""


func _hint(p: int) -> String:
	var n := "p%d_" % p
	return "P%d  %s %s %s %s  ·  %s golpe  ·  %s especial" % [p,
		Keybinds.key_name(n + "left"), Keybinds.key_name(n + "right"), Keybinds.key_name(n + "jump"),
		Keybinds.key_name(n + "down"), Keybinds.key_name(n + "attack"), Keybinds.key_name(n + "special")]


# Lo llaman los luchadores (por grupo) al recibir un golpe o salir del mapa.
func shake(amount: float) -> void:
	shake_amount = max(shake_amount, amount)


func _process(delta: float) -> void:
	shake_amount = move_toward(shake_amount, 0.0, Config.SHAKE_DECAY * delta)
	camera.offset = Vector2(rand_range(-1, 1), rand_range(-1, 1)) * shake_amount

	if Net.is_client():                                      # el cliente no decide nada: copia al anfitrión (NetSync)
		if over and not _over_played:
			_over_played = true
			Game.play_music(Game.VICTORY_MUSIC, false)
		return
	if Net.is_host() and not Net.client_ready:               # la cuenta atrás espera a que el cliente cargue
		message.text = "Esperando al otro jugador..."
		return

	if not started:
		_countdown(delta)
		return

	if go_hide_time > 0.0:
		go_hide_time -= delta
		if go_hide_time <= 0.0 and not over:
			message.text = ""

	if not over and not Game.practice:
		for i in range(2):
			var f = fighters[i]
			if f.stocks <= 0 and f.is_dead():
				_finish(1 - i)                               # gana el otro
				break


func _countdown(delta: float) -> void:
	clock += delta
	var step = int(clock)            # 0,1,2 -> "3","2","1";  3 -> "¡YA!"
	if step != last_step:
		last_step = step
		if step < Config.COUNTDOWN_SECONDS:
			message.text = str(Config.COUNTDOWN_SECONDS - step)
			$SfxCount.play()
		else:
			_start_match()


func _start_match() -> void:
	started = true
	message.text = "¡YA!"
	go_hide_time = Config.GO_MESSAGE_TIME
	$SfxGo.play()
	for i in range(2):
		fighters[i].input_enabled = not (Game.practice and i == 1)   # el muñeco nunca recibe input


func _finish(winner_index: int) -> void:
	over = true
	for f in fighters:
		f.input_enabled = false
	var data = Game.CHARACTERS[Game.selected[winner_index]]
	message.text = "¡GANA P%d!\n%s" % [winner_index + 1, data.display_name]
	$HUD/EndHint.visible = true
	$SfxWin.play()
	Game.play_music(Game.VICTORY_MUSIC, false)                # fanfarria (una vez)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):                 # Esc
		Game.goto_menu()
	elif over and event.is_action_pressed("ui_accept") and not Net.is_client():      # Enter: revancha (en red solo el anfitrión)
		get_tree().reload_current_scene()
