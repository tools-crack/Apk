extends Control
# ============================================================================
#  MainMenu.gd  —  menú principal (scenes/ui/MainMenu.tscn)
# ----------------------------------------------------------------------------
#  Botones: Jugar (2 jugadores), Práctica (vs muñeco), Controles (cambiar
#  teclas), Jugar en red · LAN (scenes/ui/Lan.tscn), Salir. Jugar y Práctica van a la
#  selección de personajes; lo único que cambia es Game.practice.
#  Los botones son AnimButton (scripts/ui/AnimButton.gd): se agrandan al pasar
#  el mouse / recibir foco y entran con una animación escalonada.
#  El texto de ayuda de abajo lee las teclas actuales de Keybinds.
# ============================================================================

onready var btn_play = $Margin/Col/ButtonsRow/Buttons/Play
onready var btn_practice = $Margin/Col/ButtonsRow/Buttons/Practice
onready var btn_controls = $Margin/Col/ButtonsRow/Buttons/Controls
onready var btn_lan = $Margin/Col/ButtonsRow/Buttons/Lan
onready var btn_quit = $Margin/Col/ButtonsRow/Buttons/Quit
onready var title = $Margin/Col/Title
onready var icon = $Margin/Col/Icon

var _t := 0.0


func _ready() -> void:
	Game.play_music(Game.MENU_MUSIC)
	btn_play.connect("pressed", self, "_on_play")
	btn_practice.connect("pressed", self, "_on_practice")
	btn_controls.connect("pressed", self, "_on_controls")
	btn_lan.connect("pressed", self, "_on_lan")
	btn_quit.connect("pressed", self, "_on_quit")
	$Margin/Col/Hint.text = "P1: %s\nP2: %s" % [_keys_text(1), _keys_text(2)]
	if Net.notice != "":
		$Margin/Col/Hint.text = Net.notice                       # p. ej. "Se perdió la conexión con el anfitrión."
		Net.notice = ""
	var i := 0
	for b in $Margin/Col/ButtonsRow/Buttons.get_children():
		b.pop_in(0.08 * i)                       # entrada escalonada
		i += 1
	btn_play.focus_silently()


# El título "respira" y el icono se mece un poco.
func _process(delta: float) -> void:
	_t += delta
	title.rect_pivot_offset = title.rect_size * 0.5      # (los contenedores acomodan el tamaño después de _ready)
	icon.rect_pivot_offset = icon.rect_size * 0.5
	var k := 1.0 + 0.018 * sin(_t * 2.0)
	title.rect_scale = Vector2(k, k)
	icon.rect_rotation = 3.0 * sin(_t * 1.4)


func _keys_text(p: int) -> String:
	var n := "p%d_" % p
	return "%s/%s mover · %s saltar · %s bajar · %s golpe · %s especial" % [
		Keybinds.key_name(n + "left"), Keybinds.key_name(n + "right"), Keybinds.key_name(n + "jump"),
		Keybinds.key_name(n + "down"), Keybinds.key_name(n + "attack"), Keybinds.key_name(n + "special")]


func _on_play() -> void:
	Game.practice = false
	Game.goto("res://scenes/ui/CharSelect.tscn")


func _on_practice() -> void:
	Game.practice = true
	Game.goto("res://scenes/ui/CharSelect.tscn")


func _on_lan() -> void:
	Game.goto("res://scenes/ui/Lan.tscn")


func _on_controls() -> void:
	Game.goto("res://scenes/ui/Controls.tscn")


func _on_quit() -> void:
	get_tree().quit()
