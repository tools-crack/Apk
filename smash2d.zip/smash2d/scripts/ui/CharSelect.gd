extends Control
# ============================================================================
#  CharSelect.gd  —  pantalla de selección de personajes (scenes/ui/CharSelect.tscn)
# ----------------------------------------------------------------------------
#  Contiene dos PickPanel (uno por jugador). Cada jugador elige con SUS teclas
#  (ver PickPanel.gd). Cuando los dos están "listos" guarda la elección en
#  Game.selected y pasa a la selección de escenario (StageSelect). En modo práctica el panel de P2 es un
#  muñeco que usa automáticamente el personaje siguiente al de P1.
#  Los personajes que aparecen salen de Game.ORDER (carpeta characters/).
# ============================================================================

onready var pick1 = $Margin/Col/Row/Pick1
onready var pick2 = $Margin/Col/Row/Pick2
onready var footer = $Margin/Col/Footer

var starting := false
var start_timer := 0.0


func _ready() -> void:
	Game.play_music(Game.SELECT_MUSIC)
	pick1.setup(1, Game.selected[0])
	pick2.setup(2, Game.selected[1])
	if Game.practice:
		pick2.lock_as_dummy()
		footer.text = "Práctica: el muñeco (P2) usa el otro personaje.   Esc: volver"
	else:
		footer.text = "Esc: volver al menú"


func _process(delta: float) -> void:
	if Game.practice:
		pick2.set_index((pick1.index + 1) % Game.ORDER.size())
	if starting:
		start_timer -= delta
		if start_timer <= 0.0:
			Game.goto("res://scenes/ui/StageSelect.tscn")
		return
	if pick1.is_ready and pick2.is_ready:
		starting = true
		start_timer = 0.7
		Game.selected = [pick1.character_id(), pick2.character_id()]
		$SfxGo.play()
		$Banner.visible = true


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and not starting:
		Game.goto_menu()
