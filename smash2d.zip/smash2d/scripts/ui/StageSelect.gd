extends Control
# ============================================================================
#  StageSelect.gd  —  selección de escenario (scenes/ui/StageSelect.tscn)
# ----------------------------------------------------------------------------
#  Se llega desde CharSelect. Muestra una tarjeta por cada escenario de
#  Game.STAGES más una tarjeta "Aleatorio". Se elige con las flechas / las
#  teclas de izquierda-derecha de cualquiera de los dos jugadores, o con el
#  mouse; se confirma con Enter, Espacio, clic o la tecla de golpe de P1 o P2.
#  Al confirmar guarda Game.stage_index y entra a la arena. Esc vuelve.
#  Las tarjetas se crean por código a partir de Game.STAGES, así que un
#  escenario nuevo aparece solo al añadirlo a esa lista.
# ============================================================================

const ANIM_BUTTON := preload("res://scripts/ui/AnimButton.gd")
const FONT_SMALL := preload("res://resources/font_small.tres")
const FONT_BIG := preload("res://resources/font_big.tres")

onready var cards_box = $Margin/Col/Cards
onready var bg = $Bg

var cards := []
var index := 0
var choosing := false


func _ready() -> void:
	Game.play_music(Game.SELECT_MUSIC)
	for i in range(Game.STAGES.size() + 1):                   # +1 = Aleatorio
		var card := _make_card(i)
		cards_box.add_child(card)
		cards.append(card)
		card.pop_in(0.07 * i)
	index = Game.stage_index if not Game.stage_random else cards.size() - 1
	cards[index].focus_silently()
	_show_info(index)


func _is_random(i: int) -> bool:
	return i >= Game.STAGES.size()


func _make_card(i: int) -> Button:
	var b := Button.new()
	b.set_script(ANIM_BUTTON)
	b.rect_min_size = Vector2(200, 250)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.hover_scale = 1.05
	b.connect("pressed", self, "_choose", [i])
	b.connect("focus_entered", self, "_on_card_focus", [i])

	var pic := TextureRect.new()
	pic.anchor_right = 1.0
	pic.anchor_bottom = 1.0
	pic.margin_left = 14
	pic.margin_top = 14
	pic.margin_right = -14
	pic.margin_bottom = -62
	pic.expand = true
	pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	pic.rect_clip_content = true
	pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(pic)

	var label := Label.new()
	label.anchor_top = 1.0
	label.anchor_right = 1.0
	label.anchor_bottom = 1.0
	label.margin_left = 10
	label.margin_right = -10
	label.margin_top = -50
	label.margin_bottom = -10
	label.align = Label.ALIGN_CENTER
	label.valign = Label.VALIGN_CENTER
	label.clip_text = true
	label.add_font_override("font", FONT_SMALL)
	label.add_color_override("font_color_shadow", Color(0.05, 0.06, 0.2, 0.9))
	label.add_constant_override("shadow_offset_x", 2)
	label.add_constant_override("shadow_offset_y", 2)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(label)

	if _is_random(i):
		label.text = "Aleatorio"
		var q := Label.new()
		q.text = "?"
		q.align = Label.ALIGN_CENTER
		q.valign = Label.VALIGN_CENTER
		q.set_anchors_and_margins_preset(Control.PRESET_WIDE)
		q.add_font_override("font", FONT_BIG)
		q.add_color_override("font_color", Color(1, 0.9, 0.4))
		q.mouse_filter = Control.MOUSE_FILTER_IGNORE
		pic.add_child(q)
		pic.texture = null
	else:
		label.text = Game.STAGES[i]["name"]
		pic.texture = load(Game.STAGES[i]["preview"])
	return b


func _on_card_focus(i: int) -> void:
	index = i
	_show_info(i)


func _show_info(i: int) -> void:
	if _is_random(i):
		$Margin/Col/StageName.text = "Escenario aleatorio"
		$Margin/Col/StageDesc.text = "Se sortea uno de los escenarios al empezar."
		return
	var st: Dictionary = Game.STAGES[i]
	$Margin/Col/StageName.text = st["name"]
	$Margin/Col/StageDesc.text = st["desc"]
	var tex = load(st["preview"])
	if bg.texture != tex:                                    # el fondo cambia al del escenario enfocado
		bg.texture = tex
		bg.modulate = Color(0.6, 0.6, 0.6, 1)
		var tw := Tween.new()
		add_child(tw)
		tw.interpolate_property(bg, "modulate", bg.modulate, Color.white, 0.35, Tween.TRANS_SINE, Tween.EASE_OUT)
		tw.start()
		tw.connect("tween_all_completed", tw, "queue_free")


func _move(d: int) -> void:
	index = (index + d + cards.size()) % cards.size()
	cards[index].grab_focus()


func _choose(i: int) -> void:
	if choosing:
		return
	choosing = true
	randomize()
	Game.stage_random = _is_random(i)
	Game.stage_index = (randi() % Game.STAGES.size()) if Game.stage_random else i
	yield(get_tree().create_timer(0.3), "timeout")           # deja ver la animación del botón
	Game.goto("res://scenes/Arena.tscn")


func _any(suffix: String, event: InputEvent) -> bool:
	return event.is_action_pressed("p1_" + suffix) or event.is_action_pressed("p2_" + suffix)


func _unhandled_input(event: InputEvent) -> void:
	if choosing or not (event is InputEventKey) or not event.pressed or event.echo:
		return
	if event.is_action_pressed("ui_cancel"):
		Game.goto("res://scenes/ui/CharSelect.tscn")
	elif _any("left", event):
		_move(-1)
	elif _any("right", event):
		_move(1)
	elif _any("attack", event):
		_choose(index)
