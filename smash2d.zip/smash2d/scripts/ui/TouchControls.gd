extends Control
# ============================================================================
#  TouchControls.gd  —  controles táctiles para móvil (Android)
# ----------------------------------------------------------------------------
#  Lo crea Arena.gd cuando Net.touch_enabled() (un móvil, o el juego abierto con --touch).
#  Dibuja y maneja los botones, y los convierte en acciones del Input Map (p1_left,
#  p2_jump...) con Input.action_press / action_release. Así el luchador y la red
#  funcionan igual que con teclado: no saben que hay una pantalla táctil.
#
#  Diseño (pantalla de 1280x720):
#    - Izquierda: STICK FLOTANTE. Toca en cualquier parte de la mitad izquierda y ahí
#      aparece el stick; si arrastras más allá de su borde, el stick SIGUE al dedo
#      (no hace falta volver al centro). Izquierda/derecha = mover, abajo = bajar de
#      plataforma, arriba = saltar.
#    - Derecha: GOLPE (grande), ESPECIAL y SALTO.
#    - Arriba a la derecha: botón de salir (hay que tocarlo dos veces).
#  Multitoque real: se puede mover, saltar y golpear a la vez con tres dedos.
#  Cada dedo se sigue por su índice, y un botón se suelta solo cuando se levanta ESE dedo.
#
#  Para probar en PC: abre el juego con  --touch  y usa el mouse (cuenta como un dedo).
# ============================================================================

var player := 1                                  # 1 = P1 (acciones p1_*), 2 = P2 (acciones p2_*)

const STICK_R := 100.0                           # radio del stick (px)
const STICK_HOME := Vector2(190, 560)            # dónde se dibuja el stick cuando nadie lo toca
const STICK_ZONE := Rect2(0, 110, 600, 610)      # zona donde se puede empezar a mover el stick
const T_SIDE_ON := 0.30                          # cuánto hay que inclinar el stick para moverse (0..1)
const T_SIDE_OFF := 0.18                         # ...y cuánto para soltar (histéresis: evita parpadeo)
const T_DOWN_ON := 0.55
const T_DOWN_OFF := 0.40
const T_UP_ON := 0.62
const T_UP_OFF := 0.45
const BUTTONS := [
	{"id": "attack", "pos": Vector2(1130, 585), "r": 84.0, "action": "attack", "text": "GOLPE", "col": Color(1.0, 0.45, 0.35)},
	{"id": "special", "pos": Vector2(962, 640), "r": 64.0, "action": "special", "text": "ESPECIAL", "col": Color(0.4, 0.7, 1.0)},
	{"id": "jump", "pos": Vector2(1152, 422), "r": 72.0, "action": "jump", "text": "SALTO", "col": Color(0.5, 0.95, 0.5)},
]
const MENU_POS := Vector2(1236, 44)
const MENU_R := 28.0
const FONT := preload("res://resources/font_small.tres")

var _prefix := "p1_"
var _fingers := {}                               # índice de dedo -> {"kind": "stick"|"btn"|"menu", "b": botón}
var _count := {}                                 # acción -> cuántas cosas la mantienen pulsada
var _pressed := {}                               # id de botón -> true (solo para dibujarlo iluminado)
var _stick_finger := -1
var _stick_center := STICK_HOME
var _stick_off := Vector2.ZERO
var _sflags := {"left": false, "right": false, "down": false, "jump": false}
var _menu_t := 0.0
var _mouse_ok := false                           # true = aceptar el mouse como un dedo (pruebas en PC)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_margins_preset(Control.PRESET_WIDE)
	_prefix = "p%d_" % player
	_mouse_ok = Net.force_touch and not OS.has_touchscreen_ui_hint()


func _exit_tree() -> void:
	_release_all()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_FOCUS_OUT:                # si la app pierde el foco no deben quedar botones "pegados"
		_release_all()


func _process(delta: float) -> void:
	if _menu_t > 0.0:
		_menu_t = max(0.0, _menu_t - delta)
		update()


# ============================================================================
#  ENTRADA
# ============================================================================
func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_down(event.index, _to_local(event.position))
		else:
			_up(event.index)
	elif event is InputEventScreenDrag:
		_move(event.index, _to_local(event.position))
	elif _mouse_ok:
		if event is InputEventMouseButton and event.button_index == BUTTON_LEFT:
			if event.pressed:
				_down(99, _to_local(event.position))
			else:
				_up(99)
		elif event is InputEventMouseMotion and _fingers.has(99):
			_move(99, _to_local(event.position))


func _to_local(p: Vector2) -> Vector2:
	return get_canvas_transform().affine_inverse().xform(p)


func _down(i: int, p: Vector2) -> void:
	if p.distance_to(MENU_POS) <= MENU_R * 1.6:
		_fingers[i] = {"kind": "menu"}
		if _menu_t > 0.0:
			_release_all()
			Game.goto_menu()                             # segundo toque: salir (en red también cierra la conexión)
		else:
			_menu_t = 2.0                                # primer toque: pide confirmar
		update()
		return
	var best = null
	var bestk := 99.0
	for b in BUTTONS:
		var k = p.distance_to(b["pos"]) / b["r"]         # distancia en "radios": el botón más cercano gana
		if k <= 1.3 and k < bestk:
			best = b
			bestk = k
	if best != null:
		_fingers[i] = {"kind": "btn", "b": best}
		_pressed[best["id"]] = true
		_hold(best["action"], 1)
		_haptic()
		update()
		return
	if _stick_finger < 0 and STICK_ZONE.has_point(p):
		_stick_finger = i
		_stick_center = _clamp_center(p)
		_stick_off = Vector2.ZERO
		_fingers[i] = {"kind": "stick"}
		update()


func _move(i: int, p: Vector2) -> void:
	if not _fingers.has(i) or _fingers[i]["kind"] != "stick":
		return
	var off = p - _stick_center
	if off.length() > STICK_R:                           # el stick sigue al dedo en vez de quedarse atrás
		_stick_center = _clamp_center(_stick_center + off.normalized() * (off.length() - STICK_R))
		off = p - _stick_center
	_stick_off = off.limit_length(STICK_R)
	_apply_stick()
	update()


func _up(i: int) -> void:
	if not _fingers.has(i):
		return
	var f = _fingers[i]
	_fingers.erase(i)
	if f["kind"] == "btn":
		_hold(f["b"]["action"], -1)
		_pressed.erase(f["b"]["id"])
	elif f["kind"] == "stick":
		_stick_finger = -1
		_stick_off = Vector2.ZERO
		_stick_center = STICK_HOME
		_apply_stick()
	update()


func _clamp_center(c: Vector2) -> Vector2:
	var z = STICK_ZONE
	return Vector2(clamp(c.x, z.position.x + STICK_R, z.end.x - STICK_R), clamp(c.y, z.position.y + STICK_R, z.end.y - STICK_R))


# Convierte la inclinación del stick en acciones, con histéresis para que no parpadee en el borde.
func _apply_stick() -> void:
	var dx = _stick_off.x / STICK_R
	var dy = _stick_off.y / STICK_R
	_set_dir("left", dx < -(T_SIDE_OFF if _sflags["left"] else T_SIDE_ON))
	_set_dir("right", dx > (T_SIDE_OFF if _sflags["right"] else T_SIDE_ON))
	_set_dir("down", dy > (T_DOWN_OFF if _sflags["down"] else T_DOWN_ON))
	_set_dir("jump", dy < -(T_UP_OFF if _sflags["jump"] else T_UP_ON))


func _set_dir(action: String, on: bool) -> void:
	if _sflags[action] != on:
		_sflags[action] = on
		_hold(action, 1 if on else -1)


# Varias cosas pueden mantener la misma acción (el stick arriba y el botón SALTO): se suelta al quedar a 0.
func _hold(action: String, delta: int) -> void:
	var c: int = _count.get(action, 0)
	var n: int = int(max(0, c + delta))
	_count[action] = n
	if c == 0 and n > 0:
		Input.action_press(_prefix + action)
	elif c > 0 and n == 0:
		Input.action_release(_prefix + action)


func _release_all() -> void:
	for a in _count.keys():
		if _count[a] > 0:
			Input.action_release(_prefix + a)
	_count.clear()
	_fingers.clear()
	_pressed.clear()
	_stick_finger = -1
	_stick_off = Vector2.ZERO
	_stick_center = STICK_HOME
	for k in _sflags.keys():
		_sflags[k] = false


func _haptic() -> void:
	if OS.get_name() == "Android":
		Input.vibrate_handheld(12)                       # vibración corta (necesita el permiso VIBRATE al exportar)


# ============================================================================
#  DIBUJO
# ============================================================================
func _draw() -> void:
	var active = _stick_finger >= 0
	var c = _stick_center
	draw_circle(c, STICK_R, Color(1, 1, 1, 0.16 if active else 0.09))
	draw_arc(c, STICK_R, 0.0, TAU, 56, Color(1, 1, 1, 0.65 if active else 0.35), 4.0, true)
	_arrow(c + Vector2(-STICK_R * 0.68, 0), Vector2(-1, 0), _sflags["left"])
	_arrow(c + Vector2(STICK_R * 0.68, 0), Vector2(1, 0), _sflags["right"])
	_arrow(c + Vector2(0, -STICK_R * 0.68), Vector2(0, -1), _sflags["jump"])
	_arrow(c + Vector2(0, STICK_R * 0.68), Vector2(0, 1), _sflags["down"])
	draw_circle(c + _stick_off, 40.0, Color(1, 1, 1, 0.55 if active else 0.28))

	for b in BUTTONS:
		var down = _pressed.has(b["id"])
		var col: Color = b["col"]
		var r: float = b["r"] * (0.94 if down else 1.0)
		draw_circle(b["pos"], r, Color(col.r, col.g, col.b, 0.62 if down else 0.30))
		draw_arc(b["pos"], r, 0.0, TAU, 48, Color(1, 1, 1, 0.9 if down else 0.55), 4.0, true)
		var s: Vector2 = FONT.get_string_size(b["text"])
		draw_string(FONT, b["pos"] + Vector2(-s.x * 0.5, FONT.get_ascent() * 0.5 - 2.0), b["text"], Color(1, 1, 1, 0.95 if down else 0.8))

	draw_circle(MENU_POS, MENU_R, Color(0.1, 0.1, 0.15, 0.5))
	draw_arc(MENU_POS, MENU_R, 0.0, TAU, 32, Color(1, 1, 1, 0.5), 3.0, true)
	draw_rect(Rect2(MENU_POS + Vector2(-9, -10), Vector2(6, 20)), Color(1, 1, 1, 0.8))
	draw_rect(Rect2(MENU_POS + Vector2(3, -10), Vector2(6, 20)), Color(1, 1, 1, 0.8))
	if _menu_t > 0.0:
		var t = "Toca otra vez para salir"
		var s2: Vector2 = FONT.get_string_size(t)
		draw_string(FONT, Vector2(1190.0 - s2.x, 100.0), t, Color(1, 1, 1, min(1.0, _menu_t)))


func _arrow(p: Vector2, dir: Vector2, on: bool) -> void:
	var side = Vector2(-dir.y, dir.x)
	var pts = PoolVector2Array([p + dir * 11.0, p - dir * 8.0 + side * 10.0, p - dir * 8.0 - side * 10.0])
	draw_colored_polygon(pts, Color(1, 1, 1, 0.95 if on else 0.4))
