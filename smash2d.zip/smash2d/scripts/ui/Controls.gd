extends Control
# ============================================================================
#  Controls.gd  —  menú para cambiar las teclas (scenes/ui/Controls.tscn)
# ----------------------------------------------------------------------------
#  Muestra las 6 acciones de cada jugador. Se pulsa una fila, se pulsa la tecla
#  nueva y listo (Esc cancela). Si la tecla ya la usaba otra acción, las dos se
#  INTERCAMBIAN. Todo se guarda solo (user://controles.cfg) mediante el autoload
#  Keybinds, y los menús / HUD muestran las teclas actuales.
#  Las filas se crean por código (build_column) a partir de Keybinds.ACTIONS.
# ============================================================================

const ANIM_BUTTON := preload("res://scripts/ui/AnimButton.gd")
const FONT_MED := preload("res://resources/font_med.tres")
const FONT_SMALL := preload("res://resources/font_small.tres")
const PLAYER_COLORS := {1: Color(0.45, 0.7, 1.0), 2: Color(1.0, 0.55, 0.45)}

var key_buttons := {}          # "p1_left" -> Button
var capturing := ""            # acción que espera una tecla ("" = ninguna)
var _blink := 0.0


func _ready() -> void:
	for p in [1, 2]:
		$Margin/Col/Columns.add_child(_build_column(p))
	$Margin/Col/Buttons/ResetP1.connect("pressed", self, "_on_reset", [1])
	$Margin/Col/Buttons/ResetP2.connect("pressed", self, "_on_reset", [2])
	$Margin/Col/Buttons/ResetAll.connect("pressed", self, "_on_reset", [0])
	$Margin/Col/Buttons/Back.connect("pressed", self, "_on_back")
	Keybinds.connect("changed", self, "_refresh")
	_refresh()
	key_buttons["p1_left"].focus_silently()


func _build_column(p: int) -> Control:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.09, 0.1, 0.16, 0.92)
	sb.set_corner_radius_all(20)
	sb.set_border_width_all(3)
	sb.border_color = PLAYER_COLORS[p]
	sb.shadow_size = 8
	sb.shadow_color = Color(0, 0, 0, 0.35)
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 12
	sb.content_margin_bottom = 14
	sb.anti_aliasing = true
	panel.add_stylebox_override("panel", sb)

	var col := VBoxContainer.new()
	col.add_constant_override("separation", 6)
	panel.add_child(col)

	var header := Label.new()
	header.text = "JUGADOR %d" % p
	header.align = Label.ALIGN_CENTER
	header.add_font_override("font", FONT_MED)
	header.add_color_override("font_color", PLAYER_COLORS[p])
	col.add_child(header)

	for a in Keybinds.ACTIONS:
		var row := HBoxContainer.new()
		row.add_constant_override("separation", 12)
		var name_label := Label.new()
		name_label.text = Keybinds.LABELS[a]
		name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		name_label.add_font_override("font", FONT_SMALL)
		name_label.clip_text = true
		row.add_child(name_label)
		var b := Button.new()
		b.set_script(ANIM_BUTTON)
		b.hover_scale = 1.04
		b.rect_min_size = Vector2(220, 44)
		b.clip_text = true
		b.add_font_override("font", FONT_SMALL)
		b.connect("pressed", self, "_on_key_pressed", [Keybinds.action_name(p, a)])
		row.add_child(b)
		key_buttons[Keybinds.action_name(p, a)] = b
		col.add_child(row)
	return panel


func _refresh() -> void:
	for act in key_buttons:
		key_buttons[act].text = "Pulsa una tecla…" if act == capturing else Keybinds.key_name(act)


func _on_key_pressed(action: String) -> void:
	capturing = action
	$Margin/Col/Status.text = "Pulsa la nueva tecla para «%s» de P%s  (Esc cancela)" % [
		Keybinds.LABELS[action.substr(3)], action.substr(1, 1)]
	_refresh()


func _input(event: InputEvent) -> void:
	if capturing == "":
		return
	if event is InputEventKey and event.pressed and not event.echo:
		get_tree().set_input_as_handled()
		var action := capturing
		capturing = ""
		if event.scancode == KEY_ESCAPE:
			$Margin/Col/Status.text = "Cancelado"
		elif Keybinds.is_reserved(event.scancode):
			$Margin/Col/Status.text = "Esa tecla está reservada"
		else:
			var other: String = Keybinds.set_key(action, event.scancode)
			if other == "":
				$Margin/Col/Status.text = "Listo: %s = %s" % [Keybinds.LABELS[action.substr(3)], Keybinds.key_name(action)]
			else:
				$Margin/Col/Status.text = "Esa tecla la usaba P%s «%s»: se intercambiaron" % [
					other.substr(1, 1), Keybinds.LABELS[other.substr(3)]]
		_refresh()
		key_buttons[action].modulate = Color.white
		key_buttons[action].grab_focus()
	elif event is InputEventMouseButton and event.pressed:
		pass                                    # un clic fuera no cancela: solo Esc


func _process(delta: float) -> void:
	if capturing == "":
		return
	_blink += delta
	key_buttons[capturing].modulate = Color(1, 1, 1, 0.65 + 0.35 * sin(_blink * 9.0))


func _on_reset(player: int) -> void:
	capturing = ""
	for b in key_buttons.values():
		b.modulate = Color.white
	Keybinds.reset(player)
	$Margin/Col/Status.text = "Teclas restauradas" + ("" if player == 0 else " (P%d)" % player)


func _on_back() -> void:
	Game.goto_menu()


func _unhandled_input(event: InputEvent) -> void:
	if capturing == "" and event.is_action_pressed("ui_cancel"):
		Game.goto_menu()
