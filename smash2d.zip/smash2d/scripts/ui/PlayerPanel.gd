extends Panel
# ============================================================================
#  PlayerPanel.gd  —  HUD de un jugador (scenes/ui/PlayerPanel.tscn)
# ----------------------------------------------------------------------------
#  Muestra: nombre, % de daño (se pone rojo al subir), vidas (●) y la barra de
#  recarga del especial. La tecla del especial se lee del Input Map, así que si
#  la cambias en Proyecto > Ajustes > Mapa de entrada, el HUD se actualiza solo.
#  Arena.gd lo conecta a un luchador con bind().
# ============================================================================

var fighter = null


func bind(f, color: Color) -> void:
	fighter = f
	$Title.text = "P%d  %s" % [f.player_id, f.display_name]
	$Title.add_color_override("font_color", color)
	$SpecialLabel.text = "ESPECIAL  [%s]" % _key_name("p%d_special" % f.player_id)


func _process(_delta: float) -> void:
	if fighter == null or not is_instance_valid(fighter):
		return
	var p = fighter.percent
	$Percent.text = "%d%%" % int(round(p))
	var k = clamp(p / 150.0, 0.0, 1.0)
	$Percent.add_color_override("font_color", Color(1.0, 1.0 - 0.75 * k, 1.0 - 0.8 * k))
	$Stocks.text = "∞" if fighter.stocks > 9 else "●●●●●".left(max(fighter.stocks, 0))
	var charge = 1.0
	if fighter.special_cooldown > 0.0:
		charge = 1.0 - fighter.special_timer / fighter.special_cooldown
	$SpecialBar.value = charge * 100.0


# Nombre de la tecla asignada a una acción del Input Map (p. ej. "G").
func _key_name(action: String) -> String:
	for ev in InputMap.get_action_list(action):
		if ev is InputEventKey:
			return OS.get_scancode_string(ev.scancode)
	return "?"
