extends Control
# ============================================================================
#  LanMenu.gd  —  menú de juego en red (scenes/ui/Lan.tscn)
# ----------------------------------------------------------------------------
#  Pantallas (todo se construye por código en _col):
#    menu       Crear partida / Unirse / Volver
#    host       muestra tu IP y espera al otro jugador
#    host_ready el otro ya está conectado -> "Elegir personajes y jugar"
#    join       lista las partidas que se encuentran solas + campo para escribir la IP
#    waiting    (cliente) conectado, esperando a que el anfitrión elija
#  El anfitrión elige los personajes y el escenario de los dos (como en el juego
#  local); al entrar a la arena el cliente salta a ella solo (Net.net_begin).
#  La última IP escrita se guarda en user://lan.cfg.
# ============================================================================

const AnimButton := preload("res://scripts/ui/AnimButton.gd")
const FONT_BIG := preload("res://resources/font_big.tres")
const FONT_MED := preload("res://resources/font_med.tres")
const FONT_SMALL := preload("res://resources/font_small.tres")
const CFG := "user://lan.cfg"

onready var _col = $Margin/Col

var _state := ""
var _status: Label = null
var _hosts_box: VBoxContainer = null
var _ip_edit: LineEdit = null
var _hosts_sig := ""
var _refresh_t := 0.0
var _n_buttons := 0


func _ready() -> void:
	Game.play_music(Game.MENU_MUSIC)
	Net.connect("peer_joined", self, "_on_peer_joined")
	Net.connect("connected", self, "_on_connected")
	Net.connect("connect_failed", self, "_on_connect_failed")
	Net.connect("peer_left", self, "_on_peer_left")
	if Net.is_active():
		Net.stop()
	_show_menu()


func _exit_tree() -> void:
	Net.stop_discovery()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if _state == "menu":
			Game.goto_menu()
		else:
			_on_cancel()


# ---------------------------------------------------------------- construcción
func _reset(title: String, sub := "") -> void:
	for c in _col.get_children():
		_col.remove_child(c)
		c.queue_free()
	_status = null
	_hosts_box = null
	_ip_edit = null
	_n_buttons = 0
	_label(title, FONT_BIG, Color(1, 1, 1))
	if sub != "":
		_label(sub, FONT_SMALL, Color(1, 1, 1))
	if Net.notice != "":
		_label(Net.notice, FONT_SMALL, Color(1.0, 0.85, 0.4))
		Net.notice = ""


func _label(text: String, font, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.align = Label.ALIGN_CENTER
	l.autowrap = true
	l.add_font_override("font", font)
	l.add_color_override("font_color", color)
	l.add_color_override("font_color_shadow", Color(0.1, 0.12, 0.2, 0.9))
	l.add_constant_override("shadow_offset_x", 2)
	l.add_constant_override("shadow_offset_y", 2)
	_col.add_child(l)
	return l


func _button(text: String, method: String, args := []) -> Button:
	var b := Button.new()
	b.set_script(AnimButton)
	b.text = text
	b.rect_min_size = Vector2(520, 60)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b.add_font_override("font", FONT_MED)
	b.connect("pressed", self, method, args)
	_col.add_child(b)
	b.pop_in(0.06 * _n_buttons)
	if _n_buttons == 0:
		b.focus_silently()
	_n_buttons += 1
	return b


# ---------------------------------------------------------------- pantallas
func _show_menu() -> void:
	_state = "menu"
	_reset("JUEGO EN RED", "PC y Android en la misma red WiFi")
	_button("Crear partida", "_on_host")
	_button("Unirse a partida", "_on_join")
	_button("Volver", "_on_back")


func _on_host() -> void:
	var err = Net.start_host()
	_state = "host"
	_reset("CREAR PARTIDA", "Dile al otro jugador que elija «Unirse a partida»")
	if err != OK:
		_status = _label("No se pudo abrir el puerto %d (error %d). ¿Hay otra copia del juego abierta?" % [Net.PORT, err], FONT_SMALL, Color(1.0, 0.6, 0.5))
		_button("Volver", "_on_cancel")
		return
	var ips = Net.local_ips()
	if ips.empty():
		_label("No encuentro tu IP: conéctate a una red WiFi o cable.", FONT_MED, Color(1.0, 0.85, 0.4))
	else:
		_label("Tu IP en esta red:", FONT_SMALL, Color(1, 1, 1))
		for ip in ips:
			_label(ip, FONT_BIG, Color(1.0, 0.95, 0.5))
	_label("Puerto %d (UDP). Si no te encuentra, permite el juego en el cortafuegos." % Net.PORT, FONT_SMALL, Color(1, 1, 1))
	_status = _label("Esperando al otro jugador...", FONT_MED, Color(1, 1, 1))
	_button("Cancelar", "_on_cancel")


func _on_peer_joined() -> void:
	if _state != "host":
		return
	_state = "host_ready"
	_reset("¡JUGADOR CONECTADO!", "Tú eres P1 y el otro es P2")
	_button("Elegir personajes y jugar", "_on_start")
	_button("Cancelar", "_on_cancel")


func _on_start() -> void:
	Game.practice = false
	Game.goto("res://scenes/ui/CharSelect.tscn")


func _on_join() -> void:
	_show_join("")


func _show_join(msg: String) -> void:
	_state = "join"
	_reset("UNIRSE A PARTIDA", "Busca partidas en tu red WiFi")
	_hosts_box = VBoxContainer.new()
	_hosts_box.alignment = BoxContainer.ALIGN_CENTER
	_hosts_box.add_constant_override("separation", 8)
	_col.add_child(_hosts_box)
	_hosts_sig = "?"
	_refresh_hosts()
	_label("o escribe la IP del anfitrión:", FONT_SMALL, Color(1, 1, 1))
	_ip_edit = LineEdit.new()
	_ip_edit.placeholder_text = "192.168.1.10"
	_ip_edit.text = _load_ip()
	_ip_edit.rect_min_size = Vector2(520, 56)
	_ip_edit.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_ip_edit.align = LineEdit.ALIGN_CENTER
	_ip_edit.add_font_override("font", FONT_MED)
	_ip_edit.connect("text_entered", self, "_on_ip_entered")
	_col.add_child(_ip_edit)
	_button("Conectar", "_on_connect_ip")
	_button("Volver", "_on_cancel")
	_status = _label(msg, FONT_SMALL, Color(1.0, 0.85, 0.4))
	Net.start_discovery()


func _process(delta: float) -> void:
	if _state != "join" or _hosts_box == null:
		return
	_refresh_t -= delta
	if _refresh_t <= 0.0:
		_refresh_t = 0.5
		_refresh_hosts()


# Un botón por cada partida encontrada (solo se reconstruye si cambia la lista).
func _refresh_hosts() -> void:
	var ips = Net.found_hosts.keys()
	ips.sort()
	var sig = str(ips)
	if sig == _hosts_sig:
		return
	_hosts_sig = sig
	for c in _hosts_box.get_children():
		_hosts_box.remove_child(c)
		c.queue_free()
	if ips.empty():
		var l := Label.new()
		l.text = "Buscando partidas..."
		l.align = Label.ALIGN_CENTER
		l.add_font_override("font", FONT_SMALL)
		_hosts_box.add_child(l)
		return
	for ip in ips:
		var h = Net.found_hosts[ip]
		var b := Button.new()
		b.set_script(AnimButton)
		b.text = "%s  —  %s" % [h["name"], ip]
		b.rect_min_size = Vector2(520, 60)
		b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		b.add_font_override("font", FONT_MED)
		b.connect("pressed", self, "_connect_to", [ip, int(h["port"])])
		_hosts_box.add_child(b)


func _on_ip_entered(_t: String) -> void:
	_on_connect_ip()


func _on_connect_ip() -> void:
	var ip = _ip_edit.text.strip_edges()
	if ip == "":
		_status.text = "Escribe la IP del anfitrión (la ves en su pantalla)."
		return
	_save_ip(ip)
	_connect_to(ip, Net.PORT)


func _connect_to(ip: String, port: int) -> void:
	Net.stop_discovery()
	var err = Net.join(ip, port)
	if err != OK:
		_show_join("No se pudo conectar a %s (error %d)." % [ip, err])
		return
	_state = "connecting"
	_reset("CONECTANDO...", ip)
	_button("Cancelar", "_on_cancel")


func _on_connected() -> void:
	_state = "waiting"
	_reset("¡CONECTADO!", "Esperando a que el anfitrión elija los personajes...")
	_button("Salir", "_on_cancel")


func _on_connect_failed() -> void:
	_show_join("No se pudo conectar. Revisa la IP, que estén en la misma red y el cortafuegos del anfitrión.")


func _on_peer_left() -> void:
	_show_menu()


func _on_cancel() -> void:
	Net.stop()
	_show_menu()


func _on_back() -> void:
	Game.goto_menu()


# ---------------------------------------------------------------- última IP
func _load_ip() -> String:
	var cf := ConfigFile.new()
	if cf.load(CFG) == OK:
		return str(cf.get_value("lan", "ip", ""))
	return ""


func _save_ip(ip: String) -> void:
	var cf := ConfigFile.new()
	cf.set_value("lan", "ip", ip)
	cf.save(CFG)
