extends Button
# ============================================================================
#  AnimButton.gd  —  botón con animaciones (se pone como script de un Button)
# ----------------------------------------------------------------------------
#  El aspecto (textura 9-patch) viene del tema global resources/ui_theme.tres.
#  Este script añade:
#    - al pasar el mouse o recibir foco: crece un poco y se ilumina
#    - al pulsar: "aplasta" y rebota
#    - sonido de selección (foco) y de confirmación (pulsar)
#    - pop_in(delay): entrada con fundido + escala (la usa el menú)
#  El mouse sobre un botón le da el foco, así teclado y mouse se ven igual.
# ============================================================================

export var hover_scale := 1.06
export var press_scale := 0.94
export var silent := false              # true = sin sonidos

const SND_FOCUS := preload("res://assets/sounds/select.wav")
const SND_PRESS := preload("res://assets/sounds/confirm.wav")

var _tween: Tween
var _sfx_focus: AudioStreamPlayer
var _sfx_press: AudioStreamPlayer
var _highlight := false
var _mute_next_focus := false


func _ready() -> void:
	_tween = Tween.new()
	add_child(_tween)
	_sfx_focus = _make_player(SND_FOCUS, -9.0)
	_sfx_press = _make_player(SND_PRESS, -6.0)
	connect("resized", self, "_center_pivot")
	connect("mouse_entered", self, "_on_mouse_entered")
	connect("mouse_exited", self, "_on_mouse_exited")
	connect("focus_entered", self, "_on_focus_entered")
	connect("focus_exited", self, "_refresh_highlight")
	connect("button_down", self, "_squash")
	connect("pressed", self, "_on_pressed")
	_center_pivot()


func _make_player(stream, vol: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = stream
	p.volume_db = vol
	add_child(p)
	return p


func _center_pivot() -> void:
	rect_pivot_offset = rect_size * 0.5


# Da el foco sin que suene el "tic" (para el botón inicial de una pantalla).
func focus_silently() -> void:
	_mute_next_focus = true
	grab_focus()


# Entrada animada: empieza pequeño y transparente y crece rebotando.
func pop_in(delay := 0.0) -> void:
	modulate.a = 0.0
	rect_scale = Vector2(0.82, 0.82)
	_tween.remove_all()
	_tween.interpolate_property(self, "modulate:a", 0.0, 1.0, 0.22, Tween.TRANS_SINE, Tween.EASE_OUT, delay)
	_tween.interpolate_property(self, "rect_scale", Vector2(0.82, 0.82), Vector2.ONE, 0.38,
		Tween.TRANS_BACK, Tween.EASE_OUT, delay)
	_tween.start()


func _on_mouse_entered() -> void:
	if not disabled and not has_focus():
		grab_focus()
	_refresh_highlight()


func _on_mouse_exited() -> void:
	_refresh_highlight()


func _on_focus_entered() -> void:
	if _mute_next_focus:
		_mute_next_focus = false
	elif not silent:
		_sfx_focus.play()
	_refresh_highlight()


func _mouse_inside() -> bool:
	return get_global_rect().has_point(get_global_mouse_position())


func _refresh_highlight() -> void:
	var on := (has_focus() or _mouse_inside()) and not disabled
	if on == _highlight:
		return
	_highlight = on
	_animate_to(Vector2.ONE * (hover_scale if on else 1.0), 0.14)


func _squash() -> void:
	_animate_to(Vector2.ONE * press_scale, 0.07)


func _on_pressed() -> void:
	if not silent:
		_sfx_press.play()
	_animate_to(Vector2.ONE * (hover_scale if _highlight else 1.0), 0.22, Tween.TRANS_BACK)


func _animate_to(target: Vector2, time: float, trans := Tween.TRANS_QUAD) -> void:
	if not is_inside_tree() or is_queued_for_deletion() or not _tween.is_inside_tree():
		return
	_tween.stop_all()
	_tween.interpolate_property(self, "rect_scale", rect_scale, target, time, trans, Tween.EASE_OUT)
	_tween.start()
