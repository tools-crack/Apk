shader_type canvas_item;
// ============================================================================
//  fighter_fx.gdshader  —  efectos del luchador (se pone como material de su Sprite)
// ----------------------------------------------------------------------------
//  flash  : 0..1 . Mezcla el dibujo hacia flash_color (destello blanco al recibir un golpe).
//  dissolve: 0..1 . 0 = se ve todo, 1 = invisible. Se disuelve en pixeles con ruido y
//            deja un borde brillante. Lo usa la reaparición (de 1 a 0).
//  Fighter.gd controla los dos valores (ver _tick_timers y _respawn).
// ============================================================================

uniform float flash : hint_range(0.0, 1.0) = 0.0;
uniform vec4 flash_color : hint_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform float dissolve : hint_range(0.0, 1.0) = 0.0;
uniform vec4 edge_color : hint_color = vec4(1.0, 0.85, 0.3, 1.0);
uniform float edge_width = 0.08;
uniform float noise_scale = 14.0;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float value_noise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	float a = hash(i);
	float b = hash(i + vec2(1.0, 0.0));
	float c = hash(i + vec2(0.0, 1.0));
	float d = hash(i + vec2(1.0, 1.0));
	return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void fragment() {
	vec4 c = texture(TEXTURE, UV) * COLOR;
	c.rgb = mix(c.rgb, flash_color.rgb, flash);
	if (dissolve > 0.001) {
		float n = value_noise(UV * noise_scale);
		if (n < dissolve) {
			c.a = 0.0;
		} else if (n < dissolve + edge_width) {
			c.rgb = edge_color.rgb;
		}
	}
	COLOR = c;
}
