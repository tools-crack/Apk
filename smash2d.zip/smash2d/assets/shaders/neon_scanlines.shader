shader_type canvas_item;
// ============================================================================
//  neon_scanlines.gdshader  —  look de TV retro para la azotea.
// ----------------------------------------------------------------------------
//  Un ColorRect a pantalla completa (en un CanvasLayer, ver scenes/stages/Azotea.tscn).
//  Dibuja líneas horizontales oscuras, un oscurecimiento en las esquinas (viñeta)
//  y un leve tinte de neón. Es transparente en el centro: no tapa la pelea.
//  line_alpha : fuerza de las líneas (0..1)      vignette : fuerza de la viñeta
//  line_pitch : separación de las líneas en px     tint    : color del tinte
// ============================================================================

uniform float line_alpha = 0.12;
uniform float line_pitch = 4.0;
uniform float vignette = 0.5;
uniform vec4 tint : hint_color = vec4(1.0, 0.3, 0.8, 1.0);
uniform float tint_strength = 0.035;

void fragment() {
	float scan = 0.5 + 0.5 * sin(FRAGCOORD.y * 6.2831853 / line_pitch);
	float scan_a = scan * line_alpha;
	vec2 d = UV - vec2(0.5);
	float v = smoothstep(0.30, 0.80, length(d * vec2(1.25, 1.0)) * 1.1) * vignette;
	float a = clamp(scan_a + v, 0.0, 1.0);
	// la viñeta oscurece; el tinte se nota sobre todo en los bordes
	vec3 col = mix(vec3(0.0), tint.rgb, tint_strength * (0.4 + v));
	COLOR = vec4(col, a);
}
