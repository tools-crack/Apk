shader_type canvas_item;
// ============================================================================
//  heat_haze.gdshader  —  calor del desierto: la parte baja de la imagen tiembla.
// ----------------------------------------------------------------------------
//  Se pone en el Sprite "Background" de scenes/stages/Desierto.tscn.
//  strength : cuánto se desplaza (en fracción del ancho). 0.004 = unos 5 px.
//  from_y   : desde qué altura (0 arriba, 1 abajo) empieza a temblar.
// ============================================================================

uniform float strength = 0.004;
uniform float speed = 2.0;
uniform float frequency = 36.0;
uniform float from_y = 0.55;

void fragment() {
	float k = smoothstep(from_y, 1.0, UV.y);
	vec2 uv = UV;
	uv.x += sin(UV.y * frequency + TIME * speed) * strength * k;
	uv.x += sin(UV.y * frequency * 0.37 - TIME * speed * 1.3) * strength * 0.5 * k;
	uv.x = clamp(uv.x, 0.0, 1.0);
	COLOR = texture(TEXTURE, uv) * COLOR;
}
